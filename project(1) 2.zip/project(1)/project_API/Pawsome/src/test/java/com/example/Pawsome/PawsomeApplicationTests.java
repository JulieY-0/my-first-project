package com.example.Pawsome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PawsomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
