package com.example.Pawsome.service;

import com.example.Pawsome.dto.EMPTranrq;
import com.example.Pawsome.dto.EMPTranrs;
import com.example.Pawsome.dto.ONEEMPTranrq;
import com.example.Pawsome.dto.ONEEMPTranrs;
import com.example.Pawsome.dto.ONEORDERBYIDTranrq;
import com.example.Pawsome.dto.ONEORDERBYIDTranrs;
import com.example.Pawsome.exception.DataNotFoundException;

public interface EmpSvc {
    
    EMPTranrs queryEmp(EMPTranrq request) throws DataNotFoundException;
    
    ONEEMPTranrs queryOneEmp(ONEEMPTranrq request) throws DataNotFoundException;
    
    ONEORDERBYIDTranrs queryOrderByID(ONEORDERBYIDTranrq request) throws DataNotFoundException;

}
