package com.example.Pawsome.dto;

import javax.validation.constraints.Size;

import lombok.Data;


@Data
public class ONEEMPTranrqTranrq {
    
    /** empId 員工編號 */
    @Size(message = "員工編號長度不得超過20", max = 20)
    private String empId;
    
}
