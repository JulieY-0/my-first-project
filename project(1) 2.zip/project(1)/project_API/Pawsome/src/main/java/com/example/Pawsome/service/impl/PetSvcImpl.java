package com.example.Pawsome.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.dto.DELETEPETRq;
import com.example.Pawsome.dto.DELETEPETRs;
import com.example.Pawsome.dto.DELETEPETTranrq;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERRq;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERRs;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERTranrs;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.dto.UPDATEPETRq;
import com.example.Pawsome.dto.UPDATEPETRs;
import com.example.Pawsome.dto.UPDATEPETTranrq;
import com.example.Pawsome.entity.PsPetEntity;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.repository.PsPetEntityRepository;
import com.example.Pawsome.service.PetSvc;

@Service
public class PetSvcImpl implements PetSvc {

	@Autowired
	private PsPetEntityRepository petRepo;

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public UPDATEPETRs updatePet(UPDATEPETRq tranrq) {

		UPDATEPETTranrq dataEntity = tranrq.getTranrq();
		String custEmail = dataEntity.getCustEmail();
		String petName = dataEntity.getPetName();

		// 根據 custEmail 查詢資料
		List<PsPetEntity> petsWithEmail = petRepo.findByCustEmail(custEmail);

		PsPetEntity entity = null;

		for (PsPetEntity pet : petsWithEmail) {
			if (pet.getName().equals(petName)) {
				// 如果找到具有相同名字的寵物，則更新現有資料
				entity = pet;
				entity.setPetId(pet.getPetId());
				break;
			}
		}

		if (entity == null) {
			// 如果未找到具有相同名字的寵物，則創建新的資料實體
			entity = new PsPetEntity();
			// 執行查詢，得到目前序號最大值
			String maxPetIdQuery = "SELECT MAX(cast(PET_ID as int)) FROM PS_PET";
			Query query = entityManager.createNativeQuery(maxPetIdQuery);
			BigDecimal maxPetId = (BigDecimal) query.getSingleResult();
			String maxPetIdStr = maxPetId.toString();
			// 計算新的PET_ID值
			int nextPetId = Integer.parseInt(maxPetIdStr) + 1;
			String newPetId = String.format("%03d", nextPetId); // 格式化为三位数，例如 "004"
			entity.setPetId(newPetId);
		}

		// 更新資料
		entity.setCustEmail(custEmail);
		entity.setName(petName);
		entity.setType(dataEntity.getPetType());
		if (dataEntity.getSex() != null) {
			entity.setSex(dataEntity.getSex());
		}
		if (dataEntity.getBirth() != null) {
			entity.setBirth(dataEntity.getBirth());
		}
		if (dataEntity.getWeight() != null) {
			entity.setWeight(dataEntity.getWeight());
		}
		if (dataEntity.getRemarks() != null) {
			entity.setRemarks(dataEntity.getRemarks());
		}

		// 儲存或更新資料
		petRepo.save(entity);

		// 返回成功的回應
		TranrsMwheader mwheader = new TranrsMwheader();
		UPDATEPETRs rs = new UPDATEPETRs();
		mwheader.setMsgid("PAWSOME-UPDATEPET");
		ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
		mwheader.setReturnCode(traSuccess.getCode());
		mwheader.setReturnDesc(traSuccess.getDesc());
		rs.setMwheader(mwheader);
		return rs;
	}

	@Override
	public DELETEPETRs deletePet(DELETEPETRq tranrq) throws DataNotFoundException {
		DELETEPETTranrq dataEntity = tranrq.getTranrq();
		String custEmail = dataEntity.getCustEmail();
		String petName = dataEntity.getPetName();

		// 根據 custEmail 查詢資料
		List<PsPetEntity> petsWithEmail = petRepo.findByCustEmail(custEmail);
		ReturnCodeAndDescEnum traDataNotFound = ReturnCodeAndDescEnum.DATA_NOT_FOUND;
		if (petsWithEmail.isEmpty()) {
			throw new DataNotFoundException("PAWSOME-DELETEPET", traDataNotFound.getCode());
		}

		for (PsPetEntity pet : petsWithEmail) {
			if (pet.getName().equals(petName)) {
				petRepo.deleteById(pet.getPetId());
			}
		}

		// 返回成功的回應
		TranrsMwheader mwheader = new TranrsMwheader();
		DELETEPETRs rs = new DELETEPETRs();
		mwheader.setMsgid("PAWSOME-DELETEPET");
		ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
		mwheader.setReturnCode(traSuccess.getCode());
		mwheader.setReturnDesc(traSuccess.getDesc());
		rs.setMwheader(mwheader);
		return rs;
	}

	@Override
	public ONEPETBYCUSTOMERRs onePetByCustomer(ONEPETBYCUSTOMERRq tranrq) throws DataNotFoundException {
		String custEmail = tranrq.getTranrq().getCustEmail();
		// 根據 custEmail 查詢資料
		List<PsPetEntity> petsWithEmail = petRepo.findByCustEmail(custEmail);
		ReturnCodeAndDescEnum traDataNotFound = ReturnCodeAndDescEnum.DATA_NOT_FOUND;
		if (petsWithEmail.isEmpty()) {
			throw new DataNotFoundException("PAWSOME-DELETEPET", traDataNotFound.getCode());
		}
		// 使用repository 將Table資料裡面cust_email為特定值的查詢出來為一個List
		List<ONEPETBYCUSTOMERTranrs> datas = new ArrayList<>();
		// 查出來的Data全部變成data並存進List裡
		for (PsPetEntity pet : petsWithEmail) {
			ONEPETBYCUSTOMERTranrs data = new ONEPETBYCUSTOMERTranrs();
			data.setPetId(pet.getPetId());
			data.setCustEmail(pet.getCustEmail());
			data.setName(pet.getName());
			data.setType(pet.getType());
			data.setSex(pet.getSex());
			data.setBirth(pet.getBirth());
			data.setWeight(pet.getWeight());
			data.setRemarks(pet.getRemarks());
			datas.add(data);
		}
		// 返回成功的回應
		TranrsMwheader mwheader = new TranrsMwheader();
		ONEPETBYCUSTOMERRs rs = new ONEPETBYCUSTOMERRs();
		mwheader.setMsgid("PAWSOME-ONEPETBYCUSTOMER");
		ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
		mwheader.setReturnCode(traSuccess.getCode());
		mwheader.setReturnDesc(traSuccess.getDesc());
		rs.setMwheader(mwheader);
		rs.setTranrs(datas);
		return rs;
	}

}
