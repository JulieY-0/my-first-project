package com.example.Pawsome.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Pawsome.entity.PsImageEntity;

@Repository
public interface PsImageDataRepository extends JpaRepository<PsImageEntity, Long> {
	List<PsImageEntity> findByImageData(byte[] imageData);
	

}