package com.example.Pawsome.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.repository.PsServiceEntityRepository;
import com.example.Pawsome.service.ServiceSvc;

@Service
public class ServiceSvcImpl implements ServiceSvc {

    @Autowired
    private PsServiceEntityRepository serviceRepo;

}
