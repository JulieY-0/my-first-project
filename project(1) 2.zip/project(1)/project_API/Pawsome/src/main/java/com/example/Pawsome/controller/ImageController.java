package com.example.Pawsome.controller;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.Pawsome.entity.PsImageEntity;
import com.example.Pawsome.repository.PsImageDataRepository;
import com.example.Pawsome.service.ImageService;

@RestController
@RequestMapping("/api")
public class ImageController {

	@Autowired
	private PsImageDataRepository imageDataRepository;

	@Autowired
	private ImageService imageService;

	@PostMapping("/upload")
	public ResponseEntity<String> uploadImage(@RequestParam("file") MultipartFile file) {
		try {
			if (file.isEmpty()) {
				return ResponseEntity.badRequest().body("Please select a file to upload.");
			}

			// 验证文件类型是否为图片
			if (!file.getContentType().startsWith("image/")) {
				return ResponseEntity.badRequest().body("Please upload an image file.");
			}

			PsImageEntity imageEntity = new PsImageEntity();
			imageEntity.setName(file.getOriginalFilename());
			imageEntity.setType(file.getContentType());
			imageEntity.setImageData(file.getBytes());
			imageDataRepository.save(imageEntity);
			return ResponseEntity.ok("Image uploaded successfully");
		} catch (IOException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Image upload failed");
		}
	}

	@GetMapping("/images/{imageId}")
	public ResponseEntity<byte[]> getImage(@PathVariable Long imageId) {
		Optional<byte[]> imageData = imageService.getImageData(imageId);
		if (imageData.isPresent()) {
			return ResponseEntity.ok(imageData.get());
		} else {
			return ResponseEntity.notFound().build();
		}
	}
}
