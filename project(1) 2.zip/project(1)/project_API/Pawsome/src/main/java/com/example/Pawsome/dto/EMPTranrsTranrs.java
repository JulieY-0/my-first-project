package com.example.Pawsome.dto;

import java.util.List;

import javax.validation.Valid;

import lombok.Data;


@Data
public class EMPTranrsTranrs {
    
    /** items */
    @Valid
    private List<EMPTranrsTranrsItems> items;

}
