package com.example.Pawsome.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.entity.PsImageEntity;
import com.example.Pawsome.repository.PsImageDataRepository;
import com.example.Pawsome.service.ImageService;

@Service
public class IamgeServiceImpl implements ImageService {

	@Autowired
	private PsImageDataRepository imageDataRepository;

	public Optional<byte[]> getImageData(Long imageId) {
		return imageDataRepository.findById(imageId).map(PsImageEntity::getImageData);
	}
}
