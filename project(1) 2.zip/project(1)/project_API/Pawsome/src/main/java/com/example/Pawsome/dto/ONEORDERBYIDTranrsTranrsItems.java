package com.example.Pawsome.dto;

import javax.validation.constraints.Size;

import lombok.Data;


@Data
public class ONEORDERBYIDTranrsTranrsItems {
    
    /** no 訂單流水號 */
    @Size(message = "店家ID長度不得超過20", max = 20)
    private String no;
    
    /** orderId 訂單編號 */
    @Size(message = "訂單編號長度不得超過20", max = 20)
    private String orderId;
    
    /** custName 會員名稱 */
    @Size(message = "會員名稱長度不得超過20", max = 20)
    private String custName;
    
    /** petName 寵物名稱 */
    @Size(message = "寵物名稱長度不得超過20", max = 20)
    private String petName;
    
    /** petType 寵物類別 */
    @Size(message = "寵物類別長度不得超過5", max = 5)
    private String petType;
    
    /** tel 連絡電話 */
    @Size(message = "連絡電話長度不得超過15", max = 15)
    private String tel;
    
    /** startDate 服務開始日期 */
    private String startDate;
    
    /** endDate 服務結束日期 */
    private String endDate;
    
    /** startTime 服務開始時間 */
    @Size(message = "服務開始時間長度不得超過10", max = 10)
    private String startTime;
    
    /** endTime 服務結束時間 */
    @Size(message = "服務結束時間長度不得超過10", max = 10)
    private String endTime;
    
    /** price 價格 */
    private String price;
    
    /** remarks 備註 */
    @Size(message = "備註長度不得超過50", max = 50)
    private String remarks;
    
    /** confirmDate 確認訂單日期 */
    private String confirmDate;

    /** orderProcess 訂單進度 */
    @Size(message = "訂單進度長度不得超過10", max = 10)
    private String orderProcess;
    
    /** updateEmp 異動員工 */
    @Size(message = "異動員工長度不得超過20", max = 20)
    private String updateEmp;

}
