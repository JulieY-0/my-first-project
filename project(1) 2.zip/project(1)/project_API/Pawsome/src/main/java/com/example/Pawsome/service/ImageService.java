package com.example.Pawsome.service;

import java.util.Optional;

public interface ImageService {
	Optional<byte[]> getImageData(Long imageId);
}
