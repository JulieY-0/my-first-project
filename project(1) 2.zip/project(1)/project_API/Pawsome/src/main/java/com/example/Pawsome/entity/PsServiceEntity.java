package com.example.Pawsome.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
@Table(name = "PS_SERVICE")
public class PsServiceEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @NotBlank
    @Column(name = "SERVICE_ID")
    private String serviceId;
    
    @NotBlank
    @Column(name = "TYPE")
    private String type;
    
    @NotBlank
    @Column(name = "NAME")
    private String name;

    @NotBlank
    @Column(name = "BRIEF")
    private String brief;
    
    @NotBlank
    @Column(name = "LOCATION")
    private String location;
    
    @NotBlank
    @Column(name = "PET_TYPE")
    private String petType;
    
    @NotBlank
    @Column(name = "PET_SIZE_RANGE")
    private String petSizeRange;
    
    @NotNull
    @Column(name = "PRICE")
    private int price;
    
}
