package com.example.Pawsome.dto;

import java.util.List;

import javax.validation.Valid;

import lombok.Data;


@Data
public class ONEORDERBYIDTranrsTranrs {
    
    /** items */
    @Valid
    private List<ONEORDERBYIDTranrsTranrsItems> items;

}
