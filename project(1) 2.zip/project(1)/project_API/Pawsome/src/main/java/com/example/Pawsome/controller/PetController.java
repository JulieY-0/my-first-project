package com.example.Pawsome.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Pawsome.dto.DELETEPETRq;
import com.example.Pawsome.dto.DELETEPETRs;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERRq;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERRs;
import com.example.Pawsome.dto.UPDATEPETRq;
import com.example.Pawsome.dto.UPDATEPETRs;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.service.PetSvc;

@RestController
@RequestMapping("/api")
public class PetController {

    @Autowired
    private PetSvc petSvc;
    
    @PostMapping(value = "/updatePet")
    public UPDATEPETRs updatePet(@Valid
    @RequestBody
    UPDATEPETRq tranrq, Errors errors) throws DataNotFoundException  {
        //檢查errors是否有錯
//        if (errors.hasErrors()) {
//            StringBuilder sb = new StringBuilder();
//            for(ObjectError error : errors.getAllErrors()) {
//                sb.append(error.getDefaultMessage()).append(";");
//            }
//            throw new ErrorInputException("ErrorInputException 輸入資料內容格式錯誤或是內容缺少");
//        }
        return petSvc.updatePet(tranrq);
    }
    
    @PostMapping(value = "/deletePet")
    public DELETEPETRs deletePet(@Valid
    @RequestBody
    DELETEPETRq tranrq, Errors errors) throws DataNotFoundException  {
        //檢查errors是否有錯
//        if (errors.hasErrors()) {
//            StringBuilder sb = new StringBuilder();
//            for(ObjectError error : errors.getAllErrors()) {
//                sb.append(error.getDefaultMessage()).append(";");
//            }
//            throw new ErrorInputException("ErrorInputException 輸入資料內容格式錯誤或是內容缺少");
//        }
        return petSvc.deletePet(tranrq);
    }
    
    @PostMapping(value = "/onePetByCustomer")
    public ONEPETBYCUSTOMERRs onePetByCustomer(@Valid
    @RequestBody
    ONEPETBYCUSTOMERRq tranrq, Errors errors) throws DataNotFoundException  {
        //檢查errors是否有錯
//        if (errors.hasErrors()) {
//            StringBuilder sb = new StringBuilder();
//            for(ObjectError error : errors.getAllErrors()) {
//                sb.append(error.getDefaultMessage()).append(";");
//            }
//            throw new ErrorInputException("ErrorInputException 輸入資料內容格式錯誤或是內容缺少");
//        }
        return petSvc.onePetByCustomer(tranrq);
    }
}
