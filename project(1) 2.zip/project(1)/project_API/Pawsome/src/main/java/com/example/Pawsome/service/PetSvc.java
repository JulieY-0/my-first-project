package com.example.Pawsome.service;

import com.example.Pawsome.dto.DELETEPETRq;
import com.example.Pawsome.dto.DELETEPETRs;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERRq;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERRs;
import com.example.Pawsome.dto.UPDATEPETRq;
import com.example.Pawsome.dto.UPDATEPETRs;
import com.example.Pawsome.exception.DataNotFoundException;

public interface PetSvc {

	UPDATEPETRs updatePet(UPDATEPETRq tranrq);

	DELETEPETRs deletePet(DELETEPETRq tranrq) throws DataNotFoundException;

	ONEPETBYCUSTOMERRs onePetByCustomer(ONEPETBYCUSTOMERRq tranrq) throws DataNotFoundException;

}
