package com.example.Pawsome.utilities;

import org.apache.commons.lang3.StringUtils;

/**
 * getStringPad
 * 資料庫編號
 * @author 00550283
 *
 */
public class StringPadUtils {
    
    private StringPadUtils() {
        
    }
    
    /**
     * getStringPad
     * @return
     */
    public static String getStringPad(String s) {
        return StringUtils.leftPad(s, 3, '0');
    }
    

}
