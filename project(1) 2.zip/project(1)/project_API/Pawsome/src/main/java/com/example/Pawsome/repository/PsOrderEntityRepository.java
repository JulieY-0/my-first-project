package com.example.Pawsome.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Pawsome.entity.PsOrderEntity;

@Repository
public interface PsOrderEntityRepository extends JpaRepository<PsOrderEntity, String> {

//	    public List<PsOrderEntity> findByOrderID(String orderID);

}
