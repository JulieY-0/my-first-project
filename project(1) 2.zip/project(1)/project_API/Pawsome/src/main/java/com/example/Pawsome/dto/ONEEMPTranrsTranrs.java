package com.example.Pawsome.dto;

import java.util.List;

import javax.validation.Valid;

import lombok.Data;


@Data
public class ONEEMPTranrsTranrs {
    
    /** items */
    @Valid
    private List<ONEEMPTranrsTranrsItems> items;

}
