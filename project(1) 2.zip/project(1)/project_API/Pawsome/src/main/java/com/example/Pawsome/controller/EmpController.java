package com.example.Pawsome.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Pawsome.dto.EMPTranrq;
import com.example.Pawsome.dto.EMPTranrs;
import com.example.Pawsome.dto.ONEEMPTranrq;
import com.example.Pawsome.dto.ONEEMPTranrs;
import com.example.Pawsome.dto.ONEORDERBYIDTranrq;
import com.example.Pawsome.dto.ONEORDERBYIDTranrs;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.ErrorInputException;
import com.example.Pawsome.service.EmpSvc;

@RestController
@RequestMapping("/api")
public class EmpController {

    @Autowired
    private EmpSvc empSvc;

    /** EMP 員工資料查詢服務 */
    private static final String EMP = "PAWSOME-EMP";

    /** ONEEMP 單筆員工資料查詢服務 */
    private static final String ONEEMP = "PAWSOME-ONEEMP";

    /** 必填欄位不完整 */
    private static final String ERRORINPUT = "E001";

    @PostMapping(value = "/emp")
    public EMPTranrs queryEmp(@Valid
    @RequestBody
    EMPTranrq request, Errors errors) throws DataNotFoundException {
        return empSvc.queryEmp(request);
    }

    @PostMapping(value = "/oneEmp")
    public ONEEMPTranrs queryOneEmp(@Valid
    @RequestBody
    ONEEMPTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException {
        // 檢查上行 Errors 是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException(ONEEMP + sb, ERRORINPUT);
        }
        return empSvc.queryOneEmp(request);
    }
    
    @PostMapping(value = "/oneOrderByID")
    public ONEORDERBYIDTranrs queryOrderByID(@Valid
    @RequestBody
    ONEORDERBYIDTranrq request, Errors errors) throws DataNotFoundException {
        return empSvc.queryOrderByID(request);
    }

}
