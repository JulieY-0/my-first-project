package com.example.Pawsome.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Pawsome.entity.PsShoppingCartEntity;

@Repository
public interface PsShoppingCartEntityRepository extends JpaRepository<PsShoppingCartEntity, String>{

}
