package com.example.Pawsome.dto;

import javax.validation.constraints.Size;

import lombok.Data;


@Data
public class ONEEMPTranrsTranrsItems {
    
    /** empId 員工編號 */
    @Size(message = "員工編號長度不得超過20", max = 20)
    private String empId;
    
    /** name 員工名稱 */
    @Size(message = "員工名稱長度不得超過20", max = 20)
    private String name;
    
    /** email 員工信箱 */
    @Size(message = "員工信箱長度不得超過50", max = 50)
    private String email;
    
    /** password 員工密碼 */
    @Size(message = "員工密碼長度不得超過15", max = 15)
    private String password;
    
    /** tel 員工電話 */
    @Size(message = "員工電話長度不得超過15", max = 15)
    private String tel;

}
