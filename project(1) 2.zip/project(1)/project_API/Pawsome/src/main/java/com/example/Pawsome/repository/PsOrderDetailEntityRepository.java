package com.example.Pawsome.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Pawsome.entity.PsOrderDetailEntity;

@Repository
public interface PsOrderDetailEntityRepository extends JpaRepository<PsOrderDetailEntity, String>{
    
//    public List<PsOrderEntity> findByOrderID(String orderID);

}
