package com.example.Pawsome.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.dto.EMPTranrq;
import com.example.Pawsome.dto.EMPTranrs;
import com.example.Pawsome.dto.EMPTranrsTranrs;
import com.example.Pawsome.dto.EMPTranrsTranrsItems;
import com.example.Pawsome.dto.ONEEMPTranrq;
import com.example.Pawsome.dto.ONEEMPTranrs;
import com.example.Pawsome.dto.ONEEMPTranrsTranrs;
import com.example.Pawsome.dto.ONEEMPTranrsTranrsItems;
import com.example.Pawsome.dto.ONEORDERBYIDTranrq;
import com.example.Pawsome.dto.ONEORDERBYIDTranrs;
import com.example.Pawsome.dto.ONEORDERBYIDTranrsTranrsItems;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.entity.PsEmpEntity;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.repository.PsEmpEntityRepository;
import com.example.Pawsome.repository.PsOrderDetailEntityRepository;
import com.example.Pawsome.service.EmpSvc;
import com.example.Pawsome.service.sql.SqlAction;
import com.example.Pawsome.service.sql.SqlUtils;

@Service
public class EmpSvcImpl implements EmpSvc {
    
    /** SqlAction */
    @Autowired
    private SqlAction sqlAction;

    /** SqlUtils */
    @Autowired
    private SqlUtils sqlUtils;


    @Autowired
    private PsEmpEntityRepository empRepo;
    
    @Autowired
    private PsOrderDetailEntityRepository orderRepo;
    
    /** EMP 員工資料查詢服務 */
    private static final String EMP = "PAWSOME-EMP";
    
    /** ONEEMPT 單筆員工資料查詢服務 */
    private static final String ONEEMPT = "PAWSOME-ONEEMPT";
    
    /** ONEORDERBYID 單筆訂單查詢服務 */
    private static final String ONEORDERBYID = "PAWSOME-ONEORDERBYID";
    
    /** 交易成功代碼 */
    private static final String SUCCESSCODE = ReturnCodeAndDescEnum.SUCCESS.getCode();

    /** 交易成功訊息 */
    private static final String SUCCESSDESC = ReturnCodeAndDescEnum.SUCCESS.getDesc();
    
    /** 查無資料 */
    private static final String DATANOTFOUND = "E702";

    /** 更新失敗 */
    private static final String UPDATEFAIL = "E002";

    /** 刪除失敗 */
    private static final String DELETEFAIL = "E004";
    
    /** SQL_ONEORDERBYID */
    private static final String SQL_ONEORDERBYID = "ONEORDERBYID_QUERY_001.sql";

    @Override
    public EMPTranrs queryEmp(EMPTranrq request) throws DataNotFoundException {

        List<PsEmpEntity> entitys = empRepo.findAll();
        
        if(entitys.isEmpty()) {
            throw new DataNotFoundException(EMP, DATANOTFOUND);
        }

        List<EMPTranrsTranrsItems> itemsList = new ArrayList<>();
        for (PsEmpEntity entity : entitys) {
            EMPTranrsTranrsItems items = new EMPTranrsTranrsItems();
            items.setEmpId(entity.getEmpId());
            items.setName(entity.getName());
            items.setEmail(entity.getEmail());
            items.setPassword(entity.getPassword());
            items.setTel(entity.getTel());
            itemsList.add(items);
        }

        EMPTranrsTranrs empTranrsTranrs = new EMPTranrsTranrs();
        empTranrsTranrs.setItems(itemsList);

        TranrsMwheader empTranrsMwheader = new TranrsMwheader();
        empTranrsMwheader.setMsgid(EMP);
        empTranrsMwheader.setReturnCode(SUCCESSCODE);
        empTranrsMwheader.setReturnDesc(SUCCESSDESC);

        EMPTranrs empTranrs = new EMPTranrs();
        empTranrs.setMwheader(empTranrsMwheader);
        empTranrs.setTranrs(empTranrsTranrs);

        return empTranrs;
    }
    
    @Override
    public ONEEMPTranrs queryOneEmp(ONEEMPTranrq request) throws DataNotFoundException {
        
        Optional<PsEmpEntity> entityOptional = empRepo.findById(request.getTranrq().getEmpId());
        
        if(!entityOptional.isPresent()) {
            throw new DataNotFoundException(ONEEMPT, DATANOTFOUND);
        }
        
        PsEmpEntity entityData = entityOptional.get();
        ONEEMPTranrsTranrsItems items = new ONEEMPTranrsTranrsItems();
        items.setEmpId(entityData.getEmpId());
        items.setName(entityData.getName());
        items.setEmail(entityData.getEmail());
        items.setPassword(entityData.getPassword());
        items.setTel(entityData.getTel());        
        
        List<ONEEMPTranrsTranrsItems> itemsList = new ArrayList<>();
        itemsList.add(items);
        
        ONEEMPTranrsTranrs oneEmpTranrsTranrs = new ONEEMPTranrsTranrs();
        oneEmpTranrsTranrs.setItems(itemsList);
        
        TranrsMwheader oneEmpTranrsMwheader = new TranrsMwheader();
        oneEmpTranrsMwheader.setMsgid(ONEEMPT);
        oneEmpTranrsMwheader.setReturnCode(SUCCESSCODE);
        oneEmpTranrsMwheader.setReturnDesc(SUCCESSDESC);
        
        ONEEMPTranrs oneEmpTranrs = new ONEEMPTranrs();
        oneEmpTranrs.setMwheader(oneEmpTranrsMwheader);
        oneEmpTranrs.setTranrs(oneEmpTranrsTranrs);
        
        return oneEmpTranrs;
    }
    
    @Override
    public ONEORDERBYIDTranrs queryOrderByID(ONEORDERBYIDTranrq request) throws DataNotFoundException {

        Map<String, Object> mapQueryOrderByID = new HashMap<>();
        mapQueryOrderByID.put("orderId", request.getTranrq().getOrderId());

//        String querySql = sqlUtils.getDynamicQuerySQL(SQL_ONEORDERBYID, mapQueryOrderByID);
//        List<Map<String, Object>> queryEntity = sqlAction.queryForList(querySql, mapQueryOrderByID);

        // 查詢是否有資料
//        if (queryEntity.isEmpty()) {
//            throw new DataNotFoundException(ONEORDERBYID, DATANOTFOUND);
//        }

        List<ONEORDERBYIDTranrsTranrsItems> itemsList = new ArrayList<>();
//        for (Map<String, Object> entity : queryEntity) {
//            ONEORDERBYIDTranrsTranrsItems items = new ONEORDERBYIDTranrsTranrsItems();
//            items.setOrderId((String) entity.get("STORE_ID"));
//            items.setStoreName((String) entity.get("STORE_NAME"));
//            if (entity.get("OWNER") != null) {
//                items.setOwner((String) entity.get("OWNER"));
//            }
//            items.setTel((String) entity.get("TEL"));
//            if (entity.get("FAX") != null) {
//                items.setFax((String) entity.get("FAX"));
//            }
//            if (entity.get("MOBILE") != null) {
//                items.setMobile((String) entity.get("MOBILE"));
//            }
//            if (entity.get("ADDRESS") != null) {
//                items.setAddress((String) entity.get("ADDRESS"));
//            }
//            if (entity.get("MSG_OPTION_MEMO") != null) {
//                items.setEvaluation((String) entity.get("MSG_OPTION_MEMO"));
//            }
//            if (entity.get("REMARKS") != null) {
//                items.setRemarks((String) entity.get("REMARKS"));
//            }
//            if (entity.get("UPDATE_TIME") != null) {
//                Timestamp ts = Timestamp.valueOf(entity.get("UPDATE_TIME").toString());
//                items.setDate(ts.toLocalDateTime().format(formatter));
//            }
//            if (entity.get("UPDATE_USER") != null) {
//                items.setUpdateUser((String) entity.get("EMP_NAME"));
//            }
//
//            itemsList.add(items);
//        }
//
//        STOREQ001TranrsTranrs storeq001TranrsTranrs = new STOREQ001TranrsTranrs();
//        storeq001TranrsTranrs.setTotalPage(totalPage);
//        storeq001TranrsTranrs.setTotalCount(totalCount);
//        storeq001TranrsTranrs.setPageNumber(pageNumber);
//        storeq001TranrsTranrs.setPageSize(pageSize);
//        storeq001TranrsTranrs.setItems(itemsList);
//
//        TranrsMwheader storeq001TranrsMwheader = new TranrsMwheader();
//        storeq001TranrsMwheader.setMsgid(STOREQ001);
//        storeq001TranrsMwheader.setReturnCode(SUCCESSCODE);
//        storeq001TranrsMwheader.setReturnDesc(SUCCESSDESC);
//
//        STOREQ001Tranrs storeq001Tranrs = new STOREQ001Tranrs();
//        storeq001Tranrs.setMwheader(storeq001TranrsMwheader);
//        storeq001Tranrs.setTranrs(storeq001TranrsTranrs);
//
//        
//        List<ONEEMPTranrsTranrsItems> itemsList = new ArrayList<>();
//        itemsList.add(items);
//        
//        ONEEMPTranrsTranrs oneEmpTranrsTranrs = new ONEEMPTranrsTranrs();
//        oneEmpTranrsTranrs.setItems(itemsList);
//        
//        TranrsMwheader oneEmpTranrsMwheader = new TranrsMwheader();
//        oneEmpTranrsMwheader.setMsgid(ONEEMPT);
//        oneEmpTranrsMwheader.setReturnCode(SUCCESSCODE);
//        oneEmpTranrsMwheader.setReturnDesc(SUCCESSDESC);
//        
//        ONEEMPTranrs oneEmpTranrs = new ONEEMPTranrs();
//        oneEmpTranrs.setMwheader(oneEmpTranrsMwheader);
//        oneEmpTranrs.setTranrs(oneEmpTranrsTranrs);
        
//        return oneEmpTranrs;
        return null;
    }
    
    

}
