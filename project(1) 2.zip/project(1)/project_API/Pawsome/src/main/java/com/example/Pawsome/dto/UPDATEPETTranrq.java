package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class UPDATEPETTranrq {

//    @NotBlank(message = "寵物ID不可為空")
	private String petId;

	@NotBlank(message = "會員信箱不可為空")
	@Size(message = "會員信箱不得超過50", max = 50)
	private String custEmail;

	@NotBlank(message = "寵物名稱不可為空")
	@Size(message = "寵物名稱長度不得超過20", max = 20)
	private String petName;

	@NotBlank(message = "寵物類型不可為空")
	@Size(message = "寵物類別長度不得超過5", max = 10)
	private String petType;

	@NotBlank(message = "寵物性別不可為空")
	private String sex;

	private String birth;

	private String weight;

	private String remarks;

}
