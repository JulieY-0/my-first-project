package com.example.Pawsome.dto;

public class Empty {

}
