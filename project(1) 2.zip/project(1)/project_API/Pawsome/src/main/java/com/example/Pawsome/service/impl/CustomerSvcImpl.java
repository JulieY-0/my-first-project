package com.example.Pawsome.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.repository.PsCustomerRepository;
import com.example.Pawsome.service.CustomerSvc;

@Service
public class CustomerSvcImpl implements CustomerSvc {

    @Autowired
    private PsCustomerRepository custRepo;

	
    
}
