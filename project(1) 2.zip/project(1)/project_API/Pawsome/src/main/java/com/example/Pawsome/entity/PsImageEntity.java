package com.example.Pawsome.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "PS_IMAGEDATA")
public class PsImageEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_IMAGEID")
	@SequenceGenerator(name = "SEQ_IMAGEID", sequenceName = "SEQ_IMAGEID", allocationSize = 1)
	private Long id;

	@Column(name = "NAME")
	private String name;

	@Column(name = "TYPE")
	private String type;

	@Lob
	@Column(name = "IMAGEDATA")
	private byte[] imageData;

	// 其他屬性和getter/setter方法
}