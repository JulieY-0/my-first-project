package com.example.Pawsome.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.dto.UPDATEORDERRq;
import com.example.Pawsome.dto.UPDATEORDERRs;
import com.example.Pawsome.dto.UPDATEORDERTranrq;
import com.example.Pawsome.entity.PsOrderEntity;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.repository.PsOrderDetailEntityRepository;
import com.example.Pawsome.repository.PsOrderEntityRepository;
import com.example.Pawsome.service.OrderSvc;

@Service
public class OrderSvcImpl implements OrderSvc {

	@Autowired
	private PsOrderDetailEntityRepository orderDetailRepo;
	@Autowired
	private PsOrderEntityRepository orderRepo;

	@Override
	public UPDATEORDERRs updateOrder(UPDATEORDERRq tranrq) throws DataNotFoundException {
		UPDATEORDERTranrq dataEntity = tranrq.getTranrq();
		String orderId = dataEntity.getOrderId();

		// 根據訂單ID查詢資料
		Optional<PsOrderEntity> petsWithEmail = orderRepo.findById(orderId);
		ReturnCodeAndDescEnum traDataNotFound = ReturnCodeAndDescEnum.DATA_NOT_FOUND;
		if (petsWithEmail.isEmpty()) {
			throw new DataNotFoundException("PAWSOME-UPDATEORDER", traDataNotFound.getCode());
		}
		PsOrderEntity entity = new PsOrderEntity();
		entity.setOrderId(orderId);
		entity.setCustEmail(dataEntity.getCustomerEmail());
		entity.setTotal(dataEntity.getTotal());
		entity.setOrderProcess(dataEntity.getOrderProcess());
		orderRepo.save(entity);
		// 返回成功的回應
		TranrsMwheader mwheader = new TranrsMwheader();
		UPDATEORDERRs rs = new UPDATEORDERRs();
		mwheader.setMsgid("PAWSOME-UPDATEORDER");
		ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
		mwheader.setReturnCode(traSuccess.getCode());
		mwheader.setReturnDesc(traSuccess.getDesc());
		rs.setMwheader(mwheader);
		return rs;
	}
}
