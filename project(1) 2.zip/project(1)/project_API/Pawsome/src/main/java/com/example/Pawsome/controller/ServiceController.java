package com.example.Pawsome.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Pawsome.service.ServiceSvc;

@RestController
@RequestMapping("/api")
public class ServiceController {

    @Autowired
    private ServiceSvc serviceSvc;
    
}
