package com.example.Pawsome.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
@Entity
//@SequenceGenerator(name = "petId", sequenceName = "SEQ_PETID", allocationSize = 1)
@Table(name = "PS_PET")
public class PsPetEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
//    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator ="petId")
    @NotBlank
    @Column(name = "PET_ID")
    private String petId;

    @NotBlank
    @Column(name = "CUST_EMAIL")
    private String custEmail;

    @NotBlank
    @Column(name = "NAME")
    private String name;

    @NotBlank
    @Column(name = "TYPE")
    private String type;

    @Column(name = "SEX")
    private String sex;

    @Column(name = "BIRTH")
    private String birth;

    @Column(name = "WEIGHT")
    private String weight;

    @Column(name = "REMARKS")
    private String remarks;

}
