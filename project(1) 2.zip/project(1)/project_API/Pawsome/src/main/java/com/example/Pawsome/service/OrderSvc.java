package com.example.Pawsome.service;

import com.example.Pawsome.dto.UPDATEORDERRq;
import com.example.Pawsome.dto.UPDATEORDERRs;
import com.example.Pawsome.exception.DataNotFoundException;

public interface OrderSvc {
	UPDATEORDERRs updateOrder(UPDATEORDERRq tranrq) throws DataNotFoundException;
}
