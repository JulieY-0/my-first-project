package com.example.Pawsome.enums;

public enum ReturnDBCategoryEnum {
    EMP("EMP"),
    CUST("CUST"),     
	PET("PET"),    
	SERVICE("S"), 
	CART("ITEM"),     
	ORDER("NO");

    private String category;

    private ReturnDBCategoryEnum(String category) {
        this.category = category;
    }

    public String getCategory() {
        return category;
    }

}
