select *
 from STUDENT.PS_ORDER PO
 join STUDENT.PS_CUSTOMER PC 
  on PO.CUST_ID = PC.CUST_ID
 left join STUDENT.PS_PET PP
  on PO.PET_ID = PP.PET_ID
 where PO.ORDER_ID = :orderId
-- offset :pageSizeIndex row
-- fetch next :pageSize rows only