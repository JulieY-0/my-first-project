import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CommCodeMsgRequest } from 'src/interface/commCodeMsgRequest';
import { CommCodeMsgResponse } from 'src/interface/commCodeMsgResponse';
import { DeletePetRequest } from 'src/interface/deletePetRequest';
import { DeletePetResponse } from 'src/interface/deletePetResponse';
import { GetImageResponse } from 'src/interface/getImageResponse';
import { InsertPetRequest } from 'src/interface/insertPetRequest';
import { InsertPetResponse } from 'src/interface/insertPetResponse';
import { OneCustomerRequest } from 'src/interface/oneCustomerRequest';
import { OneCustomerResponse } from 'src/interface/oneCustomerResponse';
import { OneOrderByIDRequest } from 'src/interface/oneOrderByIdRequest';
import { OneOrderByIDResponse } from 'src/interface/oneOrderByIdResponse';
import { OneOrderDetailRequest } from 'src/interface/oneOrderDetailRequest';
import { OneOrderDetailResponse } from 'src/interface/oneOrderDetailResponse';
import { OnePetByCustomerRequest } from 'src/interface/onePetByCustomerRequest';
import { OnePetByCustomerResponse } from 'src/interface/onePetByCustomerResponse';
import { OnePetByIDRequest } from 'src/interface/onePetByIdRequest';
import { OnePetByIDResponse } from 'src/interface/onePetByIdResponse';
import { OrderByCustomerRequest } from 'src/interface/orderByCustomerRequest';
import { OrderByCustomerResponse } from 'src/interface/orderByCustomerResponse';
import { OrderDetailRequest } from 'src/interface/orderDetailRequest';
import { OrderDetailResponse } from 'src/interface/orderDetailResponse';
import { UpdateCustomerRequest } from 'src/interface/updateCustomerRequest';
import { UpdateCustomerResponse } from 'src/interface/updateCustomerResponse';
import { UpdateImageResponse } from 'src/interface/updateImageResponse';
import { UpdateOrderDetailRequest } from 'src/interface/updateOrderDetailRequest';
import { UpdateOrderDetailResponse } from 'src/interface/updateOrderDetailResponse';
import { UpdateOrderRequest } from 'src/interface/updateOrderRequest';
import { UpdateOrderResponse } from 'src/interface/updateOrderResonse';
import { UpdatePetRequest } from 'src/interface/updatePetRequest';
import { UpdatePetResponse } from 'src/interface/updatePetResponse';

@Injectable({
  providedIn: 'root'
})
export class MemberService {

  constructor(private http: HttpClient) { }




  /** oneCustomer查詢會員資料 */
  oneCustomer(request: OneCustomerRequest) {
    let url = 'http://localhost:8080/oneCustomer';
    return this.http.post<OneCustomerResponse>(url, request);
  }

  /** onePetByCustomer查詢會員寵物資料 */
  onePetByCustomer(request: OnePetByCustomerRequest) {
    let url = 'http://localhost:8080/onePetByCustomer';
    return this.http.post<OnePetByCustomerResponse>(url, request);
  }

  /** typeData 新增寵物-種類列表 */
  typeData(request: CommCodeMsgRequest) {
    let url = 'http://localhost:8080/commCodeMsg';
    return this.http.post<CommCodeMsgResponse>(url, request);
  }
  /** insertData 新增寵物-確認新增按鈕 */
  insertData(request: InsertPetRequest) {
    let url = 'http://localhost:8080/insertPet';
    return this.http.post<InsertPetResponse>(url, request);
  }
  /** updatePet 修改寵物-確認修改按鈕 */
  updatePet(request: UpdatePetRequest) {
    let url = 'http://localhost:8080/updatePet';
    return this.http.post<UpdatePetResponse>(url, request);
  }

  /** onePetById 修改寵物-載入即待出資料 */
  onePetById(request: OnePetByIDRequest) {
    let url = 'http://localhost:8080/onePetById';
    return this.http.post<OnePetByIDResponse>(url, request);
  }

  /** deletePet 刪除寵物-刪除按鈕 */
  deletePet(request: DeletePetRequest) {
    let url = 'http://localhost:8080/deletePet';
    return this.http.post<DeletePetResponse>(url, request);
  }

  /** 圖片Dialog-updateImage上傳圖片 */
  updateImage(file: File, imageId: string): Observable<UpdateImageResponse> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('imageId', imageId);
    const url = 'http://localhost:8080/updateImage';
    return this.http.post<UpdateImageResponse>(url, formData);
  }

  /** 圖片Dialog-用getImage取得空白圖 */
  getImage() {
    let url = 'http://localhost:8080/images/000';
    return this.http.get<GetImageResponse>(url);
  }

  /** orderByCustomer 會員預約管理-預約訂單列表 */
  orderByCustomer(request: OrderByCustomerRequest) {
    let url = 'http://localhost:8080/orderByCustomer';
    return this.http.post<OrderByCustomerResponse>(url, request);
  }

  /** oneOrderDetail 會員預約管理-預約詳細資訊 */
  oneOrderDetail(request: OneOrderDetailRequest) {
    let url = 'http://localhost:8080/oneOrderDetail';
    return this.http.post<OneOrderDetailResponse>(url, request);
  }

  /** orderDetail 會員預約管理-預約詳細資訊的查看訂單按鈕ngOnInit */
  orderDetail(request: OrderDetailRequest) {
    let url = 'http://localhost:8080/orderDetail';
    return this.http.post<OrderDetailResponse>(url, request);
  }
  /** oneOrderById 會員預約管理-預約詳細資訊的察看訂單按鈕的ngOnInit */
  oneOrderById(request: OneOrderByIDRequest) {
    let url = 'http://localhost:8080/oneOrderById';
    return this.http.post<OneOrderByIDResponse>(url, request);
  }

  /** updateOrderDetail 會員預約管理-預約詳細資訊的察看訂單按鈕的ngOnInit */
  updateOrderDetail(request: UpdateOrderDetailRequest) {
    let url = 'http://localhost:8080/updateOrderDetail';
    return this.http.post<UpdateOrderDetailResponse>(url, request);
  }

  /** updateOrder 會員預約管理-取消按鈕*/
  updateOrder(request: UpdateOrderRequest) {
    let url = 'http://localhost:8080/updateOrder';
    return this.http.post<UpdateOrderResponse>(url, request);
  }

  /** updateCustomer 會員管理-修改會員資料 */
  updateCustomer(request: UpdateCustomerRequest) {
    let url = 'http://localhost:8080/updateCustomer';
    return this.http.post<UpdateCustomerResponse>(url, request);
  }

}
