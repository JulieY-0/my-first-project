import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HASHCUSTranrq } from 'src/app/interfaces/hashCusTranrq';
import { HASHCUSTranrs } from 'src/app/interfaces/hashCusTranrs';
import { Imagers } from 'src/app/interfaces/imagers';

import { ServiceDetailRequest } from 'src/interface/ServiceDetailRequest';
import { ServiceDetailResponse } from 'src/interface/ServiceDetailResponse';
import { CartRequest } from 'src/interface/cartRequest';
import { CartResponse } from 'src/interface/cartResponse';
import { CommCodeMsgRequest } from 'src/interface/commCodeMsgRequest';
import { CommCodeMsgResponse } from 'src/interface/commCodeMsgResponse';
import { DeleteFavoriteRequest } from 'src/interface/deleteFavoriteRequest';
import { DeleteFavoriteResponse } from 'src/interface/deleteFavoriteResponse';
import { DeletePetRequest } from 'src/interface/deletePetRequest';
import { DeletePetResponse } from 'src/interface/deletePetResponse';
import { FavoriteByCustomerRequest } from 'src/interface/favoriteByCustomerRequest';
import { FavoriteByCustomerResponse } from 'src/interface/favoriteByCustomerResponse';
import { GetImageResponse } from 'src/interface/getImageResponse';
import { InsertFavoriteRequest } from 'src/interface/insertFavoriteRequest';
import { InsertFavoriteResponse } from 'src/interface/insertFavoriteResponse';
import { InsertPetRequest } from 'src/interface/insertPetRequest';
import { InsertPetResponse } from 'src/interface/insertPetResponse';
import { LoginCustRequest } from 'src/interface/loginCustRequest';
import { LoginCustResponse } from 'src/interface/loginCustResponse';
import { OneCustomerRequest } from 'src/interface/oneCustomerRequest';
import { OneCustomerResponse } from 'src/interface/oneCustomerResponse';
import { OneOrderByIDRequest } from 'src/interface/oneOrderByIdRequest';
import { OneOrderByIDResponse } from 'src/interface/oneOrderByIdResponse';
import { OneOrderDetailRequest } from 'src/interface/oneOrderDetailRequest';
import { OneOrderDetailResponse } from 'src/interface/oneOrderDetailResponse';
import { OnePetByCustomerRequest } from 'src/interface/onePetByCustomerRequest';
import { OnePetByCustomerResponse } from 'src/interface/onePetByCustomerResponse';
import { OnePetByIDRequest } from 'src/interface/onePetByIdRequest';
import { OnePetByIDResponse } from 'src/interface/onePetByIdResponse';
import { OneServiceRequest } from 'src/interface/oneServiceRequest';
import { OneServiceResponse } from 'src/interface/oneServiceResponse';
import { OrderByCustomerAndIDResponse } from 'src/interface/orderByCustomerAndIDResponse';
import { OrderByCustomerAndIDRequest } from 'src/interface/orderByCustomerAndIdRequest';
import { OrderByCustomerRequest } from 'src/interface/orderByCustomerRequest';
import { OrderByCustomerResponse } from 'src/interface/orderByCustomerResponse';
import { OrderDetailRequest } from 'src/interface/orderDetailRequest';
import { OrderDetailResponse } from 'src/interface/orderDetailResponse';
import { UpdateCustomerRequest } from 'src/interface/updateCustomerRequest';
import { UpdateCustomerResponse } from 'src/interface/updateCustomerResponse';
import { UpdateImageResponse } from 'src/interface/updateImageResponse';
import { UpdateOrderDetailRequest } from 'src/interface/updateOrderDetailRequest';
import { UpdateOrderDetailResponse } from 'src/interface/updateOrderDetailResponse';
import { UpdateOrderRequest } from 'src/interface/updateOrderRequest';
import { UpdateOrderResponse } from 'src/interface/updateOrderResonse';
import { UpdatePetRequest } from 'src/interface/updatePetRequest';
import { UpdatePetResponse } from 'src/interface/updatePetResponse';

@Injectable({
  providedIn: 'root'
})
export class MemberService {

  constructor(private http: HttpClient) { }




  /** oneCustomer查詢會員資料 */
  oneCustomer(request: OneCustomerRequest) {
    let url = 'http://localhost:8080/oneCustomer';
    return this.http.post<OneCustomerResponse>(url, request);
  }

  /** onePetByCustomer查詢會員寵物資料 */
  onePetByCustomer(request: OnePetByCustomerRequest) {
    let url = 'http://localhost:8080/onePetByCustomer';
    return this.http.post<OnePetByCustomerResponse>(url, request);
  }

  /** typeData 新增寵物-種類列表 */
  typeData(request: CommCodeMsgRequest) {
    let url = 'http://localhost:8080/commCodeMsg';
    return this.http.post<CommCodeMsgResponse>(url, request);
  }
  /** insertData 新增寵物-確認新增按鈕 */
  insertData(request: InsertPetRequest) {
    let url = 'http://localhost:8080/insertPet';
    return this.http.post<InsertPetResponse>(url, request);
  }
  /** updatePet 修改寵物-確認修改按鈕 */
  updatePet(request: UpdatePetRequest) {
    let url = 'http://localhost:8080/updatePet';
    return this.http.post<UpdatePetResponse>(url, request);
  }

  /** onePetById 修改寵物-載入即待出資料 */
  onePetById(request: OnePetByIDRequest) {
    let url = 'http://localhost:8080/onePetById';
    return this.http.post<OnePetByIDResponse>(url, request);
  }

  /** deletePet 刪除寵物-刪除按鈕 */
  deletePet(request: DeletePetRequest) {
    let url = 'http://localhost:8080/deletePet';
    return this.http.post<DeletePetResponse>(url, request);
  }

  /** 圖片Dialog-updateImage上傳圖片 */
  updateImage(file: File, imageId: string): Observable<UpdateImageResponse> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('imageId', imageId);
    const url = 'http://localhost:8080/updateImage';
    return this.http.post<UpdateImageResponse>(url, formData);
  }

  /** 圖片Dialog-用getImage取得空白圖 */
  getImage() {
    let url = 'http://localhost:8080/images/000';
    return this.http.get<GetImageResponse>(url);
  }

  /** orderByCustomer 會員預約管理-預約訂單列表 */
  orderByCustomer(request: OrderByCustomerRequest) {
    let url = 'http://localhost:8080/orderByCustomer';
    return this.http.post<OrderByCustomerResponse>(url, request);
  }

  /** oneOrderDetail 會員預約管理-預約詳細資訊 */
  oneOrderDetail(request: OneOrderDetailRequest) {
    let url = 'http://localhost:8080/oneOrderDetail';
    return this.http.post<OneOrderDetailResponse>(url, request);
  }

  /** orderDetail 會員預約管理-預約詳細資訊的查看訂單按鈕ngOnInit */
  orderDetail(request: OrderDetailRequest) {
    let url = 'http://localhost:8080/orderDetail';
    return this.http.post<OrderDetailResponse>(url, request);
  }
  /** oneOrderById 會員預約管理-預約詳細資訊的察看訂單按鈕的ngOnInit */
  oneOrderById(request: OneOrderByIDRequest) {
    let url = 'http://localhost:8080/oneOrderById';
    return this.http.post<OneOrderByIDResponse>(url, request);
  }

  /** updateOrderDetail 會員預約管理-預約詳細資訊的察看訂單按鈕的ngOnInit */
  updateOrderDetail(request: UpdateOrderDetailRequest) {
    let url = 'http://localhost:8080/updateOrderDetail';
    return this.http.post<UpdateOrderDetailResponse>(url, request);
  }

  /** updateOrder 會員預約管理-取消按鈕*/
  updateOrder(request: UpdateOrderRequest) {
    let url = 'http://localhost:8080/updateOrder';
    return this.http.post<UpdateOrderResponse>(url, request);
  }

   /** updateOrderStatus 會員預約管理-詳細訂單頁-刪除按鈕後做訂單更新*/
   updateOrderStatus(request: UpdateOrderRequest) {
    let url = 'http://localhost:8080/updateOrderStatus';
    return this.http.post<UpdateOrderResponse>(url, request);
  }


  /** updateCustomer 會員管理-修改會員資料 */
  updateCustomer(request: UpdateCustomerRequest) {
    let url = 'http://localhost:8080/updateCustomer';
    return this.http.post<UpdateCustomerResponse>(url, request);
  }

  /** hashCust 會員管理-先拿到會員帳號 */
  hashCust(request: HASHCUSTranrq) {
    let url = 'http://localhost:8080/hashCustomer';
    return this.http.post<HASHCUSTranrs>(url, request);
  }

  /** cart 預約管理-修改詳細訂單資訊- */
  cart(request: CartRequest) {
    let url = 'http://localhost:8080/cart';
    return this.http.post<CartResponse>(url, request);
  }

  /** serviceDetail 預約管理-修改詳細訂單資訊*/
  serviceDetail(request: ServiceDetailRequest) {
    let url = 'http://localhost:8080/serviceDetail';
    return this.http.post<ServiceDetailResponse>(url, request);
  }
  oneService(request: OneServiceRequest) {
    let url = 'http://localhost:8080/oneService';
    return this.http.post<OneServiceResponse>(url, request);
  }
  /** loginCust 會員管理-修改密碼-核對舊密碼 */
  loginCust(request: LoginCustRequest) {
    let url = 'http://localhost:8080/loginCustomer';
    return this.http.post<LoginCustResponse>(url, request);
  }

  /** loginCust 會員管理-修改密碼-核對舊密碼 */
  insetFavorite(request: InsertFavoriteRequest) {
    let url = 'http://localhost:8080/insertFavorite';
    return this.http.post<InsertFavoriteResponse>(url, request);
  }
  /** favoriteByCustomer 會員管理-我的收藏-產生卡片*/
  favoriteByCustomer(request: FavoriteByCustomerRequest) {
    let url = 'http://localhost:8080/favoriteByCustomer';
    return this.http.post<FavoriteByCustomerResponse>(url, request);
  }
  /** favoriteByCustomer 會員管理-我的收藏-產生卡片*/
  postGetImage(imageId: string) {
    let url = 'http://localhost:8080/images/' + imageId;
    return this.http.get<Imagers>(url)
  }

  /** deleteFavorite 會員管理-我的收藏-取消收藏 */
  deleteFavorite(request: DeleteFavoriteRequest) {
    let url = 'http://localhost:8080/deleteFavorite';
    return this.http.post<DeleteFavoriteResponse>(url, request)
  }

  /** orderByCustomerAndId 會員管理-預約管理-訂單搜尋 */
  orderByCustomerAndId(request: OrderByCustomerAndIDRequest) {
    let url = 'http://localhost:8080/orderByCustomerAndId';
    return this.http.post<OrderByCustomerAndIDResponse>(url, request)
  }

}
