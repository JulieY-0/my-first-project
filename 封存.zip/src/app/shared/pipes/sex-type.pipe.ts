import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: 'sexType'
})

export class SexTypePipe implements PipeTransform {

  // transform(s: string): string {
  //   return s === '1' ? '貓貓' : '狗狗';
  // }
  transform(s: string) {
    if (s === 'F') {
      return '女';
    } else if (s === 'M') {
      return '男';
    } else {
      return '-';
    }
  }

}
