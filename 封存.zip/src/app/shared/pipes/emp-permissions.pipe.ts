import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'empPermissions'
})
export class EmpPermissionsPipe implements PipeTransform {

  transform(s: string): string {
    return s === '1' ? '編輯者' : '檢視者';
  }

}
