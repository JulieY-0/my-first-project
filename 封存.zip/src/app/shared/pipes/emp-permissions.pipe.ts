import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'empPermissions',
})
export class EmpPermissionsPipe implements PipeTransform {
  transform(s: string): string {
    return s === '1' ? '店長' : '員工';
  }
}
