import { SexPipe } from './sex.pipe';

describe('SexPipe', () => {
  it('create an instance', () => {
    const pipe = new SexPipe();
    expect(pipe).toBeTruthy();
  });
});
