import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sex'
})
export class SexPipe implements PipeTransform {

  transform(s: string): string {
    return s === 'M' ? '男' : '女';
  }
}
