import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'empIsQuit'
})
export class EmpIsQuitPipe implements PipeTransform {

  transform(s: string): string {
    return s === 'y' ? '離職' : '在職';
  }

}
