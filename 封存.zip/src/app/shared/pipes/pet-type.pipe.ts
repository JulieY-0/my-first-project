import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'petType'
})
export class PetTypePipe implements PipeTransform {

  transform(s: string): string {
    return s === '1' ? '貓貓' : '狗狗';
  }

}


