import { EmpIsQuitPipe } from './emp-is-quit.pipe';

describe('EmpIsQuitPipe', () => {
  it('create an instance', () => {
    const pipe = new EmpIsQuitPipe();
    expect(pipe).toBeTruthy();
  });
});
