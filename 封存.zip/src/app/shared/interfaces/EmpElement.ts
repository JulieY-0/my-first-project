/** navLinks 資料 */
export interface navLink {
  label: string;
  link: string;
  index: number;
}

/** 員工列表 datasource 資料 */
export interface Emp {
  order: number;
  name: string;
  email: string;
  tel: string;
  sex: string | undefined;
  birthday: string | undefined;
  permissions: string;
  isQuit: string;
  updateTime: string;
}

/** 會員列表 datasource 資料 */
export interface Customer {
  order: number;
  name: string;
  email: string;
  tel: string;
  sex: string | undefined;
  birthday: string | undefined;
}

/** 訂單列表 datasource 資料 */
export interface Order {
  order: number;
  orderId: string;
  custEmail: string;
  custName: string;
  custTel: string;
  total: string;
  confirmDate: string | null | undefined;
  orderProcess: string;
}

/** 訂單明細列表 datasource 資料 */
export interface OrderDetail {
  order: number;
  itemId: string;
  serviceName: string;
  startDate: string;
  endDate: string | undefined;
  startTime: string;
  petName: string;
  petType: string;
  remarks: string | undefined;
  price: string;
  orderProcess: string;
  updateEmp: string | undefined;
  updateTime: string | undefined;
}

/** CommCode */
export interface CommCodeItems {
  commCode: string;
  msg: string;
}

/** 服務時間 */
export interface ServiceTime {
  time: string
}

/** Request */
export interface Request<T> {
  MWHEADER: MwheaderRQ;
  TRANRQ: T
}

/** Request Mwheader */
export interface MwheaderRQ {
  MSGID: string;
}

/** QueryEmpDataRequest Tranrq */
export interface QueryEmpDataTranrq {
  pageNumber: number;
  pageSize: number;
  email: string | undefined;
}

/** UpdateEmpDataRequest Tranrq */
export interface UpdateEmpDataTranrq {
  email: string;
  password: string;
  name: string;
  tel: string;
  sex: string | undefined;
  birthday: string | undefined;
  permissions: string;
  isQuit: string;
  updateTime: string;
}

/** CreateEmpDataRequest Tranrq */
export interface CreateEmpDataTranrq {
  email: string;
  password: string;
  name: string;
  tel: string;
  sex: string | undefined;
  birthday: string | undefined;
  permissions: string;
  isQuit: string;
  updateTime: string;
}

/** QueryAdminDataRequest Tranrq */
export interface QueryAdminDataTranrq {
  permissions: string;
}

/** QueryCustDataRequest Tranrq */
export interface QueryCustDataTranrq {
  pageNumber: number;
  pageSize: number;
}

/** QueryCustDataRequest Tranrq */
export interface QueryCustByEmailDataTranrq {
  pageNumber: number;
  pageSize: number;
  email: string | undefined;
}

/** UpdateCustDataRequest Tranrq */
export interface UpdateCustDataTranrq {
  name: string;
  custEmail: string;
  password: string;
  tel: string;
  sex: string | undefined;
  birthday: string | undefined;
}

/** QueryOrderDataRequest Tranrq */
export interface QueryOrderDataTranrq {
  pageNumber: number;
  pageSize: number;
}

/** QueryOrderByIdDataRequest Tranrq */
export interface QueryOrderByIdDataTranrq {
  pageNumber: number;
  pageSize: number;
  orderId: string | undefined;
}

/** UpdateOrderDataRequest Tranrq */
export interface UpdateOrderDataTranrq {
  custName: string;
  custTel: string;
  total: string;
  confirmDate: string | undefined;
  orderProcess: string;
}

/** QueryOrderDetailDataRequest Tranrq */
export interface QueryOrderDetailDataTranrq {
  pageNumber: number;
  pageSize: number;
  orderId: string;
}

/** QueryOneOrderDetailDataRequest Tranrq */
export interface QueryOneOrderDetailDataTranrq {
  pageNumber: number;
  pageSize: number;
  orderId: string;
  itemId: string;
}

/** UpdateOrderDetailDataRequest Tranrq */
export interface UpdateOrderDetailDataTranrq {
  orderId: string;
  itemId: string;
  startDate: string;
  endDate: string | undefined;
  startTime: string;
  petId: string;
  remarks: string;
  orderProcess: string;
}

/** QueryOnePetByCustomerDataRequest Tranrq */
export interface QueryPetByCustTranrq {
  custEmail: string;
}

/** QueryCommCodeRequest Tranrq */
export interface QueryCommCodeTranrq {
  type: string;
}

/** Response */
export interface Response<T> {
  MWHEADER: MwheaderRS;
  TRANRS: T
}

/** Response Mwheader */
export interface MwheaderRS {
  MSGID: string;
  RETURNCODE: string;
  RETURNDESC: string;
}

/** QueryEmpDataResponse Tranrs */
export interface QueryEmpTranrs {
  totalPage: number;
  totalCount: number;
  pageNumber: number;
  pageSize: number;
  items: EmpDataItems[];
}

/** QueryEmpDataResponse Tranrs Items */
export interface EmpDataItems {
  name: string;
  email: string;
  tel: string;
  sex: string | undefined;
  birthday: string | undefined;
  permissions: string;
  isQuit: string;
}

/** QueryAdminDataResponse Tranrs */
export interface QueryAdminTranrs {
  name: string;
  email: string;
}


/** QueryCustDataResponse Tranrs */
export interface QueryCustTranrs {
  cusNumber: number;
  totalPage: number;
  pageNumber: number;
  pageSize: number;
  items: CustDataItems[];
}

/** QueryOneCustDataResponse Tranrs */
export interface QueryOneCustTranrs {
  totalPage: number;
  totalCount: number;
  pageNumber: number;
  pageSize: number;
  imgData: string;
  items: CustDataItems[];
}

/** QueryCustDataResponse Tranrs Items */
export interface CustDataItems {
  name: string;
  email: string;
  tel: string;
  sex: string | undefined;
  birthday: string | undefined;
}

/** QueryOrderDataResponse Tranrs */
export interface QueryOrderTranrs {
  orderNumber: number;
  totalPage: number;
  pageNumber: number;
  pageSize: number;
  items: OrderDataItems[];
}

/** QueryOneOrderDataResponse Tranrs */
export interface QueryOneOrderTranrs {
  totalPage: number;
  totalCount: number;
  pageNumber: number;
  pageSize: number;
  items: OrderDataItems[];
}

/** QueryOrderDataResponse Tranrs Items */
export interface OrderDataItems {
  orderId: string;
  custEmail: string;
  custName: string;
  custTel: string;
  total: string;
  confirmDate: string;
  orderProcess: string;
}

/** QueryOrderDetailDataResponse Tranrs */
export interface QueryOrderDetailTranrs<T> {
  totalPage: number;
  totalCount: number;
  pageNumber: number;
  pageSize: number;
  items: T[];
}

/** QueryOrderDetailDataResponse Tranrs Items */
export interface OrderDetailDataItems {
  itemId: string;
  serviceName: string;
  startDate: string;
  endDate: string | undefined;
  startTime: string;
  petName: string;
  petType: string;
  remarks: string | undefined;
  price: string;
  orderProcess: string;
  updateEmp: string | undefined;
  updateTime: string | undefined;
}

/** QueryOneOrderDetailDataResponse Tranrs Items */
export interface OrderOneDetailDataItems {
  itemId: string;
  serviceName: string;
  startDate: string;
  endDate: string | undefined | null;
  startTime: string;
  petId: string;
  petName: string;
  petType: string;
  remarks: string | undefined;
  price: string;
  orderProcess: string;
  updateEmp: string | undefined;
  updateTime: string | undefined;
}

/** QueryPetByCustDataResponse Tranrs */
export interface QueryPetByCustResponse<T> {
  MWHEADER: MwheaderRS;
  TRANRS: QueryPetByCustTranrs[];
}

/** QueryPetByCustDataResponse Tranrs Items */
export interface QueryPetByCustTranrs {
  pet_id: number,
  cust_email: string,
  name: string;
  type: string;
  sex: string | undefined;
  birth: string | undefined;
  weight: string | undefined;
  remarks: string | undefined;
}

/** QueryCommCodeResponse Tranrs */
export interface QueryCommCodeTranrs {
  items: CommCodeItems[];
}

/** 會員寵物列表 */
export interface PetList {
  petId: string;
  petName: string;
  petType: string;
}






