import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  Request,
  Response,
  QueryEmpTranrs,
  QueryEmpDataTranrq,
  QueryOrderByIdDataTranrq,
  UpdateEmpDataTranrq,
  QueryOrderDataTranrq,
  QueryCustDataTranrq,
  QueryCustByEmailDataTranrq,
  QueryOrderTranrs,
  QueryOneOrderTranrs,
  QueryCustTranrs,
  QueryOneCustTranrs,
  QueryCommCodeTranrq,
  QueryCommCodeTranrs,
  CreateEmpDataTranrq,
  UpdateCustDataTranrq,
  UpdateOrderDataTranrq,
  QueryOrderDetailDataTranrq,
  QueryOrderDetailTranrs,
  QueryOneOrderDetailDataTranrq,
  UpdateOrderDetailDataTranrq,
  OrderDetailDataItems,
  OrderOneDetailDataItems,
  QueryPetByCustTranrs,
  QueryPetByCustResponse,
  QueryPetByCustTranrq,
  ServiceDetailTranrq,
  ServiceDetailTranrs,
  QueryCalendarTranrq,
  QueryCalendarTranrs,
  QueryOrderStatusDataTranrq,
  HashEmpTranrs,
} from '../interfaces/EmpElement';

@Injectable({
  providedIn: 'root',
})
export class EmpHttpService {
  constructor(private http: HttpClient) { }

  /**
   * 查詢hashEmail對應的empEmail
   * @param hashEmail
   * @returns
   */
  queryHashEmp(hashEmail: string) {
    const queryRequest = {
      MWHEADER: {
        MSGID: 'PAWSOME-HASHEMP'
      },
      TRANRQ: {
        hashEmail: hashEmail
      }
    };
    return this.http.post<HashEmpTranrs>('http://localhost:8080/hashEmp', queryRequest);
  }

  /**
   * 查詢員工資料列表
   * @param pageNumber
   * @param pageSize
   * @param email
   * @param name
   * @param tel
   * @param isQuit
   * @returns
   */
  queryEmpData(
    pageNumber: number,
    pageSize: number,
    email: string | undefined,
    name: string | undefined,
    tel: string | undefined,
    isQuit: string | undefined,
  ) {
    let url = 'http://localhost:8080/emp';
    const queryRequest: Request<QueryEmpDataTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-EMP',
      },
      TRANRQ: {
        pageNumber: pageNumber,
        pageSize: pageSize,
        email: email,
        name: name,
        tel: tel,
        isQuit: isQuit
      },
    };
    return this.http.post<Response<QueryEmpTranrs>>(url, queryRequest);
  }

  /**
   * 修正員工資料
   * @param upadateEmp
   * @returns
   */
  editEmpData(upadateEmp: UpdateEmpDataTranrq) {
    let url = 'http://localhost:8080/updateEmp';
    const updateRequest: Request<UpdateEmpDataTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-UPDATEEMP',
      },
      TRANRQ: upadateEmp,
    };
    return this.http.post<Response<Object>>(url, updateRequest);
  }

  /**
   * 新增員工資料
   * @param createEmp
   * @returns
   */
  addEmpData(createEmp: CreateEmpDataTranrq) {
    let url = 'http://localhost:8080/insertEmp';
    const updateRequest: Request<CreateEmpDataTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-INSERTEMP',
      },
      TRANRQ: createEmp,
    };
    return this.http.post<Response<Object>>(url, updateRequest);
  }

  /**
   * 查詢會員資料列表
   * @param pageNumber
   * @param pageSize
   * @returns
   */
  queryCustData(
    pageNumber: number,
    pageSize: number,
    email: string | undefined,
    name: string | undefined,
    tel: string | undefined
  ) {
    let url = 'http://localhost:8080/customer';
    const queryRequest: Request<QueryCustDataTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-CUSTOMER',
      },
      TRANRQ: {
        pageNumber: pageNumber,
        pageSize: pageSize,
        email: email,
        name: name,
        tel: tel
      },
    };
    return this.http.post<Response<QueryCustTranrs>>(url, queryRequest);
  }

  /**
   * 查詢單筆會員資料
   * @param pageNumber
   * @param pageSize
   * @param email
   * @returns
   */
  queryCustByEmailData(
    pageNumber: number,
    pageSize: number,
    email: string | undefined
  ) {
    let url = 'http://localhost:8080/oneCustomer';
    const queryRequest: Request<QueryCustByEmailDataTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-ONECUSTOMER',
      },
      TRANRQ: {
        pageNumber: pageNumber,
        pageSize: pageSize,
        email: email,
      },
    };
    return this.http.post<Response<QueryOneCustTranrs>>(url, queryRequest);
  }

  /**
   * 修正員工資料
   * @param upadateCust
   * @returns
   */
  editCustData(upadateCust: UpdateCustDataTranrq) {
    let url = 'http://localhost:8080/updateCustomer';
    const updateRequest: Request<UpdateCustDataTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-UPDATECUSTOMER',
      },
      TRANRQ: upadateCust,
    };
    return this.http.post<Response<Object>>(url, updateRequest);
  }

  /**
   * 查詢訂單資料列表
   * @param pageNumber
   * @param pageSize
   * @returns
   */
  queryOrder(
    pageNumber: number,
    pageSize: number,
    custName: string | undefined,
    custTel: string | undefined,
    orderId: string | undefined,
    orderProcess: string | undefined,
    qstartDate: string | undefined,
    qendDate: string | undefined,
  ) {
    let url = 'http://localhost:8080/order';
    const queryRequest: Request<QueryOrderDataTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-ORDER',
      },
      TRANRQ: {
        pageNumber: pageNumber,
        pageSize: pageSize,
        custName: custName,
        custTel: custTel,
        orderId: orderId,
        orderProcess: orderProcess,
        qstartDate: qstartDate,
        qendDate: qendDate
      },
    };
    return this.http.post<Response<QueryOrderTranrs>>(url, queryRequest);
  }

  /**
   * 查詢單筆訂單資料
   * @param pageNumber
   * @param pageSize
   * @param orderId
   * @returns
   */
  queryOrderById(
    pageNumber: number,
    pageSize: number,
    orderId: string | undefined
  ) {
    let url = 'http://localhost:8080/oneOrderById';
    const queryRequest: Request<QueryOrderByIdDataTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-EMP',
      },
      TRANRQ: {
        pageNumber: pageNumber,
        pageSize: pageSize,
        orderId: orderId,
      },
    };
    return this.http.post<Response<QueryOneOrderTranrs>>(url, queryRequest);
  }

  /**
 * 查詢訂單資料列表
 * @param pageNumber
 * @param pageSize
 * @returns
 */
  queryOrderStatus(pageNumber: number, pageSize: number, confirmDate: string, orderProcess: string) {
    let url = 'http://localhost:8080/orderStatus';
    const queryRequest: Request<QueryOrderStatusDataTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-ORDER',
      },
      TRANRQ: {
        pageNumber: pageNumber,
        pageSize: pageSize,
        confirmDate: confirmDate,
        orderProcess: orderProcess
      },
    };
    return this.http.post<Response<QueryOneOrderTranrs>>(url, queryRequest);
  }

  /**
   * 修改訂單狀態
   * @param upadateOrder
   * @returns
   */
  editOrderData(upadateOrder: UpdateOrderDataTranrq) {
    let url = 'http://localhost:8080/updateOrder';
    const updateRequest: Request<UpdateOrderDataTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-UPDATEORDER',
      },
      TRANRQ: upadateOrder,
    };
    return this.http.post<Response<Object>>(url, updateRequest);
  }

  /**
   * 查詢訂單明細資料
   * @param pageNumber
   * @param pageSize
   * @param orderId
   * @returns
   */
  queryOrderDetail(pageNumber: number, pageSize: number, orderId: string) {
    let url = 'http://localhost:8080/orderDetail';
    const queryRequest: Request<QueryOrderDetailDataTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-ORDERDETAIL',
      },
      TRANRQ: {
        pageNumber: pageNumber,
        pageSize: pageSize,
        orderId: orderId,
      },
    };
    return this.http.post<
      Response<QueryOrderDetailTranrs<OrderDetailDataItems>>
    >(url, queryRequest);
  }

  /**
   * 查詢單筆訂單明細資料
   * @param pageNumber
   * @param pageSize
   * @param orderId
   * @returns
   */
  queryOneOrderDetail(
    pageNumber: number,
    pageSize: number,
    orderId: string,
    itemId: string
  ) {
    let url = 'http://localhost:8080/oneOrderDetail';
    const queryRequest: Request<QueryOneOrderDetailDataTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-ONEORDERDETAIL',
      },
      TRANRQ: {
        pageNumber: pageNumber,
        pageSize: pageSize,
        orderId: orderId,
        itemId: itemId,
      },
    };
    return this.http.post<
      Response<QueryOrderDetailTranrs<OrderOneDetailDataItems>>
    >(url, queryRequest);
  }

  /**
   * 修改訂單明細資料
   * @param upadaterq
   * @returns
   */
  editOrderDetailData(upadaterq: UpdateOrderDetailDataTranrq) {
    let url = 'http://localhost:8080/updateOrderDetail';
    const updateRequest: Request<UpdateOrderDetailDataTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-UPDATEORDERDETAIL',
      },
      TRANRQ: upadaterq,
    };
    return this.http.post<Response<Object>>(url, updateRequest);
  }

  /**
   * 查詢會員寵物資料
   * @param type
   * @returns
   */
  queryOnePetByCust(custEmail: string) {
    let url = 'http://localhost:8080/onePetByCustomer';
    const queryRequest: Request<QueryPetByCustTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-ONEPETBYCUSTOMER',
      },
      TRANRQ: {
        custEmail: custEmail,
      },
    };
    return this.http.post<QueryPetByCustResponse<QueryPetByCustTranrs>>(
      url,
      queryRequest
    );
  }

  /**
   * 查詢共用代碼資料
   * @param type
   * @returns
   */
  queryMsgCode(type: string) {
    let url = 'http://localhost:8080/commCodeMsg';
    const queryRequest: Request<QueryCommCodeTranrq> = {
      MWHEADER: {
        MSGID: 'PAWSOME-COMMCODEMSG',
      },
      TRANRQ: {
        type: type,
      },
    };
    return this.http.post<Response<QueryCommCodeTranrs>>(url, queryRequest);
  }

  queryServiceDetail(name: string | null) {
    const serviceDetailQueryUrl = 'http://localhost:8080/serviceDetail';
    const request: ServiceDetailTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-SERVICEDETAIL',
      },
      TRANRQ: {
        name: name,
      },
    };
    return this.http.post<ServiceDetailTranrs>(serviceDetailQueryUrl, request);
  }

  queryCalendar() {
    const url = 'http://localhost:8080/calendar';
    const request: QueryCalendarTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-CALENDAR',
      }
    };
    return this.http.post<QueryCalendarTranrs>(url, request);
  }

}
