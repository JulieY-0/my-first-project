import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { CurrencyPipe, DatePipe } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatBadgeModule } from '@angular/material/badge';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MAT_DATE_FORMATS, MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatToolbarModule } from '@angular/material/toolbar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EditDialogComponent } from './dialogs/edit/edit-dialog/edit-dialog.component';
import { ImageComponent } from './image/image.component';
import { InsertpetComponent } from './insertpet/insertpet.component';
import { MemberOrderComponent } from './member-order/member-order.component';
import { MemberPetComponent } from './member-pet/member-pet.component';
import { BoardingProductComponent } from './pages/boarding-product/boarding-product.component';
import { BoardingComponent } from './pages/boarding/boarding.component';
import { CartComponent } from './pages/cart/cart.component';
import { CustEditComponent } from './pages/cust-edit/cust-edit.component';
import { CustListComponent } from './pages/cust-list/cust-list.component';
import { EmpAddComponent } from './pages/emp-add/emp-add.component';
import { EmpEditComponent } from './pages/emp-edit/emp-edit.component';
import { EmpListComponent } from './pages/emp-list/emp-list.component';
import { EmpTestComponent } from './pages/emp-test/emp-test.component';
import { EmpComponent } from './pages/emp/emp.component';
import { FooterComponent } from './pages/footer/footer.component';
import { GroomingComponent } from './pages/grooming/grooming.component';
import { LoginComponent } from './pages/login/login.component';
import { LoginempComponent } from './pages/loginemp/loginemp.component';
import { MainComponent } from './pages/main/main.component';
import { MemberComponent } from './pages/member/member.component';
import { NannyComponent } from './pages/nanny/nanny.component';
import { NavComponent } from './pages/nav/nav.component';
import { OrderDetailEditComponent } from './pages/order-detail-edit/order-detail-edit.component';
import { OrderDetailListComponent } from './pages/order-detail-list/order-detail-list.component';
import { OrderEditComponent } from './pages/order-edit/order-edit.component';
import { OrderListComponent } from './pages/order-list/order-list.component';
import { ProductComponent } from './pages/product/product.component';
import { RegisterComponent } from './pages/register/register.component';
import { ServiceAddComponent } from './pages/service-add/service-add.component';
import { ServiceEditComponent } from './pages/service-edit/service-edit.component';
import { ServiceListComponent } from './pages/service-list/service-list.component';
import { DialogComponent } from './shared/components/dialog/dialog.component';
import { SnackbarComponent } from './shared/components/snackbar/snackbar.component';
import { EmpIsQuitPipe } from './shared/pipes/emp-is-quit.pipe';
import { EmpPermissionsPipe } from './shared/pipes/emp-permissions.pipe';
import { PetTypePipe } from './shared/pipes/pet-type.pipe';
import { SvcAvaliablePipe } from './shared/pipes/svc-avaliable.pipe';
import { UpdatepetComponent } from './updatepet/updatepet.component';

import { MemberOrderdetailComponent } from './pages/member-orderdetail/member-orderdetail.component';
import { MemberOrderdetailUpdateComponent } from './pages/member-orderdetail-update/member-orderdetail-update.component';
import { SidenavComponent } from './pages/sidenav/sidenav.component';
import { MatMomentDateModule } from "@angular/material-moment-adapter";
import { MatListModule } from '@angular/material/list'

export const DATE_FORMAT = {
  parse: {
    dateInput: 'YYYY/MM/DD'
  },
  display: {
    dateInput: 'YYYY/MM/DD',
    monthYearLabel: 'YYYY MMM',
    dateA11yLabel: 'YYYY/MM/DD',
    monthYearA11yLabel: 'YYYY MMM'
  }
};
import { MatGridListModule } from '@angular/material/grid-list';
import { FullCalendarModule } from '@fullcalendar/angular';
import { CalendarComponent } from './pages/calendar/calendar.component';
import { MemberPasswordComponent } from './pages/member-password/member-password.component';
import { FavComponent } from './pages/fav/fav.component';
import { NavEmpComponent } from './pages/nav-emp/nav-emp.component';
import { SexTypePipe } from './shared/pipes/sex-type.pipe';
import { SexPipe } from './shared/pipes/sex.pipe';

@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    LoginComponent,
    NavComponent,
    FooterComponent,
    RegisterComponent,
    NannyComponent,
    CartComponent,
    MemberComponent,
    BoardingComponent,
    EmpComponent,
    GroomingComponent,
    ProductComponent,
    LoginempComponent,
    EmpListComponent,
    CustListComponent,
    OrderListComponent,
    ServiceListComponent,
    SnackbarComponent,
    DialogComponent,
    EmpPermissionsPipe,
    EmpIsQuitPipe,
    EmpTestComponent,
    EmpEditComponent,
    EmpAddComponent,
    CustEditComponent,
    BoardingProductComponent,
    EditDialogComponent,
    MemberPetComponent,
    MemberOrderComponent,
    InsertpetComponent,
    UpdatepetComponent,
    ImageComponent,
    OrderEditComponent,
    OrderDetailListComponent,
    OrderDetailEditComponent,
    SvcAvaliablePipe,
    ServiceAddComponent,
    ServiceEditComponent,
    MemberOrderdetailComponent,
    PetTypePipe,
    MemberOrderdetailUpdateComponent,
    SidenavComponent,
    CalendarComponent,
    MemberPasswordComponent,
    FavComponent,
    NavEmpComponent,
    SexTypePipe,
    SexPipe,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    NgbModule,
    MatMenuModule,
    MatToolbarModule,
    MatCardModule,
    MatDatepickerModule,
    MatInputModule,
    MatButtonModule,
    MatFormFieldModule,
    MatNativeDateModule,
    MatAutocompleteModule,
    ReactiveFormsModule,
    MatRadioModule,
    MatTableModule,
    MatExpansionModule,
    MatTabsModule,
    MatIconModule,
    MatDividerModule,
    MatSelectModule,
    HttpClientModule,
    FormsModule,
    HttpClientModule,
    MatSnackBarModule,
    MatPaginatorModule,
    MatDialogModule,
    MatCheckboxModule,
    MatBadgeModule,
    MatSidenavModule,
    MatMomentDateModule,
    MatGridListModule,
    FullCalendarModule,
    MatListModule
  ],
  providers: [DatePipe, CurrencyPipe, { provide: MAT_DATE_FORMATS, useValue: DATE_FORMAT }],
  bootstrap: [AppComponent],
  entryComponents: [EmpEditComponent],
})
export class AppModule { }
