import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from 'src/app/core/services/cart.service';
import { EmpDataItems } from 'src/app/shared/interfaces/EmpElement';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css'],
})
export class SidenavComponent implements OnInit {

  /** 員工信箱加密 */
  hashEmail = '';

  /** 員工信箱 */
  email = '';

  /** 員工資料 */
  info = {} as EmpDataItems;

  /** 員工登入狀態 */
  emploginstatus = true;

  /** 購物車數量 */
  countInCart = 0;

  /** 是否為 isAdmin */
  isAdmin = false;

  /** sidenav 是否展開 */
  isExpanded = true;

  constructor(
    private router: Router,
    private empHttpService: EmpHttpService
  ) { }

  ngOnInit(): void {
    window.scrollTo(0, 0);

    if (sessionStorage.getItem('hashempuser')) {
      this.hashEmail = sessionStorage.getItem('hashempuser')!;

      this.empHttpService.queryHashEmp(this.hashEmail).subscribe({
        next: (rs) => {
          this.email = rs.TRANRS.email;
        },
        complete: () => {
          this.empHttpService.queryEmpData(0, 1, this.email, '', '', '').subscribe((res) => {
            const responseData = res;
            this.info = responseData.TRANRS.items[0];
            if (this.info.permissions === '1') {
              this.isAdmin = true;
            }
            if (sessionStorage.getItem('nav') === 'emplogin') {
              this.emploginstatus = false;
            }
          });
        }
      })
    }
  }

  /** 員工資料查詢 */
  onQuery(email: string) {
    this.empHttpService.queryEmpData(0, 1, email, '', '', '').subscribe((res) => {
      const responseData = res;
      const _info = responseData.TRANRS.items[0];
      return _info;
    });
  }

  /** 員工登出 */
  emplogout() {
    if (sessionStorage) {
      sessionStorage.clear();
      this.router.navigate(['/']);
      this.emploginstatus = true;
    }
  }
}
