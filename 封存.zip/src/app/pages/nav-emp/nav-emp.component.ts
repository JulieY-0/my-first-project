import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subject, takeUntil, timer } from 'rxjs';
import { CartService } from 'src/app/core/services/cart.service';
import { EmpDataItems } from 'src/app/shared/interfaces/EmpElement';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import { MemberService } from 'src/service/member.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-nav-emp',
  templateUrl: './nav-emp.component.html',
  styleUrls: ['./nav-emp.component.css']
})
export class NavEmpComponent implements OnInit {

  /** 員工名字 */
  empName: string = '';
  /** 員工信箱 */
  email: string = '';

  constructor(
    private router: Router, private cartService: CartService, private empHttpService: EmpHttpService
  ) { }


  private unsubscribes$ = new Subject<void>();
  private idleTime = 60000;

  //初始值為true
  loginstatus: boolean = true;
  emploginstatus: boolean = true;

  /** 員工資料 */
  info = {} as EmpDataItems;

  @HostListener('document:mousemove', ['$event'])
  @HostListener('document:keypress', ['$event'])
  onUserAction(_event: Event): void {
    this.resetimer()
  }

  ngOnInit(): void {
    window.scrollTo(0, 0);
    //自動登出
    this.resetimer();
    //目前是10秒
    timer(this.idleTime)
      .pipe(takeUntil(this.unsubscribes$)).subscribe(() => {
        if (sessionStorage.getItem('hashempuser')) {
          this.emplogout();
          Swal.fire({
            icon: 'info',
            title: '閒置過久，請重新登入!',
            width: 450,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
          })
        }
      });

    if (sessionStorage.getItem('nav') === 'login') {
      this.loginstatus = false;
    }
    if (sessionStorage.getItem('nav') === 'emplogin') {
      this.emploginstatus = false;
    }
    if (sessionStorage.getItem('isQuit') === 'y') {
      this.emplogout();
      Swal.fire({
        icon: 'warning',
        title: '帳號已停權',
        width: 450,
        padding: '3em',
        color: '#5d3f0a',
        background: '#fff',
      })
    }


    if (sessionStorage.getItem('hashempuser')) {
      const hashEmpEmail = sessionStorage.getItem('hashempuser')!;
      this.empHttpService.queryHashEmp(hashEmpEmail).subscribe(rs => {
        this.email = rs.TRANRS.email;
        this.onQuery(this.email);
      });
    }
  }

  ngOnDestroy(): void {
    this.unsubscribes$.next();
    this.unsubscribes$.complete();
  }

  resetimer() {
    this.unsubscribes$.next();
  }

  redirectLogin() {
    this.router.navigate(['/loginemp']);
  }

  /** 員工資料查詢 */
  onQuery(email: string) {
    this.empHttpService.queryEmpData(0, 1, email, '', '', '').subscribe((res) => {
      const responseData = res;
      this.info = responseData.TRANRS.items[0];
    });
  }

  /** 聯絡資訊*/
  contact() {
    Swal.fire({
      icon: 'info',
      html: '聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
      width: 450,
      padding: '3em',
      color: '#5d3f0a',
      background: '#fff',
      // confirmButtonText: '再試試',
    })
  }

  emplogout() {
    if (sessionStorage) {
      sessionStorage.clear();
      this.router.navigate(['/loginemp']);
      this.emploginstatus = true;
    }
  }
}
