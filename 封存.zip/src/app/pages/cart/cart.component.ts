import { CurrencyPipe, DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { combineLatest } from 'rxjs';
import { EditShareTranrs } from 'src/app/core/interfaces/editShareTranrs.interface';
import { InsertOrderTranrqItems } from 'src/app/core/interfaces/insertOrder/insertOrderTranrqItems.interface';
import { InsertOrderTranrs } from 'src/app/core/interfaces/insertOrder/insertOrderTranrs.interface';
import { QueryCartTranrqItems } from 'src/app/core/interfaces/queryCart/queryCartTranrqItems.interface';
import { QueryCartTranrs } from 'src/app/core/interfaces/queryCart/queryCartTranrs.interface';
import { QueryCartTranrsItems } from 'src/app/core/interfaces/queryCart/queryCartTranrsItems.interface';
import { CartService } from 'src/app/core/services/cart.service';
import { OrderService } from 'src/app/core/services/order.service';
import { EditDialogComponent } from 'src/app/dialogs/edit/edit-dialog/edit-dialog.component';
import { ServiceDetailTranrs } from 'src/app/interfaces/serviceDetailTranrs';
import { ProductsService } from 'src/app/services/products.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {

  /** 會員信箱 */
  custEmail: string = '';
  /** 加密信箱 */
  hashEmail: string | null = '';
  /** 是否送單 購物車只顯示為n的服務 */
  isSubmit: string = 'n';
  /** 總金額 */
  totalPrice: number = 0;
  /** 各項服務總金額 */
  serviceTotalPrice: string = '';
  /** 訂單狀態 預設皆為已確認 = 1 */
  orderProcess: string = '1';
  /** 訂單確認日期 */
  confirmDate: Date = new Date();
  /** 轉換訂單確認日期為後端要求格式 */
  transformedDate: string | null = '';
  /** 所有checkbox狀態 */
  allChecked: boolean = false;
  /** 單個checkbox狀態 */
  isChecked: boolean = false;
  /** 購物車ID */
  itemId: string = '';
  /** 總筆數 */
  totalCount: number = 0;
  /** 訂單編號 */
  orderId: string = '111';
  /** checkbox選取的資料 */
  selectedItems: QueryCartTranrsItems[] = [];
  /** 當天日期 */
  today: Date = new Date();
  /** 導航路徑 */
  formPath: string = '';
  /** 使用者在購物車點選的服務 */
  serviceName: string = '';

  constructor(private cartService: CartService, private orderService: OrderService, private productService: ProductsService, private router: Router, private dialog: MatDialog, private datePipe: DatePipe) { }

  /** TABLE欄位 */
  displayedColumns: string[] = [
    // 'index',
    'chooseItem',
    'serviceName',
    'startDate',
    'endDate',
    'startTime',
    'petName',
    'petType',
    'remarks',
    'serviceTotalPrice',
    'edit',
    'delete'
  ];

  /** 會員購物車列表 */
  dataSource: QueryCartTranrsItems[] = [];

  /**
   * 傳入會員信箱查詢購物車
   * 轉換confirmDate為中台要求格式進入訂單DB
   */
  ngOnInit(): void {
    window.scrollTo(0, 0);
    this.hashEmail = sessionStorage.getItem('hashuser');
    if (this.hashEmail) {
      this.cartService.queryHashCus(this.hashEmail).subscribe(rs => {
        this.custEmail = rs.TRANRS.email;
        this.onQuery(this.custEmail);
      });
    } else {
      this.router.navigate(['/login']);
    }
    this.transformedDate = this.datePipe.transform(this.confirmDate, 'yyyy-MM-dd');

  }

  /**
   * 購物車資料查詢服務
   * @param custEmail
   */
  onQuery(custEmail: string) {
    const input: QueryCartTranrqItems = {
      custEmail: custEmail,
      isSubmit: this.isSubmit
    };
    this.cartService.query(input).subscribe((rs: QueryCartTranrs) => {
      const returnCode = rs.MWHEADER.RETURNCODE;
      const tranrs = rs.TRANRS;
      if (returnCode === '0000') {
        this.totalCount = tranrs.totalCount;
        this.dataSource = tranrs.items;
        this.cartService.setCountInCart(this.totalCount);
      } else if (returnCode === 'E001' || !this.hashEmail) {
        this.router.navigate(['/login']); // 必填欄位不完整(需登入/註冊)
      } else if (returnCode === 'E702' || this.totalCount === 0) {
        // 購物車為空
      } else {
        Swal.fire({
          icon: 'warning',
          title: '<strong>其他系統異常</strong>',
          width: 350,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonText: '再試試',
          confirmButtonColor: '#ffbd4a'
        });
      }
    });
  }

  onServiceNameClick(serviceName: string) {
    this.serviceName = serviceName;
    sessionStorage.setItem('name', this.serviceName);
    this.productService.postServiceDetailQuery(this.serviceName).subscribe((rs: ServiceDetailTranrs) => {
      if (rs.TRANRS.datas[0].type === '寵物住宿') {
        this.router.navigate(['/boardingproduct']);
      }
      else {
        this.router.navigate(['/product']);
      }
    });
  }

  /**
   * 將按鈕所在的該筆資料存入cartService
   * 呼叫EditDialog
   * @param item
   */
  onEdit(item: QueryCartTranrsItems) {
    this.cartService.setEditItem(item);
    const dialogRef = this.dialog.open(EditDialogComponent);
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.onQuery(item.custEmail);
      }
    });
  }

  /**
   * 購物車資料刪除服務
   * @param item
   */
  onDelete(item: QueryCartTranrsItems) {
    this.itemId = item.itemId;
    const inputItemId: string = this.itemId;
    Swal.fire({
      icon: 'warning',
      title: '<strong>是否要移除這筆服務？</strong>',
      showCancelButton: true,
      confirmButtonText: '<strong>確認</strong>',
      cancelButtonText: '<strong>取消</strong>',
      padding: '3em',
      background: '#fff',
      confirmButtonColor: '#ffbd4a',
      cancelButtonColor: '#5d3f0a'
    }).then((result) => {
      if (result.isConfirmed) {
        this.cartService.delete(inputItemId).subscribe((rs: EditShareTranrs) => {
          const returnCode = rs.MWHEADER.RETURNCODE;
          if (returnCode === '0000') {
            this.onQuery(this.custEmail);
          } else if (returnCode === 'E001') {
            Swal.fire({
              icon: 'warning',
              title: '<strong>必填欄位不得為空</strong>',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '確認',
              confirmButtonColor: '#ffbd4a'
            });
          } else if (returnCode === 'E702') {
            Swal.fire({
              icon: 'warning',
              title: '<strong>查無該筆購物車資料</strong>',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
              confirmButtonColor: '#ffbd4a'
            });
          } else if (returnCode === 'E004') {
            Swal.fire({
              icon: 'error',
              title: '<strong>刪除購物車失敗</strong>',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
              confirmButtonColor: '#ffbd4a'
            });
          } else {
            Swal.fire({
              icon: 'warning',
              title: '<strong>其他系統異常</strong>',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
              confirmButtonColor: '#ffbd4a'
            });
          }
        });
      }
    });
  }

  /**
   * 回上一頁
   */
  return() {
    this.router.navigate(['/']).then(() => {
      const element = document.querySelector('#maingroup');
      if (element) element.scrollIntoView({ behavior: 'smooth' });
    });
  }

  /**
   * 訂單資料新增服務
   */
  insertOrder() {
    Swal.fire({
      icon: 'warning',
      title: '<strong>是否要送出預約？</strong>',
      showCancelButton: true,
      confirmButtonText: '<strong>送出</strong>',
      cancelButtonText: '<strong>取消</strong>',
      padding: '3em',
      background: '#fff',
      confirmButtonColor: '#ffbd4a',
      cancelButtonColor: '#5d3f0a'
    }).then((result) => {
      if (result.isConfirmed) {
        const input: InsertOrderTranrqItems[] = this.selectedItems.map(item => {
          return {
            custEmail: this.custEmail,
            itemId: item.itemId,
            serviceTotalPrice: item.serviceTotalPrice,
            orderProcess: this.orderProcess,
            confirmDate: this.transformedDate
          }
        });
        this.orderService.insert(input).subscribe((rs: InsertOrderTranrs) => {
          const returnCode = rs.MWHEADER.RETURNCODE;
          this.orderId = rs.TRANRS.orderId;
          if (returnCode === '0000') {
            this.onQuery(this.custEmail);
            Swal.fire({
              icon: 'success',
              title: '<strong>訂單成立</strong>',
              text: `訂單編號： ${this.orderId}`,
              width: 350,
              padding: '3em',
              background: '#fff',
              confirmButtonColor: '#ffbd4a'
            }).then(() => this.router.navigate(['/orderDetail'], { queryParams: { orderId: this.orderId } }));
          } else if (returnCode === 'E003') {
            Swal.fire({
              icon: 'error',
              title: '<strong>訂單送出失敗</strong>',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
              confirmButtonColor: '#ffbd4a'
            });
          } else {
            Swal.fire({
              icon: 'warning',
              title: '<strong>其他系統異常</strong>',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
              confirmButtonColor: '#ffbd4a'
            });
          }
        });
      }
    });
  }

  /**
   * checkbox全選
   * @param allCheckbox
   */
  allOnChecked(allCheckbox: MatCheckboxChange) {
    this.allChecked = allCheckbox.checked;
    if (allCheckbox.checked) {
      this.isChecked = allCheckbox.checked;
      this.dataSource.forEach(item => {
        if (!this.isSelected(item)) {
          this.onChecked(allCheckbox, item);
        }
      });
      console.log('0', this.allChecked);
    } else {
      // this.allChecked = false;
      this.isChecked = false;
      this.selectedItems.length = 0;
      this.totalPrice = 0;
      console.log('1', this.allChecked);
      console.log('1ischecked', this.isChecked);
    }
    // if (allCheckbox.checked) {
    //   this.allChecked = true;
    //   this.isChecked = true;
    //   this.dataSource.map(selectedItem => {
    //     this.onChecked(allCheckbox, selectedItem);
    //   });
    // } else {
    //   this.isChecked = false;
    //   this.selectedItems.length = 0;
    //   this.totalPrice = 0;
    // }
  }

  isSelected(item: QueryCartTranrsItems): boolean {
    return this.selectedItems.findIndex(selectedItem => selectedItem.itemId === item.itemId) !== -1;
  }

  /**
   * 監聽checkbox事件
   * @param checkedbox
   * @param item
   */
  onChecked(checkbox: MatCheckboxChange, item: QueryCartTranrsItems) {
    if (checkbox.checked) {
      const selectedStartDate = new Date(item.startDate);
      if (selectedStartDate > this.today) {
        const inputQueryCartNotSubmit: QueryCartTranrqItems = {
          custEmail: this.custEmail,
          isSubmit: 'n'
        };
        const isSubmit: string = 'y'
        combineLatest([this.cartService.query(inputQueryCartNotSubmit), this.cartService.queryCartIsSubmit(isSubmit)]).subscribe(([notSubmitRs, isSubmitRs]) => {
          let hasWarning = false;
          notSubmitRs.TRANRS.items.map(itemsInCart => {
            this.selectedItems.map(selectedItem => {
              const checkedServiceId = selectedItem.serviceId;
              const checkedStartDate = selectedItem.startDate;
              const checkedEndDate = selectedItem.endDate;
              const checkedStartTime = selectedItem.startTime;
              if (item.itemId !== itemsInCart.itemId) {
                if (item.serviceId === checkedServiceId) {
                  if (item.startDate === checkedStartDate) {
                    if (item.endDate !== null) {
                      hasWarning = true;
                      Swal.fire({
                        icon: 'warning',
                        title: '<strong>請修改預約日期或預約時間</strong>',
                        html: '<strong>購物車資料日期衝突1</strong>',
                        showCancelButton: true,
                        padding: '3em',
                        color: '#5d3f0a',
                        background: '#fff',
                        confirmButtonText: '<strong>修改</strong>',
                        cancelButtonText: '<strong>取消</strong>',
                        confirmButtonColor: '#ffbd4a'
                      }).then((result) => {
                        if (result.isConfirmed) {
                          this.cartService.setEditItem(item);
                          const dialogRef = this.dialog.open(EditDialogComponent);
                          dialogRef.afterClosed().subscribe(result => {
                            if (result) {
                              this.onQuery(item.custEmail);
                            }
                          });
                        }
                        this.totalPrice = 0;
                        this.selectedItems.length = 0;
                        this.isChecked = false;
                        this.allChecked = false;
                        this.onQuery(this.custEmail);
                      });
                    } else if (item.endDate === null && item.startTime === checkedStartTime) {
                      console.log(this.selectedItems);
                      hasWarning = true;
                      Swal.fire({
                        icon: 'warning',
                        title: '<strong>請修改預約日期或預約時間</strong>',
                        html: '<strong>購物車資料日期衝突2</strong>',
                        showCancelButton: true,
                        padding: '3em',
                        color: '#5d3f0a',
                        background: '#fff',
                        confirmButtonText: '<strong>修改</strong>',
                        cancelButtonText: '<strong>取消</strong>',
                        confirmButtonColor: '#ffbd4a'
                      }).then((result) => {
                        if (result.isConfirmed) {
                          this.cartService.setEditItem(item);
                          const dialogRef = this.dialog.open(EditDialogComponent);
                          dialogRef.afterClosed().subscribe(result => {
                            if (result) {
                              this.onQuery(item.custEmail);
                            }
                          });
                        }
                        this.totalPrice = 0;
                        this.selectedItems.length = 0;
                        this.isChecked = false;
                        this.allChecked = false;
                        this.onQuery(this.custEmail);
                      });
                    }
                  } else if (this.selectedItems.length !== 0) {
                    if (item.endDate && item.endDate === checkedEndDate) {
                      if (item.startDate < checkedStartDate) {
                        hasWarning = true;
                        Swal.fire({
                          icon: 'warning',
                          title: '<strong>請修改預約日期或預約時間</strong>',
                          html: '<strong>購物車資料日期衝突</strong>',
                          showCancelButton: true,
                          padding: '3em',
                          color: '#5d3f0a',
                          background: '#fff',
                          confirmButtonText: '<strong>修改</strong>',
                          cancelButtonText: '<strong>取消</strong>',
                          confirmButtonColor: '#ffbd4a'
                        }).then((result) => {
                          if (result.isConfirmed) {
                            this.cartService.setEditItem(item);
                            const dialogRef = this.dialog.open(EditDialogComponent);
                            dialogRef.afterClosed().subscribe(result => {
                              if (result) {
                                this.onQuery(item.custEmail);
                              }
                            });
                          }
                          this.totalPrice = 0;
                          this.selectedItems.length = 0;
                          this.isChecked = false;
                          this.allChecked = false;
                          this.onQuery(this.custEmail);
                        });
                      } else if (item.startDate > checkedStartDate) {
                        hasWarning = true;
                        Swal.fire({
                          icon: 'warning',
                          title: '<strong>請修改預約日期或預約時間</strong>',
                          html: '<strong>購物車資料日期衝突</strong>',
                          showCancelButton: true,
                          padding: '3em',
                          color: '#5d3f0a',
                          background: '#fff',
                          confirmButtonText: '<strong>修改</strong>',
                          cancelButtonText: '<strong>取消</strong>',
                          confirmButtonColor: '#ffbd4a'
                        }).then((result) => {
                          if (result.isConfirmed) {
                            this.cartService.setEditItem(item);
                            const dialogRef = this.dialog.open(EditDialogComponent);
                            dialogRef.afterClosed().subscribe(result => {
                              if (result) {
                                this.onQuery(item.custEmail);
                              }
                            });
                          }
                          this.totalPrice = 0;
                          this.selectedItems.length = 0;
                          this.isChecked = false;
                          this.allChecked = false;
                          this.onQuery(this.custEmail);
                        });
                      }
                    }
                  }
                }
              }
            });
          });
          isSubmitRs.TRANRS.items.map(itemsInOrder => {
            if (item.serviceId === itemsInOrder.serviceId) {
              if (item.startDate === itemsInOrder.startDate) {
                if (item.endDate === null) {
                  if (item.startTime === itemsInOrder.startTime) {
                    hasWarning = true;
                    Swal.fire({
                      icon: 'warning',
                      title: '<strong>請修改預約日期或預約時間</strong>',
                      html: '<strong>該日期之該時段已無空位</strong>',
                      showCancelButton: true,
                      padding: '3em',
                      color: '#5d3f0a',
                      background: '#fff',
                      confirmButtonText: '<strong>修改</strong>',
                      cancelButtonText: '<strong>取消</strong>',
                      confirmButtonColor: '#ffbd4a'
                    }).then((result) => {
                      if (result.isConfirmed) {
                        this.cartService.setEditItem(item);
                        const dialogRef = this.dialog.open(EditDialogComponent);
                        dialogRef.afterClosed().subscribe(result => {
                          if (result) {
                            this.onQuery(item.custEmail);
                          }
                        });
                      }
                      this.totalPrice = 0;
                      this.selectedItems.length = 0;
                      this.isChecked = false;
                      this.allChecked = false;
                      this.onQuery(this.custEmail);
                    });
                  }
                } else if (item.endDate) {
                  hasWarning = true;
                  Swal.fire({
                    icon: 'warning',
                    title: '<strong>請修改預約日期</strong>',
                    html: '<strong>該日期已無空位</strong>',
                    showCancelButton: true,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonText: '<strong>修改</strong>',
                    cancelButtonText: '<strong>取消</strong>',
                    confirmButtonColor: '#ffbd4a'
                  }).then((result) => {
                    if (result.isConfirmed) {
                      this.cartService.setEditItem(item);
                      const dialogRef = this.dialog.open(EditDialogComponent);
                      dialogRef.afterClosed().subscribe(result => {
                        if (result) {
                          this.onQuery(item.custEmail);
                        }
                      });
                    }
                    this.totalPrice = 0;
                    this.selectedItems.length = 0;
                    this.isChecked = false;
                    this.allChecked = false;
                    this.onQuery(this.custEmail);
                  });
                }
              } else if (item.endDate !== null) {
                if (item.startDate > itemsInOrder.startDate && item.startDate < itemsInOrder.endDate) {
                  hasWarning = true;
                  Swal.fire({
                    icon: 'warning',
                    title: '<strong>請修改預約日期</strong>',
                    html: '<strong>該日期已無空位</strong>',
                    showCancelButton: true,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonText: '<strong>修改</strong>',
                    cancelButtonText: '<strong>取消</strong>',
                    confirmButtonColor: '#ffbd4a'
                  }).then((result) => {
                    if (result.isConfirmed) {
                      this.cartService.setEditItem(item);
                      const dialogRef = this.dialog.open(EditDialogComponent);
                      dialogRef.afterClosed().subscribe(result => {
                        if (result) {
                          this.onQuery(item.custEmail);
                        }
                      });
                    }
                    this.totalPrice = 0;
                    this.selectedItems.length = 0;
                    this.isChecked = false;
                    this.allChecked = false;
                    this.onQuery(this.custEmail);
                  });
                } else if (item.startDate < itemsInOrder.startDate && item.endDate > itemsInOrder.startDate) {
                  hasWarning = true;
                  Swal.fire({
                    icon: 'warning',
                    title: '<strong>請修改預約日期</strong>',
                    html: '<strong>該日期已無空位</strong>',
                    showCancelButton: true,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonText: '<strong>修改</strong>',
                    cancelButtonText: '<strong>取消</strong>',
                    confirmButtonColor: '#ffbd4a'
                  }).then((result) => {
                    if (result.isConfirmed) {
                      this.cartService.setEditItem(item);
                      const dialogRef = this.dialog.open(EditDialogComponent);
                      dialogRef.afterClosed().subscribe(result => {
                        if (result) {
                          this.onQuery(item.custEmail);
                        }
                      });
                    }
                    this.totalPrice = 0;
                    this.selectedItems.length = 0;
                    this.isChecked = false;
                    this.allChecked = false;
                    this.onQuery(this.custEmail);
                  });
                }
              }
            }
          });
          if (!hasWarning) {
            if (!this.isSelected(item)) {
              this.selectedItems.push(item);
              this.totalPrice += parseInt(item.serviceTotalPrice);
            }
          }
          if (this.selectedItems.length === this.dataSource.length) {
            this.allChecked = true;
            console.log('2', this.allChecked);
          }
        });
      } else {
        Swal.fire({
          icon: 'warning',
          title: '<strong>請修改預約日期</strong>',
          html: '<strong>預約日期不得小於今日</strong>',
          showCancelButton: true,
          width: 350,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonText: '<strong>修改</strong>',
          cancelButtonText: '<strong>取消</strong>',
          confirmButtonColor: '#ffbd4a'
        }).then((result) => {
          if (result.isConfirmed) {
            this.cartService.setEditItem(item);
            const dialogRef = this.dialog.open(EditDialogComponent);
            dialogRef.afterClosed().subscribe(result => {
              if (result) {
                this.onQuery(item.custEmail);
              }
            });
          }
          this.totalPrice = 0;
          this.selectedItems.length = 0;
          this.isChecked = false;
          this.allChecked = false;
          this.onQuery(this.custEmail);
        });
      }

    } else {
      const index = this.selectedItems.findIndex(selectedItem => selectedItem.itemId === item.itemId);
      if (index !== -1) {
        this.selectedItems.splice(index, 1);
        this.totalPrice -= parseInt(item.serviceTotalPrice);
        this.allChecked = false;
      }

    }
  }

}
