import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmpDataItems, navLink } from 'src/app/shared/interfaces/EmpElement';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css'],
})
export class EmpComponent implements OnInit {

  /** 員工信箱加密 */
  hashEmail = '';

  /** 員工信箱 */
  email = '';

  /** 員工資料 */
  info = {} as EmpDataItems;

  constructor(
    private empHttpService: EmpHttpService,
    private router: Router
  ) { }

  ngOnInit(): void {
    window.scrollTo(0, 0);
    if (sessionStorage.getItem('hashempuser')) {
      this.hashEmail = sessionStorage.getItem('hashempuser')!;
      this.empHttpService.queryHashEmp(this.hashEmail).subscribe(rs => {
        this.email = rs.TRANRS.email;
        this.onQuery(this.email);
      });
    }
  }

  /** 員工資料查詢 */
  onQuery(email: string) {
    this.empHttpService.queryEmpData(0, 1, email, '', '', '').subscribe((res) => {
      const responseData = res;
      this.info = responseData.TRANRS.items[0];
      if (this.info.isQuit === 'y') {
        this.router.navigate(['/loginemp']);
        Swal.fire({
          icon: 'warning',
          title: '此帳號尚未開通',
          width: 350,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonText: '返回',
        })
      }
    });
  }
}
