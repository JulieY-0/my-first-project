import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { navLink } from 'src/app/shared/interfaces/EmpElement';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmpComponent implements OnInit {

  navLinks: any[];
  // navLinks: navLink[];
  activeLinkIndex = -1;

  constructor(
    private router: Router,
  ) {
    this.navLinks = [
      {
        label: '員工列表',
        link: './empList',
        index: 0
      }, {
        label: '會員列表',
        link: './custList',
        index: 1
      }, {
        label: '預約管理',
        link: './orderList',
        index: 2
      }, {
        label: '建立服務',
        link: './serviceList',
        index: 3
      }, {
        label: 'TEST',
        link: './empTest',
        index: 4
      },
    ];

  }

  ngOnInit(): void {
    window.scrollTo(0, 0);

    this.router.events.subscribe(res => {
      this.activeLinkIndex = this.navLinks.indexOf(this.navLinks.find((tab: { link: string; }) => tab.link === '.' + this.router.url));
    });
  }

}
