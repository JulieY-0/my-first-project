import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DialogComponent } from 'src/app/shared/components/dialog/dialog.component';
import { LoginCustRequest } from 'src/interface/loginCustRequest';
import { UpdateCustomerRequest } from 'src/interface/updateCustomerRequest';
import { MemberService } from 'src/service/member.service';
import Swal from 'sweetalert2';
export interface DialogData {
  custemail: string;
  name: string;
  tel: string;
  sex: string;
  birthday: string;
}
@Component({
  selector: 'app-member-password',
  templateUrl: './member-password.component.html',
  styleUrls: ['./member-password.component.css'],
  providers: [DatePipe]
})


export class MemberPasswordComponent implements OnInit {
  newPassword: string = '';
  birth: string | null = '';
  matchingPasswordValidator(contorl: FormControl): { [s: string]: boolean } {
    if (this.form !== undefined) {
      this.newPassword = this.form.controls.newPassword.value;
    }
    if (contorl.value !== this.newPassword) {
      return { 'passwordNotMatch': true };
    }
    return {};
  }

  hide: boolean = true;
  form = this.fb.nonNullable.group({
    /**檢核必填*/
    oldPassword: ['', [Validators.required, Validators.maxLength(15), Validators.minLength(6), Validators.pattern('.*\\S.*')]],
    newPassword: ['', [Validators.required, Validators.maxLength(15), Validators.minLength(6), Validators.pattern('.*\\S.*')]],
    newPasswordSecond: ['', [Validators.required, Validators.maxLength(15), Validators.minLength(6), Validators.pattern('.*\\S.*'), this.matchingPasswordValidator.bind(this)]]
  });

  /** 是否通過 */
  pass: boolean = false;
  constructor(private fb: FormBuilder,
    public dialogRef: MatDialogRef<DialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private memberService: MemberService,
    private datePipe: DatePipe) { }

  ngOnInit(): void {
  }
  loginCust() {

    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-LOGINCUSTOMER"
      },
      TRANRQ: {
        email: this.data.custemail,
        password: this.form.value.oldPassword
      }
    }
    this.memberService.loginCust(request as LoginCustRequest).subscribe({
      next: (response) => {
        console.log(response);
        if (response.MWHEADER.RETURNCODE == '0000') {
          this.pass = true;
        }
      }
    });
  }

  /** 按下確定修改 */
  updateCust() {

    this.birth = this.datePipe.transform(this.data.birthday, 'yyyy-MM-dd')
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-UPDATECUSTOMER"
      },
      TRANRQ: {
        custEmail: this.data.custemail,
        password: this.form.value.newPassword,
        name: this.data.name,
        tel: this.data.tel,
        sex: this.data.sex,
        birthday: this.birth
      }
    }
    this.memberService.updateCustomer(request as UpdateCustomerRequest).subscribe({
      next: (response) => {
        console.log(response);
        if (response.MWHEADER.RETURNCODE == '0000') {
          Swal.fire({
            position: 'center',
            icon: 'success',
            title: '修改成功',
            showConfirmButton: false,
            timer: 1500
          })
        }
      }
    });

    this.dialogRef.close();

  }

  /** 按下取消按鈕 */
  close() {
    this.dialogRef.close();
  }


}
