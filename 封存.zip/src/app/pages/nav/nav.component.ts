import { LoginService } from 'src/app/services/login.service';
import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { CartService } from 'src/app/core/services/cart.service';
import { Subject, takeUntil, timer } from 'rxjs';
import { MemberService } from 'src/service/member.service';
import { HASHCUSTranrq } from 'src/app/interfaces/hashCusTranrq';
import { OneCustomerRequest } from 'src/interface/oneCustomerRequest';
import { EmpDataItems } from 'src/app/shared/interfaces/EmpElement';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  custemail: string = '';
  countInCart: number = 0;
  memeberName: string = '';

  constructor(
    private router: Router, private cartService: CartService, private memberService: MemberService, private empHttpService: EmpHttpService
  ) { }

  private unsubscribes$ = new Subject<void>();
  private idleTime = 60000;

  //初始值為true
  loginstatus: boolean = true;
  emploginstatus: boolean = true;
  imagePath: string = '';
  /** 員工資料 */
  info = {} as EmpDataItems;
  /** 員工名字 */
  empName: string = '';
  /** 員工信箱 */
  email: string = '';

  @HostListener('document:mousemove', ['$event'])
  @HostListener('document:keypress', ['$event'])
  onUserAction(_event: Event): void {
    this.resetimer()
  }

  ngOnInit(): void {
    //自動登出
    this.resetimer();
    //目前是10秒
    timer(this.idleTime)
      .pipe(takeUntil(this.unsubscribes$)).subscribe(() => {
        if (sessionStorage.getItem('hashuser')) {
          this.logout();
          Swal.fire({
            icon: 'info',
            title: '閒置過久，請重新登入!',
            width: 450,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonText: 'OK',
            confirmButtonColor: '#ffbd4a'
          })
        }
      });

    if (sessionStorage.getItem('nav') === 'login') {
      this.loginstatus = false;
    }
    if (sessionStorage.getItem('nav') === 'emplogin') {
      this.emploginstatus = false;
    }
    if (sessionStorage.getItem('isQuit') === 'y') {
      this.emplogout();
      Swal.fire({
        icon: 'warning',
        title: '帳號已停權',
        width: 450,
        padding: '3em',
        color: '#5d3f0a',
        background: '#fff',
        confirmButtonText: 'OK',
        confirmButtonColor: '#ffbd4a'
      })
    }
    this.cartService.countInCart$.subscribe((count: number) => {
      this.countInCart = count;
    });

    if (sessionStorage.getItem('hashuser')) {
      const hashuser = sessionStorage.getItem('hashuser');
      const request0 = {
        MWHEADER: {
          MSGID: "PAWSOME-HASHCUST"
        },
        TRANRQ: {
          hashEmail: hashuser
        }
      }
      this.memberService.hashCust(request0 as HASHCUSTranrq).subscribe(
        response => {
          this.custemail = response.TRANRS.email;

          /** 基本會員資料*/
          const request = {
            MWHEADER: {
              MSGID: "PAWSOME-ONECUSTOMER"
            },
            TRANRQ: {
              email: this.custemail,
              pageNumber: 0,
              pageSize: 5
            }
          }
          this.memberService.oneCustomer(request as OneCustomerRequest).subscribe(
            response => {
              if (!this.imagePath) {
                this.imagePath = response.TRANRS.imgData;
              }
              this.memeberName = response.TRANRS.items[0].name;
            })


        })
    }

    if (sessionStorage.getItem('hashempuser')) {
      const hashEmpEmail = sessionStorage.getItem('hashempuser')!;
      this.empHttpService.queryHashEmp(hashEmpEmail).subscribe(rs => {
        this.email = rs.TRANRS.email;
        this.onQuery(this.email);
      });
    }
  }

  ngOnDestroy(): void {
    this.unsubscribes$.next();
    this.unsubscribes$.complete();
  }

  resetimer() {
    this.unsubscribes$.next();
  }

  redirectLogin() {
    this.router.navigate(['/login']);
  }

  /** 員工資料查詢 */
  onQuery(email: string) {
    this.empHttpService.queryEmpData(0, 1, email, '', '', '').subscribe((res) => {
      const responseData = res;
      this.info = responseData.TRANRS.items[0];
    });
  }

  // 聯絡資訊
  contact() {
    Swal.fire({
      icon: 'info',
      html: '聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
      width: 450,
      padding: '3em',
      color: '#5d3f0a',
      background: '#fff',
      confirmButtonText: 'OK',
      confirmButtonColor: '#ffbd4a'
      // confirmButtonText: '再試試',
    })
  }
  logout() {
    if (sessionStorage) {
      sessionStorage.clear();
      this.router.navigate(['/']);
      this.loginstatus = true;
      this.cartService.setCountInCart(0);
    }
  }

  emplogout() {
    if (sessionStorage) {
      sessionStorage.clear();
      this.router.navigate(['/loginemp']);
      this.emploginstatus = true;
    }
  }
}
