import { LoginService } from 'src/app/services/login.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { CartService } from 'src/app/core/services/cart.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  countInCart: number = 0;

  constructor(
    private router: Router, private cartService: CartService
  ) { }

  loginstatus: boolean = true;
  emploginstatus: boolean = true;

  ngOnInit(): void {
    if (sessionStorage.getItem('nav') === 'login') {
      this.loginstatus = false;
    }
    if (sessionStorage.getItem('nav') === 'emplogin') {
      this.emploginstatus = false;
    }
    this.cartService.countInCart$.subscribe((count: number) => {
      this.countInCart = count;
    });
  }


  redirectLogin() {
    this.router.navigate(['/login']);
  }

  // 聯絡資訊
  contact() {
    Swal.fire({
      icon: 'info',
      html: '聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
      width: 450,
      padding: '3em',
      color: '#5d3f0a',
      background: '#fff',
      // confirmButtonText: '再試試',
    })
  }
  logout() {
    if (sessionStorage) {
      sessionStorage.clear();
      this.router.navigate(['/']);
      this.loginstatus = true;
      this.cartService.setCountInCart(0);
    }
  }

  emplogout() {
    if (sessionStorage) {
      sessionStorage.clear();
      this.router.navigate(['/']);
      this.emploginstatus = true;
    }
  }
}
