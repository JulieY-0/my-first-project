import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EditShareTranrs } from 'src/app/core/interfaces/editShareTranrs.interface';
import { InsertCartTranrqItems } from 'src/app/core/interfaces/insertCart/insertCartTranrqItems.interface';
import { QueryCartTranrqItems } from 'src/app/core/interfaces/queryCart/queryCartTranrqItems.interface';
import { QueryCartTranrs } from 'src/app/core/interfaces/queryCart/queryCartTranrs.interface';
import { CartService } from 'src/app/core/services/cart.service';
import { PetDatas } from 'src/app/interfaces/pet-datas';
import { ProductsService } from 'src/app/services/products.service';
import { CommCodeItems } from 'src/app/shared/interfaces/EmpElement';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  serviceId = 0;
  serviceName = '';
  brief = '';
  petType = '';
  petSizeRange = '';
  price = '';
  serviceType = '';
  isLogin = false;
  hasPet = false;
  timeOptions = ['08:00-09:00', '09:00-10:00', '10:00-11:00', '11:00-12:00', '13:00-14:00', '14:00-15:00',
    '15:00-16:00', '16:00-17:00', '17:00-18:00', '18:00-19:00', '19:00-20:00', '20:00-21:00', '21:00-22:00'];
  petOptions: string[] = [];
  buttonIsDisable = false;
  // 帶出寵物類型
  petDatas: PetDatas[] = [];
  imageUrl = '';
  tomorrow = new Date();
  maxDate = new Date();
  petId = 0;
  msgCode: CommCodeItems[] = []

  /** 會員信箱 */
  hashEmail = '';
  custEmail = '';
  /** 轉換預約日期為後端要求格式 */
  transformedDate: string | null = '';


  reservationForm = this.fb.nonNullable.group({
    date: [{ value: '', disabled: true }, Validators.required],
    time: ['', Validators.required],
    petName: ['', Validators.required],
    petType: [{ value: '', disabled: true }, Validators.required],
    petSize: [{ value: '', disabled: true }, Validators.required],
    remarks: ['']


  });

  constructor(private fb: FormBuilder, private productsService: ProductsService, private datePipe: DatePipe, private cartService: CartService, private empHttpService: EmpHttpService, private router: Router) { }

  ngOnInit(): void {
    window.scrollTo(0, 0);

    // 從service拿detail資料
    // const datas = this.productsService.serviceDetailResponse.TRANRS.datas[0];
    // API拿圖片
    // this.productsService.postGetImage(datas.serviceId).subscribe(imageResponse => {
    //   if (imageResponse.MWHEADER.RETURNCODE === '0000') {
    //     this.imageUrl = imageResponse.TRANRS;
    //   }
    // })
    // this.serviceId = datas.serviceId;
    // this.serviceType = datas.type;
    // this.serviceName = datas.name;
    // this.brief = datas.brief;
    // this.petType = datas.petType;
    // this.petSizeRange = datas.petSizeRange;
    // this.price = datas.price;

    // 從session拿資料查詢
    this.productsService.postServiceDetailQuery(sessionStorage.getItem('name')).subscribe(response => {
      if (response.MWHEADER.RETURNCODE === '0000') {

        const resData = response.TRANRS.datas[0];
        this.serviceId = resData.serviceId;
        this.serviceType = resData.type;
        this.serviceName = resData.name;
        this.brief = resData.brief;
        this.petType = resData.petType;
        this.petSizeRange = resData.petSizeRange;
        this.price = resData.price;

        this.productsService.postGetImage(this.serviceId).subscribe(imageResponse => {
          if (imageResponse.MWHEADER.RETURNCODE === '0000') {
            this.imageUrl = imageResponse.TRANRS;
          }
        })
      } else {
        Swal.fire({
          icon: 'warning',
          title: '系統發生異常',
          html:
            '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
        })
      }
    })
  }

  // 判斷登入後，展開並取得該會員所有寵物名稱
  verifyLoginAndHasPet() {
    // 判斷登入且有寵物後，展開並取得該會員所有寵物名稱
    if (sessionStorage.getItem('hashuser')) {
      console.log('判斷登入成功');
      this.isLogin = true;
      this.hashEmail = sessionStorage.getItem('hashuser')!;
      this.productsService.postHashCusQuery(this.hashEmail).subscribe(emailRes => {
        if (emailRes.MWHEADER.RETURNCODE === '0000') {
          this.custEmail = emailRes.TRANRS.email;
          // 登入成功且有寵物
          // this.custEmail = sessionStorage.getItem('user')!;
          this.productsService.postPetQuery(this.custEmail).subscribe(response => {
            if (response.MWHEADER.RETURNCODE === '0000') {
              this.hasPet = true;
              this.petDatas = response.TRANRS;
              this.tomorrow.setDate(this.tomorrow.getDate() + 1);
              this.maxDate.setDate(this.tomorrow.getDate() + 31);

              // 立即預約紐鎖住
              this.buttonIsDisable = true;
              // 取得寵物code
              this.empHttpService.queryMsgCode('PET').subscribe(msgRessponse => {
                if (msgRessponse.MWHEADER.RETURNCODE === '0000') {
                  this.msgCode = msgRessponse.TRANRS.items;
                } else {
                  Swal.fire({
                    icon: 'warning',
                    title: '系統發生異常',
                    html:
                      '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
                    width: 450,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                  })
                }
              })
              // 登入成功但沒有寵物
            } else if (response.MWHEADER.RETURNCODE === 'E702') {
              Swal.fire({
                icon: 'warning',
                title: '請新增寵物資訊以利後續預約',
                width: 450,
                padding: '3em',
                color: '#5d3f0a',
                background: '#fff',
              })
              this.router.navigateByUrl('/member');
            } else {
              Swal.fire({
                icon: 'warning',
                title: '系統發生異常',
                html:
                  '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
                width: 450,
                padding: '3em',
                color: '#5d3f0a',
                background: '#fff',

              })
            }
          })
        //登入後沒有拿到解碼的email
        } else {
          Swal.fire({
            icon: 'warning',
            title: '系統發生異常',
            html:
              '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
            width: 450,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',

          })
        }
      })
    } else {
      Swal.fire({
        icon: 'warning',
        title: '請登入以利後續預約',
        width: 450,
        padding: '3em',
        color: '#5d3f0a',
        background: '#fff',
      })
      this.router.navigateByUrl('/login');
    }

  }

  // 選取寵物名稱後觸發帶出寵物細節
  selectedPetName() {
    console.log('有觸發');
    for (const pet of this.petDatas) {
      if (pet.pet_id === parseInt(this.reservationForm.controls.petName.value)) {
        this.petId = pet.pet_id;
        this.reservationForm.controls.petType.patchValue(this.codeToPetType(pet.type));
        this.reservationForm.controls.petSize.patchValue(pet.weight);
      }
    }
  }

  insertCart() {
    //轉換日期格式yyyy-MM-dd
    this.transformedDate = this.datePipe.transform(this.reservationForm.controls.date.value, 'yyyy-MM-dd');
    const input: InsertCartTranrqItems = {
      custEmail: this.custEmail,
      serviceId: this.serviceId,
      startDate: this.transformedDate,
      endDate: '',
      startTime: this.reservationForm.controls.time.value,
      petId: this.petId,
      remarks: this.reservationForm.controls.remarks.value,
      isSubmit: 'n'
    }
    this.cartService.insert(input).subscribe((rs: EditShareTranrs) => {
      const returnCode = rs.MWHEADER.RETURNCODE;
      if (returnCode === '0000') {
        Swal.fire({
          icon: 'success',
          title: '加入購物車成功',
          width: 350,
          padding: '3em',
          background: '#fff',
        });
        const input: QueryCartTranrqItems = {
          custEmail: this.custEmail,
          isSubmit: 'n'
        };
        this.cartService.query(input).subscribe((rs: QueryCartTranrs) => {
          const returnCode = rs.MWHEADER.RETURNCODE;
          if (returnCode === '0000') {
            this.cartService.setCountInCart(rs.TRANRS.totalCount);
          }
        });
      } else if (returnCode === 'E001') {
        Swal.fire({
          icon: 'warning',
          title: '必填欄位不得為空',
          width: 350,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonText: '確認',
        });
      } else if (returnCode === 'E703') {
        Swal.fire({
          icon: 'warning',
          title: '購物車已有相同時間之服務',
          width: 350,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonText: '確認',
        });
      } else if (returnCode === 'E003') {
        Swal.fire({
          icon: 'error',
          title: '加入購物車失敗',
          width: 350,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonText: '再試試',
        });
      } else {
        Swal.fire({
          icon: 'warning',
          title: '其他系統異常',
          width: 350,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonText: '再試試',
        });
      }
    });
  }

  lastPage() {
    if (this.serviceType === '寵物保姆') {
      this.router.navigateByUrl('/nanny');
    } else {
      this.router.navigateByUrl('/grooming');
    }
  }

  // 轉換code得出寵物類型
  codeToPetType(code: string) {
    for (const msgCode of this.msgCode) {
      // 數字
      if (code === msgCode.commCode) {
        return msgCode.msg;
      }
    } return code;
  }


}
