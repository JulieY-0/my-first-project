import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EditShareTranrs } from 'src/app/core/interfaces/editShareTranrs.interface';
import { InsertCartTranrqItems } from 'src/app/core/interfaces/insertCart/insertCartTranrqItems.interface';
import { QueryCartTranrqItems } from 'src/app/core/interfaces/queryCart/queryCartTranrqItems.interface';
import { QueryCartTranrs } from 'src/app/core/interfaces/queryCart/queryCartTranrs.interface';
import { CartService } from 'src/app/core/services/cart.service';
import { PetDatas } from 'src/app/interfaces/pet-datas';
import { ProductsService } from 'src/app/services/products.service';
import { CommCodeItems } from 'src/app/shared/interfaces/EmpElement';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  /** 服務ID */
  serviceId = 0;

  /** 服務名稱 */
  serviceName = '';

  /** 服務簡介 */
  brief = '';

  /** 寵物類別 */
  petType = '';

  /** 寵物體重限制 */
  petSizeRange = '';

  /** 服務價格 */
  price = '';

  /** 服務類別 */
  serviceType = '';

  /** 登入與否 */
  isLogin = false;

  /** 是否擁有寵物 */
  hasPet = false;

  /** 預約時間選項 */
  timeOptions = ['08:00-09:00', '09:00-10:00', '10:00-11:00', '11:00-12:00', '13:00-14:00', '14:00-15:00',
    '15:00-16:00', '16:00-17:00', '17:00-18:00', '18:00-19:00', '19:00-20:00', '20:00-21:00', '21:00-22:00'];

  /** 寵物選項 */
  petOptions: string[] = [];

  /** 立即預約按鈕Disable */
  resvBtnDisable = false;

  /** 寵物類別、體重資訊 */
  petDatas: PetDatas[] = [];

  /** 商品圖片 */
  imageUrl = '';

  /** 明天日期 */
  tomorrow = new Date();

  /** 最大可預約日 */
  maxDate = new Date();

  /** 寵物ID */
  petId = 0;

  /** 共同code資料 */
  msgCode: CommCodeItems[] = []

  /** 會員信箱 */
  hashEmail: string | null = '';

  /** 加密信箱 */
  custEmail = '';

  /** 轉換預約日期為後端要求格式 */
  transformedDate: string | null = '';

  /* 購物車item數量 */
  countInCart: number | string = 0;

  /** 立即預約按鈕出現與否 */
  reservBtnExsit = true;

  /** 建構表格 */
  reservationForm = this.fb.nonNullable.group({
    date: ['', Validators.required],
    time: ['', Validators.required],
    petName: ['', Validators.required],
    petType: [{ value: '', disabled: true }, Validators.required],
    petSize: [{ value: '', disabled: true }, Validators.required],
    remarks: ['']


  });

  /**
   * Creates an instance of ProductComponent.
   * @param {FormBuilder} fb
   * @param {ProductsService} productsService
   * @param {DatePipe} datePipe
   * @param {CartService} cartService
   * @param {EmpHttpService} empHttpService
   * @param {Router} router
   * @memberof ProductComponent
   */
  constructor(private fb: FormBuilder, private productsService: ProductsService, private datePipe: DatePipe,
    private cartService: CartService, private empHttpService: EmpHttpService, private router: Router) { }

  ngOnInit(): void {
    window.scrollTo(0, 0);

    // 購物車紅標
    this.hashEmail = sessionStorage.getItem('hashuser');
    if (this.hashEmail) {
      this.cartService.queryHashCus(this.hashEmail).subscribe(rs => {
        this.custEmail = rs.TRANRS.email;
        const input: QueryCartTranrqItems = {
          custEmail: this.custEmail,
          isSubmit: 'n'
        };
        this.cartService.query(input).subscribe((rs: QueryCartTranrs) => {
          const returnCode = rs.MWHEADER.RETURNCODE;
          if (returnCode === '0000') {
            this.countInCart = rs.TRANRS.totalCount;
            this.cartService.setCountInCart(this.countInCart);
          }
        });
      });
    }
    // 取得服務詳細資料
    this.productsService.postServiceDetailQuery(sessionStorage.getItem('name')).subscribe(response => {
      if (response.MWHEADER.RETURNCODE === '0000') {

        const resData = response.TRANRS.datas[0];
        this.serviceId = resData.serviceId;
        this.serviceType = resData.type;
        this.serviceName = resData.name;
        this.brief = resData.brief;
        this.petType = resData.petType;
        this.petSizeRange = resData.petSizeRange;
        this.price = resData.price;

        this.productsService.postGetImage(this.serviceId).subscribe(imageResponse => {
          if (imageResponse.MWHEADER.RETURNCODE === '0000') {
            this.imageUrl = imageResponse.TRANRS;
          }
        })
      } else {
        Swal.fire({
          icon: 'warning',
          title: '系統發生異常',
          html:
            '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonColor: '#ffbd4a'
        })
      }
    })
    // 判斷是否為員工，決定是否顯示立即預約按鈕
    if (sessionStorage.getItem('isQuit')) {
      this.reservBtnExsit = false;
    }
  }

  /**
   *
   *判斷登入且有無寵物，並取得該會員所有服務資格的寵物名稱
   * @memberof ProductComponent
   */
  verifyLoginAndHasPet() {
    if (sessionStorage.getItem('hashuser')) {
      console.log('判斷登入成功');
      this.isLogin = true;
      this.hashEmail = sessionStorage.getItem('hashuser')!;
      this.cartService.queryHashCus(this.hashEmail).subscribe(emailRes => {
        if (emailRes.MWHEADER.RETURNCODE === '0000') {
          this.custEmail = emailRes.TRANRS.email;
          // 登入成功且有寵物
          this.productsService.postPetQuery(this.custEmail).subscribe(response => {
            if (response.MWHEADER.RETURNCODE === '0000') {
              this.hasPet = true;
              this.petDatas = response.TRANRS;
              console.log(response);
              // 過濾寵物類型及體重
              if (this.petType === '狗狗') {
                this.petDatas = this.petDatas.filter((pet) => pet.type === '2' && +pet.weight <= +this.petSizeRange);
                console.log(this.petDatas);
                console.log('狗');

              } else if (this.petType === '貓貓') {
                this.petDatas = this.petDatas.filter((pet) => pet.type === '1' && +pet.weight <= +this.petSizeRange);
                console.log(this.petDatas);
                console.log('貓');
              } else {
                this.petDatas = this.petDatas.filter((pet) => +pet.weight <= +this.petSizeRange);
                console.log(this.petDatas);
                console.log('體重');
              }
              // 篩選後就沒有寵物的話
              if (this.petDatas.length === 0) {
                this.hasPet = false;
                Swal.fire({
                  icon: 'warning',
                  title: '您未有不超過' + this.petSizeRange + '公斤的' + this.petType,
                  html: '請至<a href="http://localhost:4200/member">會員專區</a></br>修改或新增該類型毛孩以利後續預約',
                  width: 450,
                  padding: '3em',
                  color: '#5d3f0a',
                  background: '#fff',
                  confirmButtonColor: '#ffbd4a'
                })
              } else {
                this.tomorrow.setDate(this.tomorrow.getDate() + 1);
                this.maxDate.setDate(this.tomorrow.getDate() + 31);
                // 立即預約紐鎖住
                this.resvBtnDisable = true;
                // 取得寵物code
                this.empHttpService.queryMsgCode('PET').subscribe(msgRessponse => {
                  if (msgRessponse.MWHEADER.RETURNCODE === '0000') {
                    this.msgCode = msgRessponse.TRANRS.items;
                  } else {
                    Swal.fire({
                      icon: 'warning',
                      title: '系統發生異常',
                      html:
                        '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
                      width: 450,
                      padding: '3em',
                      color: '#5d3f0a',
                      background: '#fff',
                      confirmButtonColor: '#ffbd4a'
                    })
                  }
                })
              }
              // 登入成功但沒有寵物
            } else if (response.MWHEADER.RETURNCODE === 'E702') {
              Swal.fire({
                icon: 'warning',
                title: '請新增寵物資訊以利後續預約',
                width: 450,
                padding: '3em',
                color: '#5d3f0a',
                background: '#fff',
                confirmButtonColor: '#ffbd4a'
              })
              this.router.navigateByUrl('/member');
            } else {
              Swal.fire({
                icon: 'warning',
                title: '系統發生異常',
                html:
                  '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
                width: 450,
                padding: '3em',
                color: '#5d3f0a',
                background: '#fff',
                confirmButtonColor: '#ffbd4a'

              })
            }
          })
          //登入後沒有拿到解碼的email
        } else {
          Swal.fire({
            icon: 'warning',
            title: '系統發生異常',
            html:
              '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
            width: 450,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonColor: '#ffbd4a'

          })
        }
      })
      // 未登入
    } else {
      Swal.fire({
        icon: 'warning',
        title: '請登入以利後續預約',
        width: 450,
        padding: '3em',
        color: '#5d3f0a',
        background: '#fff',
        confirmButtonColor: '#ffbd4a'
      })
      this.router.navigateByUrl('/login');
    }

  }
  /**
   *
   *選取寵物名稱後帶出寵物類型及體重
   * @memberof ProductComponent
   */
  selectedPetName() {
    console.log('有觸發');
    for (const pet of this.petDatas) {
      if (pet.pet_id === parseInt(this.reservationForm.controls.petName.value)) {
        this.petId = pet.pet_id;
        this.reservationForm.controls.petType.patchValue(this.codeToPetType(pet.type));
        this.reservationForm.controls.petSize.patchValue(pet.weight);
      }
    }
  }


  /**
   *
   *加入購物車
   * @memberof ProductComponent
   */
  insertCart() {
    //轉換日期格式yyyy-MM-dd
    this.transformedDate = this.datePipe.transform(this.reservationForm.controls.date.value, 'yyyy-MM-dd');
    const input: InsertCartTranrqItems = {
      custEmail: this.custEmail,
      serviceId: this.serviceId,
      startDate: this.transformedDate,
      endDate: '',
      startTime: this.reservationForm.controls.time.value,
      petId: this.petId,
      remarks: this.reservationForm.controls.remarks.value,
      isSubmit: 'n'
    };
    const isSubmit: string = 'y';
    let hasWarning: boolean = false;
    this.cartService.queryCartIsSubmit(isSubmit).subscribe(isSubmitRs => {
      isSubmitRs.TRANRS.items.map(itemsInOrder => {
        if (input.serviceId === itemsInOrder.serviceId) { //是否與訂單中相同服務
          if (input.startDate === itemsInOrder.startDate) { //是否與訂單中相同預約日
            if (input.startTime === itemsInOrder.startTime) { //是否與訂單中相同時間
              hasWarning = true;
              Swal.fire({
                icon: 'warning',
                title: '<strong>請修改預約日期或預約時間</strong>',
                html: '<strong>該日期之該時段已無空位</strong>',
                padding: '3em',
                color: '#5d3f0a',
                background: '#fff',
                confirmButtonText: '確認',
                confirmButtonColor: '#ffbd4a'
              });
            }
          }
        }
      });
      if (!hasWarning) {
        this.cartService.insert(input).subscribe((rs: EditShareTranrs) => {
          const returnCode = rs.MWHEADER.RETURNCODE;
          if (returnCode === '0000') {
            Swal.fire({
              icon: 'success',
              title: '<strong>加入購物車成功</strong>',
              width: 350,
              padding: '3em',
              background: '#fff',
              confirmButtonText: '<strong>確認</strong>',
              confirmButtonColor: '#ffbd4a'
            });
            const input: QueryCartTranrqItems = {
              custEmail: this.custEmail,
              isSubmit: 'n'
            };
            this.cartService.query(input).subscribe((rs: QueryCartTranrs) => {
              const returnCode = rs.MWHEADER.RETURNCODE;
              if (returnCode === '0000') {
                this.cartService.setCountInCart(rs.TRANRS.totalCount);
              }
            });
          } else if (returnCode === 'E001') {
            Swal.fire({
              icon: 'warning',
              title: '<strong>必填欄位不得為空</strong>',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '<strong>確認</strong>',
              confirmButtonColor: '#ffbd4a'
            });
          } else if (returnCode === 'E703') { //與購物車相同服務、日期、時間
            Swal.fire({
              icon: 'warning',
              title: '<strong>請修改預約日期或預約時間</strong>',
              html: '<strong>購物車已有相同時間之服務</strong>',
              width: 500,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '<strong>確認</strong>',
              confirmButtonColor: '#ffbd4a'
            });
          } else if (returnCode === 'E003') {
            Swal.fire({
              icon: 'error',
              title: '<strong>加入購物車失敗</strong>',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '<strong>再試試</strong>',
              confirmButtonColor: '#ffbd4a'
            });
          } else {
            Swal.fire({
              icon: 'warning',
              title: '<strong>其他系統異常</strong>',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '<strong>再試試</strong>',
              confirmButtonColor: '#ffbd4a'
            });
          }
        });
      }
    });
  }

  /**
   *
   *返回上一頁
   * @memberof ProductComponent
   */
  lastPage() {
    if (this.serviceType === '寵物保姆') {
      this.router.navigateByUrl('/nanny');
    } else {
      this.router.navigateByUrl('/grooming');
    }
  }
  /**
   *
   *轉換共通code得出寵物類型
   * @param {string} code
   * @return {*}
   * @memberof ProductComponent
   */
  codeToPetType(code: string) {
    for (const msgCode of this.msgCode) {
      // 數字
      if (code === msgCode.commCode) {
        return msgCode.msg;
      }
    } return code;
  }


}
