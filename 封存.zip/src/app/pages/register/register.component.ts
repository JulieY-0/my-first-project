import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatNativeDateModule } from '@angular/material/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { insertdata } from 'src/app/core/interface/login';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';
import * as moment from 'moment';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  responseData: any = {};
  hide: boolean = true;
  password: string = '';
  hideconfirm: boolean = true;
  mintDate = moment('1993-1-1');
  maxDate = moment(new Date());

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private loginService: LoginService,
  ) { }

  form = this.fb.nonNullable.group({
    /**檢核必填*/
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(15), Validators.pattern('.*\\S.*')]],
    confirmpassword: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(15), this.matchingPasswordValidator.bind(this)]],
    name: ['', [Validators.required, Validators.pattern('.*\\S.*'), Validators.maxLength(15)]],
    tel: ['', [Validators.required, Validators.maxLength(15), Validators.pattern('^[0-9]*$'), Validators.pattern('.*\\S.*')]],
    sex: '',
    birthday: '',
  });

  ngOnInit(): void {
    // 帶入登入頁未註冊帳號
    this.form.controls.email.patchValue(sessionStorage['registerEmail']);
    if (!sessionStorage.getItem('page')) {
      sessionStorage.setItem('page', 'reg');
    }
  }

  matchingPasswordValidator(contorl: FormControl): { [s: string]: boolean } {
    if (this.form !== undefined) {
      this.password = this.form.controls.password.value;
    }
    if (contorl.value !== this.password) {
      return { 'passwordNotMatch': true };
    }
    return {};
  }

  test() {
    this.form.controls.email.patchValue('cust@gmail.com');
    this.form.controls.password.patchValue('cust1111');
    this.form.controls.confirmpassword.patchValue('cust1111');
    this.form.controls.name.patchValue('cust');
    this.form.controls.tel.patchValue('0900000096');
  }

  insert() {
    const data: insertdata = {
      email: this.form.controls.email.value,
      password: this.form.controls.password.value,
      name: this.form.controls.name.value,
      tel: this.form.controls.tel.value,
      sex: this.form.controls.sex.value,
      //目前是Sun Oct 22 2023 00:00:00 GMT+0800 (台北標準時間)後端會調整成2020-11-11
      birthday: this.form.controls.birthday.value,
      confirmpassword: this.form.controls.confirmpassword.value,
    };

    this.loginService.insert(data).subscribe({
      next: (response) => {
        console.log(response)
        console.log(this.form.controls.birthday.value)
        if (response) {
          this.responseData = response;
          //已註冊過
          if (this.responseData.MWHEADER.RETURNCODE === 'E003') {
            Swal.fire({
              icon: 'warning',
              title: '此帳號已註冊',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '返回',
              confirmButtonColor:'#ffbd4a',
              footer: '<a href="login">前往登入</a>'
            })
          }
          //註冊成功
          if (this.responseData.MWHEADER.RETURNCODE === '0000') {
            sessionStorage.removeItem('registerEmail');
            Swal.fire({
              icon: 'success',
              title: '註冊成功',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '請先登入',
              confirmButtonColor:'#ffbd4a',
            })
            this.router.navigate(['/login']);
          }
          if (this.responseData.MWHEADER.RETURNCODE === 'E001') {
            Swal.fire({
              icon: 'error',
              title: '欄位格式錯誤',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '重新註冊',
              confirmButtonColor:'#ffbd4a',
            })
          }
          if (this.form.controls.password.value.length < 6 || this.form.controls.confirmpassword.value.length < 6) {
            Swal.fire({
              icon: 'error',
              title: '密碼不能小於6位',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '重新註冊',
              confirmButtonColor:'#ffbd4a',
            })
          }
          if (this.form.controls.password.value.length > 15 || this.form.controls.confirmpassword.value.length > 15) {
            Swal.fire({
              icon: 'error',
              title: '密碼不能大於15位',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '重新註冊',
              confirmButtonColor:'#ffbd4a',
            })
          }
          if (this.form.controls.password.value !== this.form.controls.confirmpassword.value) {
            Swal.fire({
              icon: 'error',
              title: '確認密碼與密碼不同',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '重新註冊',
              confirmButtonColor:'#ffbd4a',
            })
          }
        }
      },
      error: (err) => {
        console.log('err', err);
      }
    });






  }

}
