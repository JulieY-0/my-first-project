import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Cards } from 'src/app/interfaces/cards';
import { ProductsService } from 'src/app/services/products.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { CartService } from 'src/app/core/services/cart.service';
import { QueryCartTranrqItems } from 'src/app/core/interfaces/queryCart/queryCartTranrqItems.interface';
import { QueryCartTranrs } from 'src/app/core/interfaces/queryCart/queryCartTranrs.interface';
import { MemberService } from 'src/service/member.service';
import { ServiceDetailRequest } from 'src/interface/ServiceDetailRequest';
import { HASHCUSTranrq } from 'src/app/interfaces/hashCusTranrq';
import { InsertFavoriteRequest } from 'src/interface/insertFavoriteRequest';

@Component({
  selector: 'app-grooming',
  templateUrl: './grooming.component.html',
  styleUrls: ['./grooming.component.css']
})
export class GroomingComponent implements OnInit {
  /* 服務內容 */
  items: Cards[] = [];

  /* 全部服務內容 */
  allItems: Cards[] = [];

  /* 搜尋框建議選項 */
  options: string[] = ['洗澡', '護毛', '指甲'];

  /* 查無資料 */
  dataNotFound = false;

  /* 加密信箱 */
  hashEmail: string | null = '';

  /* 會員信箱 */
  custEmail: string = '';

  /* 購物車item數量 */
  countInCart: number | string = 0;

  /* 建構表格 */
  form = this.fb.nonNullable.group({
    search: ['']
  });

  /** 服務Id */
  serviceId: number = 0;

  /** 為了裝hashUser */
  hashuser = sessionStorage.getItem("hashuser");

  /**
   * Creates an instance of GroomingComponent.
   * @param {FormBuilder} fb
   * @param {ProductsService} productsService
   * @param {CartService} cartService
   * @param {MatDialog} dialog
   * @param {Router} router
   * @memberof GroomingComponent
   */
  constructor(private fb: FormBuilder, private productsService: ProductsService, private cartService: CartService,
    public dialog: MatDialog, private router: Router, private memberService: MemberService) { }


  ngOnInit(): void {
    window.scrollTo(0, 0);

    // 購物車紅標
    this.hashEmail = sessionStorage.getItem('hashuser');
    if (this.hashEmail) {
      this.cartService.queryHashCus(this.hashEmail).subscribe(rs => {
        this.custEmail = rs.TRANRS.email;
        const input: QueryCartTranrqItems = {
          custEmail: this.custEmail,
          isSubmit: 'n'
        };
        this.cartService.query(input).subscribe((rs: QueryCartTranrs) => {
          const returnCode = rs.MWHEADER.RETURNCODE;
          if (returnCode === '0000') {
            this.countInCart = rs.TRANRS.totalCount;
            this.cartService.setCountInCart(this.countInCart);
          }
        });
      });
    }
    // 查詢類別下服務內容
    this.productsService.postServiceQuery('寵物美容').subscribe(response => {
      if (response.MWHEADER.RETURNCODE === '0000') {
        this.dataNotFound = false;
        const serviceArray = response.TRANRS.TRANRS;
        for (const service of serviceArray) {
          // service.name
          // service.serviceId
          console.log(service.name);

          // 取得圖片
          this.productsService.postGetImage(service.serviceId).subscribe(imageResponse => {
            if (imageResponse.MWHEADER.RETURNCODE === '0000') {
              const object = { imageUrl: imageResponse.TRANRS, name: service.name };
              this.items.push(object);
              console.log(this.items);
              this.allItems = this.items;
            }
          })
        }
      } else if (response.MWHEADER.RETURNCODE === 'E702') {
        this.dataNotFound = true;
      } else {
        Swal.fire({
          icon: 'warning',
          title: '系統發生異常',
          html:
            '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonColor: '#ffbd4a'
        })
      }
    })
  }

  /**
   *搜尋服務
   * @memberof GroomingComponent
   */
  queryService() {
    this.items = [];
    const searchName = this.form.controls.search.value;
    if (!searchName) {
      this.items = this.allItems;
    } else {
      this.productsService.postOneServiceQuery(searchName,'寵物美容').subscribe(response => {
        // 查無資料
        if (response.MWHEADER.RETURNCODE === 'E702') {
          this.dataNotFound = true;
        } else if (response.MWHEADER.RETURNCODE === '0000') {
          this.dataNotFound = false;
          const serviceArray = response.TRANRS.datas;
          for (const service of serviceArray) {
            console.log(service.name);

            // 打圖片API
            this.productsService.postGetImage(service.serviceId).subscribe(imageResponse => {
              if (imageResponse.MWHEADER.RETURNCODE === '0000') {
                const object = { imageUrl: imageResponse.TRANRS, name: service.name };
                this.items.push(object);
                console.log(this.items);
              }
            })
          }
        } else {
          Swal.fire({
            icon: 'warning',
            title: '系統發生異常',
            html:
              '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
            width: 450,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonColor: '#ffbd4a'
          })
        }
      })
    }
  }

  queryAllService() {
    if (this.allItems.length !== 0) {
      this.dataNotFound = false;
      this.items = this.allItems;
    }

    this.form.controls.search.patchValue('');
  }

  /**
   *
   *取得服務詳細資料，存sessionStorage
   * @param {string} serviceName
   * @memberof GroomingComponent
   */
  sendServiceDetail(serviceName: string) {
    this.productsService.postServiceDetailQuery(serviceName).subscribe(response => {
      if (response.MWHEADER.RETURNCODE === '0000') {
        sessionStorage.setItem('name', response.TRANRS.datas[0].name);
        this.router.navigate(['/product']);
      } else if (response.MWHEADER.RETURNCODE === '9999' || response.MWHEADER.RETURNCODE === 'E702') {
        Swal.fire({
          icon: 'warning',
          title: '系統發生異常',
          html:
            '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonColor: '#ffbd4a'
        })
      }
    })
  }

  /** Julie的我的收藏部分功能 */
  favorite(serviceName: string) {
    if (sessionStorage.getItem('hashuser')) {
      console.log('判斷登入成功');
      /** 先拿到 ServiceName/ serviceId/ CustEmail 存到DB裡面*/
      /** 先打一支serviceDetail 去拿到 ServiceId */
      /** 同時從session Storage 裡面拿CustEmail*/
      const request = {
        MWHEADER: {
          MSGID: "PAWSOME-SERVICEDETAIL"
        },
        TRANRQ: {
          name: serviceName
        }
      }
      console.log(request);

      this.memberService.serviceDetail(request as ServiceDetailRequest).subscribe({
        next: (response) => {
          this.serviceId = response.TRANRS.datas[0].serviceId
          /** 先拿到custemail */
          const request0 = {
            MWHEADER: {
              MSGID: "PAWSOME-HASHCUST"
            },
            TRANRQ: {
              hashEmail: this.hashuser
            }
          }
          console.log(request0);

          this.memberService.hashCust(request0 as HASHCUSTranrq).subscribe(
            response => {
              console.log(response.TRANRS.email);
              this.custEmail = response.TRANRS.email;

              /** 一起打一支insertFavorite進去DB*/
              const request1 = {
                MWHEADER: {
                  MSGID: "PAWSOME-INSERTFAVORITE"
                },
                TRANRQ: {
                  custEmail: this.custEmail,
                  serviceId: this.serviceId,
                  serviceName: serviceName
                }
              }
              this.memberService.insetFavorite(request1 as InsertFavoriteRequest).subscribe(
                response1 => {
                  console.log(response1);
                  const returnCode = response1.MWHEADER.RETURNCODE;
                  if (returnCode === '0000') {
                    Swal.fire('收藏成功!', '', 'success');
                  }
                  if (returnCode === 'E703') {
                    Swal.fire('收藏裡已經有囉');
                  }

                }
              );
            })
        }
      })

    } else {
      Swal.fire({
        icon: 'warning',
        title: '請登入以利後續預約',
        width: 450,
        padding: '3em',
        color: '#5d3f0a',
        background: '#fff',
      })
      this.router.navigateByUrl('/login');
    }

  }




}
