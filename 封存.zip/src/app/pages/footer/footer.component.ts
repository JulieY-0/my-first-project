import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  constructor(
    private router: Router,
  ) { }

  ngOnInit(): void {
  }

  // 聯絡資訊
  contact() {
    Swal.fire({
      icon: 'info',
      html: '聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
      width: 450,
      padding: '3em',
      color: '#5d3f0a',
      background: '#fff',
      // confirmButtonText: '再試試',
    })
  }

  login() {
    if (sessionStorage.getItem('nav') === 'emplogin') {
      Swal.fire({
        icon: 'warning',
        title: '已登入',
        width: 350,
        padding: '3em',
        background: '#fff',
      })
    } else if (sessionStorage.getItem('nav') === 'login') {
      Swal.fire({
        icon: 'warning',
        title: '請先進行會員登出',
        width: 350,
        padding: '3em',
        background: '#fff',
      })
    } else {
      this.router.navigate(['/loginemp'])
    }
  }

}
