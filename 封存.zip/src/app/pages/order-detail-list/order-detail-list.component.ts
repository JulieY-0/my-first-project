import { DatePipe } from '@angular/common';
import {
  Component,
  OnInit,
  ViewChild,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { Customer, Order, OrderDetail, UpdateOrderDataTranrq } from 'src/app/shared/interfaces/EmpElement';
import { EmpDataService } from 'src/app/shared/service/emp-data.service';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import Swal from 'sweetalert2';
import { OrderDetailEditComponent } from '../order-detail-edit/order-detail-edit.component';
import { Router } from '@angular/router';
import { combineLatest } from 'rxjs';

@Component({
  selector: 'app-order-detail-list',
  templateUrl: './order-detail-list.component.html',
  styleUrls: ['./order-detail-list.component.css'],
  providers: [DatePipe],
})
export class OrderDetailListComponent implements OnInit {

  /**
   * 分頁
   * @type {MatPaginator}
   * @memberof OrderListComponent
   */
  @ViewChild('paginator', { static: true }) paginator!: MatPaginator;

  /** 資料總筆數 */
  length = 0;

  /** 目前頁碼 預設為0 */
  pageIndex = 0;

  /** 每頁呈現幾筆 預設為5 */
  pageSize = 5;

  /** 總頁數 */
  totalPage: number | undefined;

  /** 允許切換的每頁資料筆數 */
  pageSizeOptions = [5, 10];

  /** 分頁結果 */
  pageEvent: PageEvent | undefined;

  /** 欲修改之訂單編號 */
  selectOrderId: string | undefined;

  /** 欲修改之訂單 */
  selectOrder = {} as Order;

  /** 欲修改之訂單總金額 */
  selectTotal = 0;

  /** 會員信箱 */
  selectCustEmail: string | undefined;

  /** 會員資料 */
  selectCustomer = {} as Customer;

  /** 訂單資訊 */
  order = {} as UpdateOrderDataTranrq;

  /** 欄位名稱 */
  displayedColumns = [
    'serviceName',
    'startDate',
    'endDate',
    'startTime',
    'petName',
    'petType',
    'remarks',
    'price',
    'orderProcess',
    'updateEmp',
    'updateTime',
    'edit',
  ];

  /** 表格資料 */
  dataSource: OrderDetail[] = [];

  constructor(
    private empHttpService: EmpHttpService,
    public dialog: MatDialog,
    public router: Router
  ) { }

  ngOnInit(): void {
    window.scrollTo(0, 0);

    // 訂單資訊
    this.selectOrderId = sessionStorage.getItem('orderId')!;
    this.selectCustEmail = sessionStorage.getItem('custEmail')!;
    this.empHttpService
      .queryOrderById(0, 1, this.selectOrderId)
      .subscribe((res) => {
        const responseData = res;
        this.selectOrder = responseData.TRANRS.items[0];
        this.selectTotal = Number(this.selectOrder.total);
      });

    // 訂購人資訊
    this.empHttpService
      .queryCustByEmailData(0, 1, this.selectCustEmail)
      .subscribe((res) => {
        const responseData = res;
        this.selectCustomer = responseData.TRANRS.items[0];
      });

    this.queryOrderDetail();
  }

  /**
   * 分頁器
   * @param event
   */
  getPaginatorData(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.queryPageDatabtn(this.pageIndex, this.pageSize);
  }

  /** 查詢按鈕 */
  queryOrderDetail() {
    this.pageIndex = 0;
    this.empHttpService
      .queryOrderDetail(0, this.pageSize, this.selectOrderId as string)
      .subscribe((res) => {
        const responseData = res;

        if (responseData.MWHEADER.RETURNCODE !== '0000') {
          Swal.fire({
            icon: 'error',
            title: '查詢失敗',
            text: responseData.MWHEADER.RETURNDESC,
            width: 350,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonText: '確定',
          });
          return;
        }

        this.length = responseData.TRANRS.totalCount;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as OrderDetail[];
        this.dataSource = this.dataSource.map<OrderDetail>((e) => ({
          ...e,
        }));
      });
  }

  /**
   * 分頁查詢按鈕
   * @param pageIndex
   * @param pageSize
   */
  queryPageDatabtn(pageIndex: number, pageSize: number) {
    this.empHttpService
      .queryOrderDetail(pageIndex, pageSize, this.selectOrderId as string)
      .subscribe((res) => {
        const responseData = res;

        this.length = responseData.TRANRS.totalCount;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as OrderDetail[];
        this.dataSource = this.dataSource.map<OrderDetail>((e) => ({
          ...e,
        }));
      });
  }

  /** 開啟修改彈窗 */
  openEditDialog(i: number) {
    sessionStorage.setItem('itemId', this.dataSource[i].itemId);
    const dialogRef = this.dialog.open(OrderDetailEditComponent, {
      width: '55%',
    });

    dialogRef.afterClosed().subscribe(() => {
      this.queryPageDatabtn(this.pageIndex, this.pageSize);

      // 重查訂單資訊
      this.empHttpService
        .queryOrderById(0, 1, this.selectOrderId)
        .subscribe((res) => {
          const responseData = res;
          this.selectOrder = responseData.TRANRS.items[0];
          this.selectTotal = Number(this.selectOrder.total);
        });
    });
  }

  /** 回上一頁至訂單管理 */
  backToOrder() {
    this.router.navigate(['/empPawsome/orderList']);
    //TODO 導回修改那筆
    sessionStorage.setItem('orderId', this.selectOrderId!);
  }

  /** 取消訂單 修改訂單狀態 */
  cancelOrder() {
    Swal.fire({
      title: '您確定要取消這筆訂單?',
      showCancelButton: true,
      confirmButtonText: '確定',
      cancelButtonText: '取消',
      customClass: {
        actions: 'my-actions',
        cancelButton: 'order-1',
        confirmButton: 'order-2',
      },
      width: 350,
      padding: '3em',
      color: '#5d3f0a',
      background: '#fff',
    }).then((result) => {
      if (result.isConfirmed) {
        this.empHttpService.queryOrderById(0, 1, this.selectOrderId).subscribe({
          next: (res) => {
            this.order = res.TRANRS.items[0];
          },
          complete: () => {
            const updaterq = {
              ...this.order,
              orderProcess: '3',
            } as UpdateOrderDataTranrq;

            this.empHttpService.editOrderData(updaterq).subscribe((res) => {
              const responseData = res;
              // 修改失敗跳出提示訊息
              if (responseData.MWHEADER.RETURNCODE !== '0000') {
                Swal.fire({
                  icon: 'error',
                  title: '取消失敗',
                  text: responseData.MWHEADER.RETURNDESC,
                  width: 350,
                  padding: '3em',
                  color: '#5d3f0a',
                  background: '#fff',
                  confirmButtonText: '確定',
                });
                return;
              }

              // 修改成功跳出提示訊息
              if (responseData.MWHEADER.RETURNCODE === '0000') {
                Swal.fire({
                  icon: 'success',
                  title: '取消成功',
                  width: 350,
                  padding: '3em',
                  background: '#fff',
                });

                // 重查訂單資訊
                this.empHttpService
                  .queryOrderById(0, 1, this.selectOrderId)
                  .subscribe((res) => {
                    const responseData = res;
                    this.selectOrder = responseData.TRANRS.items[0];
                    this.selectTotal = Number(this.selectOrder.total);
                  });
                // 重查訂單明細資訊
                this.queryPageDatabtn(this.pageIndex, this.pageSize);
              }





            });
          }

        });
      }
    });
  }

  ngOnDestroy(): void {
    sessionStorage.removeItem('orderId');
    sessionStorage.removeItem('custEmail');
  }
}
