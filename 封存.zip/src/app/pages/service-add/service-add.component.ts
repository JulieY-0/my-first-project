import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Service } from 'src/app/interfaces/service';
import { ProductsService } from 'src/app/services/products.service';
import { DialogComponent, DialogData } from 'src/app/shared/components/dialog/dialog.component';
import { MemberService } from 'src/service/member.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-service-add',
  templateUrl: './service-add.component.html',
  styleUrls: ['./service-add.component.css']
})
export class ServiceAddComponent implements OnInit {
  /** 服務類別選項 */
  serviceTypes = ['寵物保姆', '寵物住宿', '寵物美容'];

  /** 寵物類別選項 */
  petTypes = ['狗狗', '貓貓', '狗狗&貓貓'];

  /** 服務狀態選項 */
  serviceAvaliables = [{ status: '上架', value: 'y' }, { status: '下架', value: 'n' }];

  /** 新增按鈕出現與否 */
  newBtnExsit = true;

  /** 修改按鈕出現與否 */
  editBtnExsit = true;

  /** 服務ID */
  serviceID = 0;

  /** 服務圖片 */
  image = '';

  /** 服務圖片驗證 */
  imageVarify = false;

  /** 上傳服務圖片 */
  fileToUpload: File | null = null;

  /** 建構表格 */
  form = this.fb.nonNullable.group({
    type: ['', [Validators.required, Validators.maxLength(10)]],
    name: ['', [Validators.required, Validators.maxLength(20)]],
    brief: ['', [Validators.required, Validators.maxLength(50)]],
    petType: ['', Validators.required],
    petSizeRange: ['', [Validators.required, Validators.pattern(/^\d*$/), Validators.maxLength(20)]],
    price: ['', [Validators.required, Validators.pattern(/^\d*$/), Validators.maxLength(10)]],
    isavaliable: ['', [Validators.required]]
  });

  /** 表格控制項 */
  controls = this.form.controls;

  /**
   * Creates an instance of ServiceAddComponent.
   * @param {FormBuilder} fb
   * @param {MatDialogRef<DialogComponent>} dialogRef
   * @param {ProductsService} productsService
   * @param {MemberService} memberService
   * @param {Router} router
   * @param {Service} data
   * @memberof ServiceAddComponent
   */
  constructor(private fb: FormBuilder, public dialogRef: MatDialogRef<DialogComponent>, private productsService: ProductsService,
    private memberService: MemberService, private router: Router, @Inject(MAT_DIALOG_DATA) public data: Service) { }

  ngOnInit(): void {
    console.log(this.data);
    // 若有值即是修改
    if (this.data) {
      this.newBtnExsit = false;
      this.form.setValue({
        type: this.data.type,
        name: this.data.name,
        brief: this.data.brief,
        petType: this.data.petType,
        petSizeRange: this.data.petSizeRange,
        price: this.data.price,
        isavaliable: this.statusToCode(this.data.isavaliable)
      })
      this.serviceID = this.data.serviceId;
      this.getImage(this.serviceID);

    } else {
      this.editBtnExsit = false;
      // 取空白圖
      this.productsService.getImage().subscribe(res => {
        this.image = res.TRANRS;

      })
    }
  }


  /**
   *
   *新增服務
   * @memberof ServiceAddComponent
   */
  addService() {
    // 如果圖片不符合
    if (!this.imageVarify) {
      Swal.fire({
        icon: 'warning',
        title: '請上傳檔案小於500KB的圖片',
        width: 450,
        padding: '3em',
        color: '#5d3f0a',
        background: '#fff',
        confirmButtonColor: '#ffbd4a'
      })
    } else {
      this.productsService.postInsertService(this.controls.type.value, this.controls.name.value, this.controls.brief.value,
        this.controls.petType.value, this.controls.petSizeRange.value, this.controls.price.value,
        this.controls.isavaliable.value).subscribe(response => {
          if (response.MWHEADER.RETURNCODE === '0000') {
            console.log("文字資料上傳成功", response);
            this.serviceID = response.TRANRS.serviceId;
            // 存完資料存圖片
            // 若圖片非空值則上傳圖片
            if (this.fileToUpload) {
              this.memberService.updateImage(this.fileToUpload, this.serviceID.toString()).subscribe(imageResponse => {
                if (imageResponse.MWHEADER.RETURNCODE === '0000') {
                  console.log("圖片上傳成功", imageResponse);
                  /** 上傳後打API顯示圖片 */
                  // this.getImage(this.serviceID);
                  Swal.fire({
                    icon: 'success',
                    title: '新增成功',
                    width: 350,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonColor: '#ffbd4a'
                  })

                  // 文字成功圖片失敗
                } else {
                  console.log('文字成功，圖片失敗，要刪除服務');
                  this.deleteService(this.serviceID);
                }
              })
            }
          } else {
            Swal.fire({
              icon: 'warning',
              title: '系統發生異常',
              html:
                '請聯繫工程師尋求協助</br></br>聯絡資訊:02-00000000</br></br>地址:台北市內湖區瑞光路510號',
              width: 450,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonColor: '#ffbd4a'
            })
          }
          this.dialogRef.close();
        })
    }
  }

  /**
   *
   *修改服務
   * @return {*}
   * @memberof ServiceAddComponent
   */
  editService() {
    // 按修改後沒動到圖片就只存文字
    if (!this.fileToUpload) {
      this.imageVarify = true;
      this.productsService.postUpdateService(this.data.serviceId, this.controls.type.value, this.controls.name.value, this.controls.brief.value,
        this.controls.petType.value, this.controls.petSizeRange.value, this.controls.price.value,
        this.controls.isavaliable.value).subscribe(response => {
          if (response.RETURNCODE === '0000') {
            console.log("文字資料上傳成功", response);
            Swal.fire({
              icon: 'success',
              title: '修改成功',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonColor: '#ffbd4a'
            })
          } else {
            Swal.fire({
              icon: 'warning',
              title: '系統發生異常',
              html:
                '請聯繫工程師尋求協助</br></br>聯絡資訊:02-00000000</br></br>地址:台北市內湖區瑞光路510號',
              width: 450,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonColor: '#ffbd4a'
            })
          }
          this.dialogRef.close();
        })
      return;
    }
    // 有動到圖片的話，檢核圖片格式是否正確
    if (!this.imageVarify) {
      Swal.fire({
        icon: 'warning',
        title: '請上傳檔案小於500KB的圖片',
        width: 450,
        padding: '3em',
        color: '#5d3f0a',
        background: '#fff',
        confirmButtonColor: '#ffbd4a'
      })
    } else {
      this.productsService.postUpdateService(this.data.serviceId, this.controls.type.value, this.controls.name.value, this.controls.brief.value,
        this.controls.petType.value, this.controls.petSizeRange.value, this.controls.price.value,
        this.controls.isavaliable.value).subscribe(response => {
          if (response.RETURNCODE === '0000') {
            console.log("文字資料上傳成功", response);
            // 存完資料存圖片
            // 若圖片非空值則上傳圖片
            if (this.fileToUpload) {
              this.memberService.updateImage(this.fileToUpload, this.serviceID.toString()).subscribe(imageResponse => {
                if (imageResponse.MWHEADER.RETURNCODE === '0000') {
                  console.log("圖片上傳成功", imageResponse);
                  /** 上傳後打API顯示圖片 */
                  // this.getImage(this.serviceID);
                  Swal.fire({
                    icon: 'success',
                    title: '修改成功',
                    width: 350,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonColor: '#ffbd4a'
                  })
                } else {
                  console.log('文字修改成功，圖片失敗，要聯絡工程師');
                  Swal.fire({
                    icon: 'warning',
                    title: '服務內容修改成功，但圖片上傳失敗',
                    html:
                      '請聯繫工程師尋求協助</br></br>聯絡資訊:02-00000000</br></br>地址:台北市內湖區瑞光路510號',
                    width: 450,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonColor: '#ffbd4a'
                  })
                }
              })
            }
          } else {
            Swal.fire({
              icon: 'warning',
              title: '系統發生異常',
              html:
                '請聯繫工程師尋求協助</br></br>聯絡資訊:02-00000000</br></br>地址:台北市內湖區瑞光路510號',
              width: 450,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonColor: '#ffbd4a'
            })
          }
          this.dialogRef.close();
        })
    }
  }


  /**
   *
   *關閉Dialog
   * @memberof ServiceAddComponent
   */
  closeDialog() {
    this.dialogRef.close();
  }

  /**
   *
   *轉換文字為共同code
   * @param {string} status
   * @return {*}
   * @memberof ServiceAddComponent
   */
  statusToCode(status: string) {
    if (status === '上架') {
      return 'y';
    } else {
      return 'n';
    }
  }

  /**
   *
   *上傳圖片後觸發圖片驗證
   * @param {*} event
   * @memberof ServiceAddComponent
   */
  onFileSelected(event: any) {
    this.fileToUpload = event.target.files[0];

    // 若非null即有上傳
    if (this.fileToUpload) {
      if (this.fileToUpload.size <= 500 * 1024) {
        const reader = new FileReader();
        reader.onload = (e: any) => {
          this.image = e.target.result;
        };
        reader.readAsDataURL(this.fileToUpload);
        this.imageVarify = true;
      } else {
        console.log('圖片太大');
        Swal.fire({
          icon: 'warning',
          title: '請上傳檔案小於500KB的圖片',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonColor: '#ffbd4a'
        })
        event.target.value = null;
        this.imageVarify = false;
        this.memberService.getImage().subscribe(res => {
          this.image = res.TRANRS;
        })
      }
    }
  }

  /**
   *
   *取得服務圖片
   * @param {number} serviceID
   * @memberof ServiceAddComponent
   */
  getImage(serviceID: number) {
    this.productsService.postGetImage(serviceID).subscribe(response => {
      this.image = response.TRANRS;
    })
  }

  /**
   *
   *刪除服務(文字)
   * @param {number} serviceID
   * @memberof ServiceAddComponent
   */
  deleteService(serviceID: number) {
    this.productsService.postDeleteService(serviceID).subscribe(deleteResponse => {
      if (deleteResponse.RETURNCODE === '0000') {
        console.log('刪除成功');
      }
    })
  }

}
