import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Service } from 'src/app/interfaces/service';
import { ProductsService } from 'src/app/services/products.service';
import { DialogComponent, DialogData } from 'src/app/shared/components/dialog/dialog.component';
import { MemberService } from 'src/service/member.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-service-add',
  templateUrl: './service-add.component.html',
  styleUrls: ['./service-add.component.css']
})
export class ServiceAddComponent implements OnInit {

  serviceTypes = ['寵物保姆', '寵物住宿', '寵物美容'];

  petTypes = ['狗狗', '貓貓', '狗狗&貓貓'];

  serviceAvaliables = [{ status: '上架中', value: 'y' }, { status: '下架中', value: 'n' }];

  newBtnDisable = false;
  editBtnDisable = false;

  serviceID = 0;
  image = '';
  imageVarify = false;
  fileToUpload: File | null = null;

  form = this.fb.nonNullable.group({
    type: ['', [Validators.required, Validators.maxLength(10)]],
    name: ['', [Validators.required, Validators.maxLength(20)]],
    brief: ['', [Validators.required, Validators.maxLength(50)]],
    petType: ['', Validators.required],
    petSizeRange: ['', [Validators.required, Validators.pattern(/^\d*$/), Validators.maxLength(20)]],
    price: ['', [Validators.required, Validators.pattern(/^\d*$/), Validators.maxLength(10)]],
    isavaliable: ['', [Validators.required]]
  });

  controls = this.form.controls;

  constructor(private fb: FormBuilder, public dialogRef: MatDialogRef<DialogComponent>, private productsService: ProductsService,
    private memberService: MemberService, private router: Router, @Inject(MAT_DIALOG_DATA) public data: Service) { }

  ngOnInit(): void {
    console.log(this.data);
    // 若有值 是修改
    if (this.data) {
      this.newBtnDisable = true;
      this.form.setValue({
        type: this.data.type,
        name: this.data.name,
        brief: this.data.brief,
        petType: this.data.petType,
        petSizeRange: this.data.petSizeRange,
        price: this.data.price,
        isavaliable: this.statusToCode(this.data.isavaliable)
      })
      this.serviceID = this.data.serviceId;
      this.getImage(this.serviceID);

    } else {
      this.editBtnDisable = true;
      // 取空白圖
      this.memberService.getImage().subscribe(res => {
        // console.log(res.TRANRS);
        this.image = res.TRANRS;

      })
    }
  }


  addService() {
    // 如果是空值(沒變動)
    if (!this.imageVarify) {
      Swal.fire({
        icon: 'warning',
        title: '請上傳檔案小於500KB的圖片',
        width: 450,
        padding: '3em',
        color: '#5d3f0a',
        background: '#fff',
      })
    } else {
      this.productsService.postInsertService(this.controls.type.value, this.controls.name.value, this.controls.brief.value,
        this.controls.petType.value, this.controls.petSizeRange.value, this.controls.price.value,
        this.controls.isavaliable.value).subscribe(response => {
          if (response.MWHEADER.RETURNCODE === '0000') {
            console.log("文字資料上傳成功", response);
            this.serviceID = response.TRANRS.serviceId;
            // 存完資料存圖片
            // 若非空值則打API
            if (this.fileToUpload) {
              this.memberService.updateImage(this.fileToUpload, this.serviceID.toString()).subscribe(imageResponse => {
                if (imageResponse.MWHEADER.RETURNCODE === '0000') {
                  console.log("圖片上傳成功", imageResponse);
                  /** 上傳後打API顯示圖片 */
                  this.getImage(this.serviceID);
                  Swal.fire({
                    icon: 'success',
                    title: '新增成功',
                    width: 350,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                  })

                  // 文字成功圖片失敗
                } else {
                  console.log('文字成功，圖片失敗，要刪除服務');
                  this.deleteService(this.serviceID);
                }
              })
              // 文字成功 圖片沒有更動 要刪除文字
              // } else {
              //   console.log('文字成功，圖片沒有更動，要刪除服務');
              //   this.deleteService(this.serviceID);
            }
          } else {
            Swal.fire({
              icon: 'warning',
              title: '系統發生異常',
              html:
                '請聯繫工程師尋求協助</br></br>聯絡資訊:02-00000000</br></br>地址:台北市內湖區瑞光路510號',
              width: 450,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
            })
          }
          this.dialogRef.close();
        })
    }


  }

  editService() {
    if (!this.imageVarify) {
      Swal.fire({
        icon: 'warning',
        title: '請上傳檔案小於500KB的圖片',
        width: 450,
        padding: '3em',
        color: '#5d3f0a',
        background: '#fff',
      })
    } else {
      this.productsService.postUpdateService(this.data.serviceId, this.controls.type.value, this.controls.name.value, this.controls.brief.value,
        this.controls.petType.value, this.controls.petSizeRange.value, this.controls.price.value,
        this.controls.isavaliable.value).subscribe(response => {
          if (response.RETURNCODE === '0000') {
            console.log("文字資料上傳成功", response);
            // 存完資料存圖片
            // 若非空值則打API
            if (this.fileToUpload) {
              this.memberService.updateImage(this.fileToUpload, this.serviceID.toString()).subscribe(imageResponse => {
                if (imageResponse.MWHEADER.RETURNCODE === '0000') {
                  console.log("圖片上傳成功", imageResponse);
                  /** 上傳後打API顯示圖片 */
                  this.getImage(this.serviceID);
                  Swal.fire({
                    icon: 'success',
                    title: '修改成功',
                    width: 350,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                  })
                } else {
                  console.log('文字成功，圖片失敗，要刪除服務');
                  Swal.fire({
                    icon: 'warning',
                    title: '服務內容修改成功，但圖片上傳失敗',
                    html:
                      '請聯繫工程師尋求協助</br></br>聯絡資訊:02-00000000</br></br>地址:台北市內湖區瑞光路510號',
                    width: 450,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                  })
                }
              })
              // 文字成功 圖片沒有更動 要刪除文字
            }
          } else {
            Swal.fire({
              icon: 'warning',
              title: '系統發生異常',
              html:
                '請聯繫工程師尋求協助</br></br>聯絡資訊:02-00000000</br></br>地址:台北市內湖區瑞光路510號',
              width: 450,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
            })
          }
          this.dialogRef.close();
        })
    }

  }


  closeDialog() {
    this.dialogRef.close();
  }


  // 轉換文字為code
  statusToCode(status: string) {
    if (status === '上架中') {
      return 'y';
    } else {
      return 'n';
    }

  }
  // 點上傳圖片則觸發
  onFileSelected(event: any) {
    this.fileToUpload = event.target.files[0];
    console.log('type' + this.fileToUpload?.type);
    console.log('size' + this.fileToUpload?.size);


    // 若非null(有上傳)
    if (this.fileToUpload) {
      console.log('這個時候觸發');

      if (this.fileToUpload?.size <= 500 * 1024) {
        const reader = new FileReader();
        reader.onload = (e: any) => {
          this.image = e.target.result;
        };
        reader.readAsDataURL(this.fileToUpload);
        this.imageVarify = true;
      } else {
        console.log('圖片太大');
        Swal.fire({
          icon: 'warning',
          title: '請上傳檔案小於500KB的圖片',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
        })
        event.target.value = null;
        this.imageVarify = false;
        this.memberService.getImage().subscribe(res => {
          this.image = res.TRANRS;
        })
      }
    }
  }

  // uploadImg(file: File, imageId: string) {
  /** 上傳圖片 */
  // const formData: FormData = new FormData();
  // formData.append('file', file);
  // formData.append('imageId', imageId);

  //   this.memberService.updateImage(file, imageId).subscribe(
  //     response => {
  //       console.log("上傳成功", response);
  //       /** 上傳後打API顯示圖片 */
  //       this.getImage(this.serviceID);
  //     })
  // }

  // 取得圖片
  getImage(serviceID: number) {
    this.productsService.postGetImage(serviceID).subscribe(response => {
      this.image = response.TRANRS;
    })
  }


  deleteService(serviceID: number) {
    this.productsService.postDeleteService(serviceID).subscribe(deleteResponse => {
      if (deleteResponse.RETURNCODE === '0000') {
        console.log('刪除成功');
      }
    })
  }

}
