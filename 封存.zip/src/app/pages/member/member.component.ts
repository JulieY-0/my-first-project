import { DatePipe, Location } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { QueryCartTranrqItems } from 'src/app/core/interfaces/queryCart/queryCartTranrqItems.interface';
import { QueryCartTranrs } from 'src/app/core/interfaces/queryCart/queryCartTranrs.interface';
import { CartService } from 'src/app/core/services/cart.service';
import { HASHCUSTranrq } from 'src/app/interfaces/hashCusTranrq';
import { OneCustomerRequest } from 'src/interface/oneCustomerRequest';
import { UpdateCustomerRequest } from 'src/interface/updateCustomerRequest';
import { MemberPasswordComponent } from '../member-password/member-password.component';
import { MemberService } from './../../../service/member.service';
import { OnePetByCustomerRequest } from 'src/interface/onePetByCustomerRequest';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-member',
  templateUrl: './member.component.html',
  styleUrls: ['./member.component.css'],
  providers: [DatePipe]
})
export class MemberComponent implements OnInit {
  selectedView: string = '會員帳號設定';

  // 定義一個方法来切换視圖
  switchView(view: string) {
    this.selectedView = view;
  }


  form = this.fb.nonNullable.group({
    /** 會員姓名的FormControl */
    name: [{ value: '', disabled: true }, Validators.required],
    // {value: '', disabled: true}
    // /** 會員電子信箱的FormControl*/  disabled: boolean =true
    email: [{ value: '', disabled: true }, Validators.required],
    /** 會員電話的FormControl*/
    tel: [{ value: '', disabled: true }, [Validators.pattern('^[0-9]*$'), Validators.maxLength(10)]],
    /** 會員姓名的FormControl */
    sex: [{ value: '', disabled: true }],
    /** 會員電話的FormControl*/
    birth: [{ value: '', disabled: true }],
  });

  panelOpenState: boolean = false;
  step: number = 0;
  imagePath: string = '';
  alttext: string = 'memberPhoto';
  isEditable: boolean = false;
  // readonlyMode: boolean = false;
  // disabled: boolean = true;
  nameControl!: FormControl;
  hashuser = sessionStorage.getItem("hashuser");
  custemail: string = '';
  password: string = '';
  hashEmail: string | null = '';
  countInCart: number | string = 0;
  name: string | undefined = '';

  constructor(private memberService: MemberService, private fb: FormBuilder, private datePipe: DatePipe, public dialog: MatDialog, private cartService: CartService, private router: Router) { }

  public get birth(): FormControl<string | null> {
    return this.form.controls.birth;
  }
  @ViewChild('fileInput') fileInput!: ElementRef;
  ngOnInit(): void {
    window.scrollTo(0, 0);
    // this.readonlyMode = true;
    // this.form.controls.name.disable();
    console.log(sessionStorage.getItem("hashuser"));

    this.hashEmail = sessionStorage.getItem('hashuser');
    if (this.hashEmail) {
      this.cartService.queryHashCus(this.hashEmail).subscribe(rs => {
        this.custemail = rs.TRANRS.email;
        const input: QueryCartTranrqItems = { custEmail: this.custemail, isSubmit: 'n' };
        this.cartService.query(input).subscribe((rs: QueryCartTranrs) => {
          const returnCode = rs.MWHEADER.RETURNCODE;
          if (returnCode === '0000') { this.countInCart = rs.TRANRS.totalCount; this.cartService.setCountInCart(this.countInCart); }
        });
      });
    }



    /** 先拿到custemail */
    const request0 = {
      MWHEADER: {
        MSGID: "PAWSOME-HASHCUST"
      },
      TRANRQ: {
        hashEmail: this.hashuser
      }
    }
    console.log(request0);

    this.memberService.hashCust(request0 as HASHCUSTranrq).subscribe(
      response => {
        console.log(response.TRANRS.email);
        this.custemail = response.TRANRS.email;

        /** 基本會員資料*/
        const request = {
          MWHEADER: {
            MSGID: "PAWSOME-ONECUSTOMER"
          },
          TRANRQ: {
            email: this.custemail,
            pageNumber: 0,
            pageSize: 5
          }
        }
        console.log(request);

        this.memberService.oneCustomer(request as OneCustomerRequest).subscribe(
          response => {
            console.log(response);
            this.imagePath = response.TRANRS.imgData;
            console.log(response.TRANRS.items[0]);
            this.form.controls.name.setValue(response.TRANRS.items[0].name);
            this.form.controls.email.setValue(response.TRANRS.items[0].email);
            this.form.controls.tel.setValue(response.TRANRS.items[0].tel);
            this.form.controls.sex.setValue(response.TRANRS.items[0].sex);
            // this.form.controls.password.setValue(response.TRANRS.items[0].password);
            // const birthDate: any = this.datePipe.transform(response.TRANRS.items[0].birthday, 'yyyy/MM/dd')
            this.form.controls.birth.setValue(response.TRANRS.items[0].birthday);

            /** 先判斷有沒有寵物沒有的話跳彈框 */
            /** 會員寵物列表 */
            const request = {
              MWHEADER: {
                MSGID: "PAWSOME-ONEPETBYCUSTOMER"
              },
              TRANRQ: {
                custEmail: this.custemail,
              }
            }
            this.memberService.onePetByCustomer(request as OnePetByCustomerRequest).subscribe(
              response => {
                console.log(response);
              if (response.MWHEADER.RETURNCODE === 'E702') {
                Swal.fire('還沒有寵物呦，請先新增寵物!!');
              }

              })
          })
        console.log(this.custemail);


      })
  }


  onEditClick() {
    this.isEditable = true;
    // this.form.controls.name.enable();
    // this.readonlyMode = !this.readonlyMode
    this.form.get('name')?.enable();
    this.form.get('tel')?.enable();
    this.form.get('sex')?.enable();
    this.form.get('birth')?.enable();
    this.name = this.form.value.name;
  }

  onCancelClick() {
    this.isEditable = false;

    /** 先拿到custemail */
    const request0 = {
      MWHEADER: {
        MSGID: "PAWSOME-HASHCUST"
      },
      TRANRQ: {
        hashEmail: this.hashuser
      }
    }
    console.log(request0);

    this.memberService.hashCust(request0 as HASHCUSTranrq).subscribe(
      response => {
        console.log(response.TRANRS.email);
        this.custemail = response.TRANRS.email;

        /** 基本會員資料*/
        const request = {
          MWHEADER: {
            MSGID: "PAWSOME-ONECUSTOMER"
          },
          TRANRQ: {
            email: this.custemail,
            pageNumber: 0,
            pageSize: 5
          }
        }
        console.log(request);

        this.memberService.oneCustomer(request as OneCustomerRequest).subscribe(
          response => {
            console.log(response);
            this.imagePath = response.TRANRS.imgData;
            console.log(response.TRANRS.items[0]);

            this.form.controls.name.setValue(response.TRANRS.items[0].name);
            this.form.controls.email.setValue(response.TRANRS.items[0].email);
            this.form.controls.tel.setValue(response.TRANRS.items[0].tel);
            this.form.controls.sex.setValue(response.TRANRS.items[0].sex);
            // this.form.controls.password.setValue(response.TRANRS.items[0].password);
            // const birthDate: any = this.datePipe.transform(response.TRANRS.items[0].birthday, 'yyyy/MM/dd')
            this.form.controls.birth.setValue(response.TRANRS.items[0].birthday);

          })
        console.log(this.custemail);


      })

    this.form.get('name')?.disable();
    this.form.get('tel')?.disable();
    this.form.get('sex')?.disable();
    this.form.get('birth')?.disable();
    // this.readonlyMode = !this.readonlyMode;
  }



  updateData() {
    console.log(this.form.get('email'));
    this.isEditable = false;
    /** 再拿到使用者的密碼 */
    /** 基本會員資料*/
    const request1 = {
      MWHEADER: {
        MSGID: "PAWSOME-ONECUSTOMER"
      },
      TRANRQ: {
        email: this.custemail,
        pageNumber: 0,
        pageSize: 5
      }
    }
    this.memberService.oneCustomer(request1 as OneCustomerRequest).subscribe(
      response => {
        console.log(response);
        console.log(response.TRANRS.items[0].password)
        this.password = response.TRANRS.items[0].password;
        const birth = this.datePipe.transform(this.form.value.birth, 'yyyy-MM-dd');
        const editBirthday = !this.form.value.birth ? '' : new Date(this.form.value.birth);
        console.log('edit', this.form.controls.name);

        /** 更新資料 */
        const request2 = {
          MWHEADER: {
            MSGID: "PAWSOME-UPDATECUSTOMER"
          },
          TRANRQ: {
            custEmail: this.custemail,
            password: this.password,
            name: this.form.value.name,
            tel: this.form.value.tel,
            sex: this.form.value.sex,
            birthday: editBirthday
          }
        }
        console.log(request2);

        this.memberService.updateCustomer(request2 as UpdateCustomerRequest).subscribe(
          response => {
            console.log(response);
            /** 基本會員資料*/
            const request3 = {
              MWHEADER: {
                MSGID: "PAWSOME-ONECUSTOMER"
              },
              TRANRQ: {
                email: this.custemail,
                pageNumber: 0,
                pageSize: 5
              }
            }
            this.memberService.oneCustomer(request3 as OneCustomerRequest).subscribe(
              response => {
                console.log(response);
                this.imagePath = response.TRANRS.imgData;
                console.log(response.TRANRS.items[0]);

                this.form.controls.name.setValue(response.TRANRS.items[0].name);
                this.form.controls.email.setValue(response.TRANRS.items[0].email);
                this.form.controls.tel.setValue(response.TRANRS.items[0].tel);
                this.form.controls.sex.setValue(response.TRANRS.items[0].sex);
                // this.form.controls.password.setValue(response.TRANRS.items[0].password);
                const birthDate: any = this.datePipe.transform(response.TRANRS.items[0].birthday, 'yyyy-MM-dd')
                this.form.controls.birth.setValue(birthDate);


              })

          })

      })

    // this.form.controls.name.disable();

    this.form.get('name')?.disable();
    this.form.get('tel')?.disable();
    this.form.get('sex')?.disable();
    this.form.get('birth')?.disable();

  }


  onFileSelected(event: any) {
    const fileToUpload: File | null = event.target.files[0] || null;
    if (fileToUpload) {
      this.uploadImg(fileToUpload, this.custemail);
    }
  }

  triggerFileInput() {
    this.fileInput.nativeElement.click();
  }
  /** 上傳相片按鈕 */
  uploadImg(file: File, imageId: string) {

    /** 上傳圖片 */
    const formData: FormData = new FormData();
    formData.append('file', file);
    formData.append('imageId', this.custemail);


    this.memberService.updateImage(file, imageId).subscribe(
      response => {
        console.log("上傳成功", response);

        /** 上傳完再打一次 */
        const request = {
          MWHEADER: {
            MSGID: "PAWSOME-ONECUSTOMER"
          },
          TRANRQ: {
            email: this.custemail,
            pageNumber: 0,
            pageSize: 5
          }
        }
        console.log(request);

        this.memberService.oneCustomer(request as OneCustomerRequest).subscribe(
          response => {
            console.log(response);
            this.imagePath = response.TRANRS.imgData;
            console.log(response.TRANRS.items[0]);
          });
      },

    );
    location.reload();

  }
  /** 移除目前大頭貼照片中的空白頭圖片拿取 */
  dataURLtoFile(dataUrl: string) {
    //去除前綴字
    dataUrl = dataUrl.replace('data:image/jpeg;base64,', '');
    //將Base64轉換成字節數組
    const byteArray = new Uint8Array(
      atob(dataUrl).split('').map((char) => char.charCodeAt(0))
    );
    const file = new Blob([byteArray], { type: 'image/jpeg.' });

    const imageFile = new File([file], 'image.jpg', { type: 'image/jpeg' })
    return imageFile;
  }



  /** 移除目前的大頭照功能 */
  clearImg() {
    /** 先打一支getImage為了拿到空白圖 */
    this.memberService.getImage().subscribe(
      response => {
        console.log(response.TRANRS);
        const imageString = response.TRANRS;
        const imageFile = this.dataURLtoFile(imageString);
        console.log('有跑到');
        if (imageFile) {
          this.uploadImg(imageFile, this.custemail);
          console.log('有跑到2');

        }
      });
  }

  forgetPassword() {
    const dialogRef = this.dialog.open(MemberPasswordComponent, { //打開對話框組件
      width: '600px',
      height: '400px',
      //可選項，可配置寬高與傳遞數據
      data: {
        custemail: this.custemail,
        name: this.form.value.name,
        tel: this.form.value.tel,
        sex: this.form.value.sex,
        // birthday: this.
      }
    });
    dialogRef.afterClosed().subscribe(() => {



    });
  }







}
