import { DatePipe } from '@angular/common';
import { Tranrs } from './../../../interface/oneCustomerResponse';
import { MemberService } from './../../../service/member.service';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { OneCustomerRequest } from 'src/interface/oneCustomerRequest';
import { MatDialog } from '@angular/material/dialog';
import { ImageComponent } from 'src/app/image/image.component';
import { UpdateCustomerRequest } from 'src/interface/updateCustomerRequest';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-member',
  templateUrl: './member.component.html',
  styleUrls: ['./member.component.css'],
  providers: [DatePipe]
})
export class MemberComponent implements OnInit {
  selectedView: string = '會員帳號設定';

  // 定义一个方法来切换视图
  switchView(view: string) {
    this.selectedView = view;
  }


  form = this.fb.nonNullable.group({
    /** 會員姓名的FormControl */
    name: ['', [Validators.required, Validators.pattern(/^[0-9a-zA-Z_]*$/)]],
    // {value: '', disabled: true}
    // /** 會員電子信箱的FormControl*/  disabled: boolean =true
    email: ['', [Validators.required, Validators.pattern(/^[0-9a-zA-Z_]*$/)]],
    /** 會員電話的FormControl*/
    tel: ['', Validators.pattern('^(0|[1-9][0-9]*)$')],
  });
  form1 = this.fb.nonNullable.group({
    /** 會員姓名的FormControl */
    sex: ['', [Validators.required, Validators.pattern(/^[0-9a-zA-Z_]*$/)]],
    /** 會員電子信箱的FormControl*/
    password: ['', [Validators.required, Validators.pattern(/^[0-9a-zA-Z_]*$/)]],
    /** 會員電話的FormControl*/
    birth: ['', Validators.pattern('^(0|[1-9][0-9]*)$')],
  });
  nameForm = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.pattern(/^[0-9a-zA-Z_]*$/)]]
  });
  panelOpenState: boolean = false;
  step: number = 0;
  imagePath: string = '';
  alttext: string = 'memberPhoto';
  isEditable: boolean = false;
  // haveupdatePhoto: boolean = this.imagePath == '';
  readonlyMode: boolean = true;
  // disabled: boolean = true;
  constructor(private memberService: MemberService, private fb: FormBuilder, private datePipe: DatePipe, public dialog: MatDialog) { }

  public get birth(): FormControl<string | null> {
    return this.form1.controls.birth;
  }
  @ViewChild('fileInput') fileInput!: ElementRef;
  ngOnInit(): void {
    window.scrollTo(0, 0);
    /** 基本會員資料*/
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-ONECUSTOMER"
      },
      TRANRQ: {
        email: '123@gmail.com',
        pageNumber: 0,
        pageSize: 5
      }
    }
    this.memberService.oneCustomer(request as OneCustomerRequest).subscribe(
      response => {
        console.log(response);
        this.imagePath = response.TRANRS.imgData;
        console.log(response.TRANRS.items[0]);

        this.form.controls.name.setValue(response.TRANRS.items[0].name);
        this.form.controls.email.setValue(response.TRANRS.items[0].email);
        this.form.controls.tel.setValue(response.TRANRS.items[0].tel);
        this.form1.controls.sex.setValue(response.TRANRS.items[0].sex);
        this.form1.controls.password.setValue(response.TRANRS.items[0].password);
        const birthDate: any = this.datePipe.transform(response.TRANRS.items[0].birthday, 'yyyy-MM-dd')
        this.form1.controls.birth.setValue(birthDate);
        // Swal.fire({
        //   position: 'center',
        //   icon: 'success',
        //   title: '修改成功',
        //   showConfirmButton: false,
        //   timer: 1500
        // })
      })



  }


  onEditClick() {
    this.isEditable = true;
    this.readonlyMode = !this.readonlyMode;

  }

  onSaveClick() {
    this.isEditable = false;
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-UPDATECUSTOMER"
      },
      TRANRQ: {
        custEmail: "123@gmail.com",
        password: this.form1.value.password,
        name: this.form.value.name,
        tel: this.form.value.tel,
        sex: this.form1.value.sex,
        birthday: this.form1.value.birth
      }
    }
    this.memberService.updateCustomer(request as UpdateCustomerRequest).subscribe(
      response => {
        console.log(response);
        // this.imagePath = response.TRANRS.imgData;
        // console.log(response.TRANRS.items[0]);

        // this.form.controls.name.setValue(response.TRANRS.items[0].name);
        // this.form.controls.email.setValue(response.TRANRS.items[0].email);
        // this.form.controls.tel.setValue(response.TRANRS.items[0].tel);
        // this.form1.controls.sex.setValue(response.TRANRS.items[0].sex);
        // this.form1.controls.password.setValue(response.TRANRS.items[0].password);
        // const birthDate: any = this.datePipe.transform(response.TRANRS.items[0].birthday, 'yyyy-MM-dd')
        // this.form1.controls.birth.setValue(birthDate);

      })
    /** 基本會員資料*/
    const request1 = {
      MWHEADER: {
        MSGID: "PAWSOME-ONECUSTOMER"
      },
      TRANRQ: {
        email: '123@gmail.com',
        pageNumber: 0,
        pageSize: 5
      }
    }
    this.memberService.oneCustomer(request1 as OneCustomerRequest).subscribe(
      response => {
        console.log(response);
        this.imagePath = response.TRANRS.imgData;
        console.log(response.TRANRS.items[0]);

        this.form.controls.name.setValue(response.TRANRS.items[0].name);
        this.form.controls.email.setValue(response.TRANRS.items[0].email);
        this.form.controls.tel.setValue(response.TRANRS.items[0].tel);
        this.form1.controls.sex.setValue(response.TRANRS.items[0].sex);
        this.form1.controls.password.setValue(response.TRANRS.items[0].password);
        const birthDate: any = this.datePipe.transform(response.TRANRS.items[0].birthday, 'yyyy-MM-dd')
        this.form1.controls.birth.setValue(birthDate);


      })


  }



  editphoto() {
    const dialogRef = this.dialog.open(ImageComponent, { //打開對話框組件
      width: '500px',
      height: '500px',
      //可選項，可配置寬高與傳遞數據
      data: {

      }
    });
    dialogRef.afterClosed().subscribe(() => {
      const request = {
        MWHEADER: {
          MSGID: "PAWSOME-ONECUSTOMER"
        },
        TRANRQ: {
          email: '123@gmail.com',
          pageNumber: 0,
          pageSize: 5
        }
      }
      this.memberService.oneCustomer(request as OneCustomerRequest).subscribe(
        response => {
          console.log(response);
          this.imagePath = response.TRANRS.imgData;



        })



    })
  }
  onFileSelected(event: any) {
    const fileToUpload: File | null = event.target.files[0] || null;
    if (fileToUpload) {
      this.uploadImg(fileToUpload, '123@gmail.com');
    }
  }

  triggerFileInput() {
    this.fileInput.nativeElement.click();
  }
  /** 上傳相片按鈕 */
  uploadImg(file: File, imageId: string) {
    /** 上傳圖片 */
    const formData: FormData = new FormData();
    formData.append('file', file);
    formData.append('imageId', '123@gmail.com');

    this.memberService.updateImage(file, imageId).subscribe(
      response => {
        console.log("上傳成功", response);

        /** 上傳完再打一次 */
        const request = {
          MWHEADER: {
            MSGID: "PAWSOME-ONECUSTOMER"
          },
          TRANRQ: {
            email: '123@gmail.com',
            pageNumber: 0,
            pageSize: 5
          }
        }
        this.memberService.oneCustomer(request as OneCustomerRequest).subscribe(
          response => {
            console.log(response);
            this.imagePath = response.TRANRS.imgData;
            console.log(response.TRANRS.items[0]);
          });
      },

    );



  }
  /** 移除目前大頭貼照片中的空白頭圖片拿取 */
  dataURLtoFile(dataUrl: string) {
    //去除前綴字
    dataUrl = dataUrl.replace('data:image/jpeg;base64,', '');
    //將Base64轉換成字節數組
    const byteArray = new Uint8Array(
      atob(dataUrl).split('').map((char) => char.charCodeAt(0))
    );
    const file = new Blob([byteArray], { type: 'image/jpeg.' });

    const imageFile = new File([file], 'image.jpg', { type: 'image/jpeg' })
    return imageFile;
  }



  /** 移除目前的大頭照功能 */
  clearImg() {
    /** 先打一支getImage為了拿到空白圖 */
    this.memberService.getImage().subscribe(
      response => {
        console.log(response.TRANRS);
        const imageString = response.TRANRS;
        const imageFile = this.dataURLtoFile(imageString);
        console.log('有跑到');
        if (imageFile) {
          this.uploadImg(imageFile, '123@gmail.com');
          console.log('有跑到2');

        }
      });
  }






}




