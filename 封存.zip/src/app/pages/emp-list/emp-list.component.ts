import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { Emp } from 'src/app/shared/interfaces/EmpElement';
import { EmpIsQuitPipe } from 'src/app/shared/pipes/emp-is-quit.pipe';
import { EmpPermissionsPipe } from 'src/app/shared/pipes/emp-permissions.pipe';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import { MatDialog } from '@angular/material/dialog';
import { EmpEditComponent } from '../emp-edit/emp-edit.component';
import { EmpAddComponent } from '../emp-add/emp-add.component';
import { EmpDataService } from 'src/app/shared/service/emp-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css'],
  providers: [EmpPermissionsPipe, EmpIsQuitPipe],
})
export class EmpListComponent implements OnInit {
  /**
   * 分頁
   * @type {MatPaginator}
   * @memberof EmpListComponent
   */
  @ViewChild('paginator', { static: true }) paginator!: MatPaginator;

  /** 員工信箱 */
  empEmail = '';

  /** 資料總筆數 */
  length = 0;

  /** 目前頁碼 預設為0 */
  pageIndex = 0;

  /** 每頁呈現幾筆 預設為5 */
  pageSize = 5;

  /** 總頁數 */
  totalPage: number | undefined;

  /** 允許切換的每頁資料筆數 */
  pageSizeOptions = [5, 10];

  /** 分頁結果 */
  pageEvent: PageEvent | undefined;

  /** 查詢員工信箱 */
  queryEmail: string | undefined;

  /** 查詢員工姓名 */
  queryName: string | undefined;

  /** 查詢員工電話 */
  queryTel: string | undefined;

  /** 查詢員工就職狀態 */
  queryIsQuit: string | undefined;

  /** 欄位名稱 */
  displayedColumns = [
    'name',
    'email',
    'tel',
    'sex',
    'birthday',
    'permissions',
    'isQuit',
    'updateTime',
    'edit',
  ];

  /** 表格資料 */
  dataSource: Emp[] = [];

  /** 查無資料 */
  dataNotFound = false;

  /** 就職狀態選單 */
  isQuitList = [
    { msg: '在職', code: 'n' },
    { msg: '離職', code: 'y' }
  ]

  /** 利用 FormBuilder 群組 nonNullable 和 Validators，檢核 Input 輸入值 */
  form = this.fb.nonNullable.group({
    email: ['', [Validators.pattern(/^\S*$/)]],
    name: ['', [Validators.pattern(/^\S*$/)]],
    tel: ['', [Validators.pattern(/^\d*$/)]],
    isQuit: [''],
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private empHttpService: EmpHttpService,
    private dataService: EmpDataService,
    private empPermissionsPipe: EmpPermissionsPipe,
    private empIsQuitPipe: EmpIsQuitPipe,
    public dialog: MatDialog,
  ) { }

  /**
   * 取得「員工信箱」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpListComponent
   */
  public get email(): FormControl<string | null> {
    return this.form.controls.email;
  }

  /**
   * 取得「員工姓名」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpListComponent
   */
  public get name(): FormControl<string | null> {
    return this.form.controls.name;
  }

  /**
   * 取得「員工電話」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpListComponent
   */
  public get tel(): FormControl<string | null> {
    return this.form.controls.tel;
  }

  /**
   * 取得「就職狀態」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpListComponent
   */
  public get isQuit(): FormControl<string | null> {
    return this.form.controls.isQuit;
  }

  ngOnInit(): void {

    this.empHttpService.queryHashEmp(sessionStorage.getItem('hashempuser')!).subscribe({
      next: (rs) => {
        this.empEmail = rs.TRANRS.email;
      },
      complete: () => {
        this.empHttpService.queryEmpData(0, 1, this.empEmail, '', '', '').subscribe((res) => {
          const responseData = res;
          // 若員工權限不夠轉至員工首頁
          if (responseData.TRANRS.items[0].permissions !== '1') {
            this.router.navigate(['/empPawsome/emp']);
          }
        });
      }
    })

    this.queryEmpData();
  }

  /**
   * 分頁器
   * @param event
   */
  getPaginatorData(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.queryPageDatabtn(this.pageIndex, this.pageSize);
  }

  /** 初始查詢按鈕 */
  queryEmpData() {
    this.dataNotFound = false;
    this.pageIndex = 0;
    this.queryEmail = this.form.value.email;
    this.queryName = this.form.value.name;
    this.queryTel = this.form.value.tel;
    this.queryIsQuit = this.form.value.isQuit;
    this.empHttpService
      .queryEmpData(0, this.pageSize, this.queryEmail, this.queryName, this.queryTel, this.queryIsQuit)
      .subscribe((res) => {
        const responseData = res;

        if (responseData.MWHEADER.RETURNCODE !== '0000') {
          this.dataSource = [];
          this.dataNotFound = true;
          return;
        }

        this.length = responseData.TRANRS.totalCount;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as Emp[];
        this.dataSource = this.dataSource.map<Emp>((e) => ({
          ...e,
          permissions: this.empPermissionsPipe.transform(e.permissions),
          isQuit: this.empIsQuitPipe.transform(e.isQuit),
        }));
      });
  }

  /**
   * 分頁查詢按鈕
   * @param pageIndex
   * @param pageSize
   */
  queryPageDatabtn(pageIndex: number, pageSize: number) {
    this.dataNotFound = false;
    this.empHttpService
      .queryEmpData(pageIndex, pageSize, this.queryEmail, this.queryName, this.queryTel, this.queryIsQuit)
      .subscribe((res) => {
        const responseData = res;

        this.length = responseData.TRANRS.totalCount;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as Emp[];
        this.dataSource = this.dataSource.map<Emp>((e) => ({
          ...e,
          permissions: this.empPermissionsPipe.transform(e.permissions),
          isQuit: this.empIsQuitPipe.transform(e.isQuit),
        }));
      });
  }

  /** 全查按鈕 重新載入表格 */
  queryAllData() {
    this.dataNotFound = false;
    this.pageIndex = 0;
    this.form.patchValue({
      email: '',
      name: '',
      tel: '',
      isQuit: '',
    });

    this.queryEmpData();
  }

  /** 開啟新增彈窗 */
  openAddDialog() {
    const dialogRef = this.dialog.open(EmpAddComponent, {
      width: '55%',
    });
    dialogRef.afterClosed().subscribe(() => {
      this.queryEmail = '';
      this.queryEmpData();
    });
  }

  /** 開啟修改彈窗 */
  openEditDialog(i: number) {
    // 將員工信箱資料存至 dataService
    this.dataService.empEmail = this.dataSource[i].email;

    const dialogRef = this.dialog.open(EmpEditComponent, {
      width: '55%',
    });

    dialogRef.afterClosed().subscribe(() => {
      this.queryEmail = '';
      this.queryPageDatabtn(this.pageIndex, this.pageSize);
    });
  }
}
