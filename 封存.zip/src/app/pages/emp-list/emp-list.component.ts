import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { Emp } from 'src/app/shared/interfaces/EmpElement';
import { EmpIsQuitPipe } from 'src/app/shared/pipes/emp-is-quit.pipe';
import { EmpPermissionsPipe } from 'src/app/shared/pipes/emp-permissions.pipe';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import { MatDialog } from '@angular/material/dialog';
import { EmpEditComponent } from '../emp-edit/emp-edit.component';
import { EmpAddComponent } from '../emp-add/emp-add.component';
import { EmpDataService } from 'src/app/shared/service/emp-data.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css'],
  providers: [EmpPermissionsPipe, EmpIsQuitPipe]
})
export class EmpListComponent implements OnInit {

  /**
   * 分頁
   * @type {MatPaginator}
   * @memberof EmpListComponent
   */
  @ViewChild('paginator', { static: true }) paginator!: MatPaginator;

  /** 是否有修改權限 */
  isAdmin = false;

  /** 資料總筆數 */
  length = 0;

  /** 目前頁碼 預設為0 */
  pageIndex = 0;

  /** 每頁呈現幾筆 預設為5 */
  pageSize = 5;

  /** 總頁數 */
  totalPage: number | undefined;

  /** 允許切換的每頁資料筆數 */
  pageSizeOptions = [5, 10];

  /** 分頁結果 */
  pageEvent: PageEvent | undefined;

  /** 初始員工列表全查 */
  queryEmail: string | undefined;

  /** 欄位名稱 */
  displayedColumns = [
    'order',
    'name',
    'email',
    'tel',
    'sex',
    'birthday',
    'permissions',
    'isQuit',
    'updateTime',
    'edit',
  ];

  /** 表格資料 */
  dataSource: Emp[] = [];

  /** 利用 FormBuilder 群組 nonNullable 和 Validators，檢核 Input 輸入值 */
  form = this.fb.nonNullable.group({
    email: ['', [Validators.email]]
  });

  constructor(
    private fb: FormBuilder,
    private empHttpService: EmpHttpService,
    private dataService: EmpDataService,
    private empPermissionsPipe: EmpPermissionsPipe,
    private empIsQuitPipe: EmpIsQuitPipe,
    public dialog: MatDialog,
  ) { }

  /**
   * 取得「員工信箱」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpListComponent
   */
  public get email(): FormControl<string | null> {
    return this.form.controls.email;
  }

  ngOnInit(): void {

    if (sessionStorage.getItem('permission') === '1') {
      this.isAdmin = true;
    }

    this.queryEmpData();
  }

  /**
   * 分頁器
   * @param event
   */
  getPaginatorData(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.queryPageDatabtn(this.pageIndex, this.pageSize);
  }

  /** 初始查詢按鈕 */
  queryEmpData() {
    this.pageIndex = 0;
    this.queryEmail = this.form.value.email;
    this.empHttpService.queryEmpData(0, this.pageSize, this.queryEmail).subscribe(
      res => {
        const responseData = res;

        if (responseData.MWHEADER.RETURNCODE !== '0000') {
          Swal.fire({
            icon: 'error',
            title: '查詢失敗',
            text: responseData.MWHEADER.RETURNDESC,
            width: 350,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonText: '確定',
          })
          return;
        }

        this.length = responseData.TRANRS.totalCount;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as Emp[];
        this.dataSource = this.dataSource.map<Emp>(e => ({
          ...e,
          permissions: this.empPermissionsPipe.transform(e.permissions),
          isQuit: this.empIsQuitPipe.transform(e.isQuit),
          order: 0
        }));
      });
  }

  /**
   * 分頁查詢按鈕
   * @param pageIndex
   * @param pageSize
   */
  queryPageDatabtn(pageIndex: number, pageSize: number) {
    this.empHttpService.queryEmpData(pageIndex, pageSize, this.queryEmail).subscribe(
      res => {
        const responseData = res;

        this.length = responseData.TRANRS.totalCount;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as Emp[];
        this.dataSource = this.dataSource.map<Emp>(e => ({
          ...e,
          permissions: this.empPermissionsPipe.transform(e.permissions),
          isQuit: this.empIsQuitPipe.transform(e.isQuit),
          order: pageIndex * pageSize
        }))
      });
  }

  /** 全查按鈕 */
  queryAllData() {
    this.pageIndex = 0;
    this.form.patchValue({
      email: ''
    });

    this.empHttpService.queryEmpData(0, this.pageSize, '').subscribe(
      res => {
        const responseData = res;

        if (responseData.MWHEADER.RETURNCODE !== '0000') {
          Swal.fire({
            icon: 'error',
            title: '查詢失敗',
            text: responseData.MWHEADER.RETURNDESC,
            width: 350,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonText: '確定',
          })
          return;
        }

        this.length = responseData.TRANRS.totalCount;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as Emp[];
        this.dataSource = this.dataSource.map<Emp>(e => ({
          ...e,
          permissions: this.empPermissionsPipe.transform(e.permissions),
          isQuit: this.empIsQuitPipe.transform(e.isQuit),
          order: 0
        }));
      });
  }

  /** 開啟新增彈窗 */
  openAddDialog() {
    const dialogRef = this.dialog.open(EmpAddComponent, {
      width: '60%'
    });
    this.queryEmpData();
  }

  /** 開啟修改彈窗 */
  openEditDialog(i: number) {

    // 將員工信箱資料存至 dataService
    this.dataService.empEmail = this.dataSource[i].email;

    const dialogRef = this.dialog.open(EmpEditComponent, {
      width: '55%'
    });

    dialogRef.afterClosed().subscribe(() => {
      this.queryEmail = '';
      this.queryPageDatabtn(this.pageIndex, this.pageSize);
    });
  }
}

