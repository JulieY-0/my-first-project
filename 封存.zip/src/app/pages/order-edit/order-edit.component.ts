import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DialogComponent, DialogData } from 'src/app/shared/components/dialog/dialog.component';
import { CommCodeItems, OrderDataItems, UpdateOrderDataTranrq } from 'src/app/shared/interfaces/EmpElement';
import { EmpDataService } from 'src/app/shared/service/emp-data.service';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-order-edit',
  templateUrl: './order-edit.component.html',
  styleUrls: ['./order-edit.component.css'],
  providers: [DatePipe]
})
export class OrderEditComponent implements OnInit {

  /** 欲修改之訂單編號 */
  selectOrderId: string | undefined;

  /** 欲修改之訂購時間 */
  selectConfirmDate: string | undefined;

  /** 欲修改之會員信箱 */
  selectCustEmail: string | undefined;

  /** 欲修改之資料 */
  editData = {} as OrderDataItems;

  /** 訂單狀態選單 */
  orderProcessList: CommCodeItems[] = [];

  /** 利用 FormBuilder 群組 nonNullable 和 Validators，檢核 Input 輸入值 */
  form = this.fb.nonNullable.group({
    orderProcess: ['', [Validators.required]]
  });

  /**
   * 取得「訂單狀態」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderEditComponent
   */
  public get orderProcess(): FormControl<string | null> {
    return this.form.controls.orderProcess;
  }

  constructor(
    private fb: FormBuilder,
    private empHttpService: EmpHttpService,
    private dataService: EmpDataService,
    private datePipe: DatePipe,
    public dialogRef: MatDialogRef<DialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
  ) { }

  ngOnInit(): void {
    this.empHttpService.queryMsgCode('ORDERPROCESS')
      .subscribe(res => {
        const responseData = res;
        this.orderProcessList = responseData.TRANRS.items;
      });

    this.selectOrderId = this.dataService.orderId;

    this.empHttpService.queryOrderById(0, 1, this.selectOrderId).subscribe({
      next: res => {
        const responseData = res;
        this.editData = responseData.TRANRS.items[0];
      },
      complete: () => {
        this.initialization();
      }
    });
  }

  /** 修改訂單狀態 */
  editOrder() {
    const updaterq = {
      ...this.editData,
      custEmail: this.selectCustEmail,
      orderProcess: this.orderProcessList.find(element => element.msg === this.form.value.orderProcess)?.commCode
    } as UpdateOrderDataTranrq;

    console.log(updaterq);

    this.empHttpService.editOrderData(updaterq).subscribe(
      res => {
        const responseData = res;
        // 修改失敗跳出提示訊息
        if (responseData.MWHEADER.RETURNCODE !== '0000') {
          Swal.fire({
            icon: 'error',
            title: '修改失敗',
            text: responseData.MWHEADER.RETURNDESC,
            width: 350,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonText: '確定',
          })
          return;
        }

        // 修改成功跳出提示訊息
        if (responseData.MWHEADER.RETURNCODE === '0000') {
          Swal.fire({
            icon: 'success',
            title: '修改成功',
            width: 350,
            padding: '3em',
            background: '#fff',
          })
          this.dialogRef.close();
        }
      });
  }

  /** 關閉談窗 */
  closeDialog() {
    this.dialogRef.close();
  }

  /** 初始化-將選取資料帶到畫面顯示 */
  initialization() {
    // 將選取資料帶到畫面顯示
    this.form.patchValue({
      ...this.editData,
    });

    this.selectCustEmail = this.editData.custEmail;
    this.selectConfirmDate = this.datePipe.transform(this.editData.confirmDate, 'yyyy-MM-dd') as string;

  }
}
