import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cards } from 'src/app/interfaces/cards';
import { HASHCUSTranrq } from 'src/app/interfaces/hashCusTranrq';
import { ProductsService } from 'src/app/services/products.service';
import { ServiceDetailRequest } from 'src/interface/ServiceDetailRequest';
import { DeleteFavoriteRequest } from 'src/interface/deleteFavoriteRequest';
import { FavoriteByCustomerRequest } from 'src/interface/favoriteByCustomerRequest';
import { MemberService } from 'src/service/member.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-fav',
  templateUrl: './fav.component.html',
  styleUrls: ['./fav.component.css']
})
export class FavComponent implements OnInit {
  /** 生成收藏卡片 */
  items: Cards[] = [];

  dataNotFound = false;

  /** 為了裝hashUser */
  hashuser = sessionStorage.getItem("hashuser");

  /** 為了裝CustEmail */
  custEmail: string = '';

  /** 服務Id */
  serviceId: number = 0;

  /** 裝卡片圖片的Object */
  object: any = {};

  constructor(private router: Router, private productsService: ProductsService, private memberService: MemberService) { }

  ngOnInit(): void {
    this.favoriteCard();
  }


  /** 產生卡片 */
  favoriteCard() {
    /** 先拿到custemail */
    const request0 = {
      MWHEADER: {
        MSGID: "PAWSOME-HASHCUST"
      },
      TRANRQ: {
        hashEmail: this.hashuser
      }
    }
    console.log(request0);

    this.memberService.hashCust(request0 as HASHCUSTranrq).subscribe(
      response => {
        console.log(response.TRANRS.email);
        this.custEmail = response.TRANRS.email;
        /** 打favoriteByCustomer去拿到所有卡片 */
        const request1 = {
          MWHEADER: {
            MSGID: "PAWSOME-HASHCUST"
          },
          TRANRQ: {
            custEmail: this.custEmail
          }
        }
        console.log(request1);

        this.memberService.favoriteByCustomer(request1 as FavoriteByCustomerRequest).subscribe(response1 => {
          if (response.MWHEADER.RETURNCODE === '0000') {
            console.log(response1);
            const serviceArray = response1.TRANRS.items;
            for (const service of serviceArray) {
              console.log(service.serviceId);

              // 打圖片API
              this.memberService.postGetImage(service.serviceId).subscribe(imageResponse => {
                if (imageResponse.MWHEADER.RETURNCODE === '0000') {
                  this.object = { imageUrl: imageResponse.TRANRS, name: service.serviceName };
                  this.items.push(this.object);
                  console.log(this.items);
                }
              })
            }
          } else if (response.MWHEADER.RETURNCODE === 'E702') {
            this.dataNotFound = true;
          } else {
            Swal.fire({
              icon: 'warning',
              title: '系統發生異常',
              html:
                '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
              width: 450,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
            })
          }
        })
      })


  }








  /** 收藏清單製作 */
  /** 了解更多按鈕 */
  //取得服務詳細資料，存service
  sendServiceDetail(serviceName: string) {
    this.productsService.postServiceDetailQuery(serviceName).subscribe(response => {
      if (response.MWHEADER.RETURNCODE === '0000') {
        sessionStorage.setItem('name', response.TRANRS.datas[0].name);
        this.router.navigate(['/product']);
      } else if (response.MWHEADER.RETURNCODE === '9999' || response.MWHEADER.RETURNCODE === 'E702') {
        Swal.fire({
          icon: 'warning',
          title: '系統發生異常',
          html:
            '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
        })
      }
    })
  }

  /** 取消收藏按鈕 */
  deleteFavorite(serviceName: string) {
    /** 先詢問是否取消 */
    Swal.fire({
      title: '確定要取消這個收藏嗎?',
      // showDenyButton: true,
      showCancelButton: true,
      confirmButtonText: '確定取消',
      denyButtonText: `取消`,
    }).then((result) => {
      if (result.isConfirmed) {
        /** 1.先拿到custemail */
        const request0 = {
          MWHEADER: {
            MSGID: "PAWSOME-HASHCUST"
          },
          TRANRQ: {
            hashEmail: this.hashuser
          }
        }
        console.log(request0);

        this.memberService.hashCust(request0 as HASHCUSTranrq).subscribe(
          response => {
            /** 2.用serviceName去拿serviceId */
            const request = {
              MWHEADER: {
                MSGID: "PAWSOME-SERVICEDETAIL"
              },
              TRANRQ: {
                name: serviceName
              }
            }
            console.log(request);

            this.memberService.serviceDetail(request as ServiceDetailRequest).subscribe({
              next: (response) => {
                this.serviceId = response.TRANRS.datas[0].serviceId
                /** 執行取消這件事情 */
                const request1 = {
                  MWHEADER: {
                    MSGID: "PAWSOME-DELETEFAVORITE"
                  },
                  TRANRQ: {
                    custEmail: this.custEmail,
                    serviceId: this.serviceId
                  }
                }
                this.memberService.deleteFavorite(request1 as DeleteFavoriteRequest).subscribe(response => {
                  if (response.MWHEADER.RETURNCODE === '0000') {
                    console.log(response);
                    this.items = [];
                    /** 再重新查一次 */
                    this.favoriteCard();
                    Swal.fire('取消成功', '', 'success');
                  }
                })
              }
            })
          })
      }
    })
  }






}
