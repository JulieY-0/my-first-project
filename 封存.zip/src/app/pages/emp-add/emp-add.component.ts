import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {
  DialogComponent,
  DialogData,
} from 'src/app/shared/components/dialog/dialog.component';
import {
  CommCodeItems,
  CreateEmpDataTranrq,
} from 'src/app/shared/interfaces/EmpElement';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-emp-add',
  templateUrl: './emp-add.component.html',
  styleUrls: ['./emp-add.component.css'],
  providers: [DatePipe],
})
export class EmpAddComponent implements OnInit {
  /** 密碼是否顯示 */
  hide = true;

  /** 員工權限初始值 */
  isViewer = {
    key: '2',
    value: '員工',
  };

  /** 員工狀態初始值 在職 */
  isNew = {
    key: 'n',
    value: '在職',
  };

  /** 員工性別選單 */
  sexList = [
    {
      key: 'F',
      value: '女',
    },
    {
      key: 'M',
      value: '男',
    },
  ];

  /** 最大生日日期 */
  maxDate = new Date();

  /** 員工權限選單 */
  permissionList: CommCodeItems[] = [];

  /** 異動日期 */
  currentDate: string | undefined | null;

  /** 利用 FormBuilder 群組 nonNullable 和 Validators，檢核 Input 輸入值 */
  form = this.fb.nonNullable.group({
    name: ['',
      [
        Validators.required,
        Validators.pattern(/^\S*$/),
        Validators.maxLength(20),
      ],
    ],
    tel: ['',
      [
        Validators.required,
        Validators.pattern(/^\d*$/),
        Validators.maxLength(10),
      ],
    ],
    email: ['', [Validators.required, Validators.email]],
    password: [
      '',
      [
        Validators.required,
        Validators.pattern(/^\w*$/),
        Validators.minLength(6),
        Validators.maxLength(20),
      ],
    ],
    sex: [''],
    birthday: [''],
    permissions: [this.isViewer.key, [Validators.required]],
    isQuit: [this.isNew.key, [Validators.required]],
  });

  /**
   * 取得「員工名稱」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get name(): FormControl<string | null> {
    return this.form.controls.name;
  }

  /**
   * 取得「電話」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get tel(): FormControl<string | null> {
    return this.form.controls.tel;
  }

  /**
   * 取得「信箱」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get email(): FormControl<string | null> {
    return this.form.controls.email;
  }

  /**
   * 取得「密碼」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get password(): FormControl<string | null> {
    return this.form.controls.password;
  }

  /**
   * 取得「性別」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get sex(): FormControl<string | null> {
    return this.form.controls.sex;
  }

  /**
   * 取得「生日」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get birthday(): FormControl<string | null> {
    return this.form.controls.birthday;
  }

  /**
   * 取得「權限」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get permissions(): FormControl<string | null> {
    return this.form.controls.permissions;
  }

  /**
   * 取得「狀態」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof EmpEditComponent
   */
  public get isQuit(): FormControl<string | null> {
    return this.form.controls.isQuit;
  }

  constructor(
    private fb: FormBuilder,
    private empHttpService: EmpHttpService,
    private datePipe: DatePipe,
    public dialogRef: MatDialogRef<DialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) { }

  ngOnInit(): void {
    this.empHttpService.queryMsgCode('PERMISSIONS').subscribe((res) => {
      const responseData = res;
      this.permissionList = responseData.TRANRS.items;
    });

    this.currentDate = this.datePipe.transform(new Date(), 'yyyy/MM/dd');
  }

  /** 新增員工資料 */
  addEmp() {
    const editSex = !this.form.value.sex
      ? ''
      : this.sexList.find((element) => element.key === this.form.value.sex)
        ?.value;
    const createrq = {
      ...this.form.value,
      sex: editSex,
    } as CreateEmpDataTranrq;

    this.empHttpService.addEmpData(createrq).subscribe((res) => {
      const responseData = res;
      // 新增失敗跳出提示訊息
      if (responseData.MWHEADER.RETURNCODE !== '0000') {
        Swal.fire({
          icon: 'error',
          title: '新增失敗',
          text: responseData.MWHEADER.RETURNDESC,
          width: 350,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
          confirmButtonText: '確定',
        });
        return;
      }

      if (responseData.MWHEADER.RETURNCODE === '0000') {
        Swal.fire({
          icon: 'success',
          title: '新增成功',
          width: 350,
          padding: '3em',
          background: '#fff',
        });
        this.dialogRef.close();
      }
    });
  }

  /** 關閉談窗 */
  closeDialog() {
    this.dialogRef.close();
  }
}
