import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { Order } from 'src/app/shared/interfaces/EmpElement';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import { OrderEditComponent } from '../order-edit/order-edit.component';
import { EmpDataService } from 'src/app/shared/service/emp-data.service';
import { MatDialog } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.css'],
  providers: [DatePipe],
})
export class OrderListComponent implements OnInit {

  /**
   * 分頁
   * @type {MatPaginator}
   * @memberof OrderListComponent
   */
  @ViewChild('paginator', { static: true }) paginator!: MatPaginator;

  /** 是否有修改權限 */
  isAdmin = false;

  /** 資料總筆數 */
  length = 0;

  /** 目前頁碼 預設為0 */
  pageIndex = 0;

  /** 每頁呈現幾筆 預設為5 */
  pageSize = 5;

  /** 總頁數 */
  totalPage: number | undefined;

  /** 允許切換的每頁資料筆數 */
  pageSizeOptions = [5, 10];

  /** 分頁結果 */
  pageEvent: PageEvent | undefined;

  /** 初始訂單列表全查 */
  queryOrderId: string | undefined;

  /** 是否顯示訂單明細  */
  openOrderDetail = false;

  /** 取得訂單相關資訊 */
  getOrderInfo = {
    orderId: '',
    custEmail: ''
  };

  /** 欄位名稱 */
  displayedColumns = [
    'order',
    'orderId',
    'custName',
    'custTel',
    'total',
    'confirmDate',
    'orderProcess',
    'edit',
  ];

  /** 表格資料 */
  dataSource: Order[] = [];

  /** 利用 FormBuilder 群組 nonNullable 和 Validators，檢核 Input 輸入值 */
  form = this.fb.nonNullable.group({
    orderId: ['', [Validators.pattern(/^\d*$/)]]
  });

  constructor(
    private fb: FormBuilder,
    private empHttpService: EmpHttpService,
    private dataService: EmpDataService,
    public dialog: MatDialog,
    public router: Router
  ) { }

  /**
   * 取得「訂單編號」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderListComponent
   */
  public get orderId(): FormControl<string | null> {
    return this.form.controls.orderId;
  }

  ngOnInit(): void {
    if (sessionStorage.getItem('permission') === '1') {
      this.isAdmin = true;
    }

    this.queryOrder();
  }

  /**
   * 分頁器
   * @param event
   */
  getPaginatorData(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.queryPageDatabtn(this.pageIndex, this.pageSize);
  }

  /** 初始查詢按鈕 */
  queryOrder() {
    this.pageIndex = 0;
    this.empHttpService.queryOrder(0, this.pageSize).subscribe(
      res => {
        const responseData = res;

        if (responseData.MWHEADER.RETURNCODE !== '0000') {
          Swal.fire({
            icon: 'error',
            title: '查詢失敗',
            text: responseData.MWHEADER.RETURNDESC,
            width: 350,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonText: '確定',
          })
          return;
        }

        this.length = responseData.TRANRS.orderNumber;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as Order[];
        this.dataSource = this.dataSource.map<Order>(e => ({
          ...e,
          order: 0
        }));
      });
  }

  /**
   * 分頁查詢按鈕
   * @param pageIndex
   * @param pageSize
   */
  queryPageDatabtn(pageIndex: number, pageSize: number) {
    this.empHttpService.queryOrder(pageIndex, pageSize).subscribe(
      res => {
        const responseData = res;

        this.length = responseData.TRANRS.orderNumber;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as Order[];
        this.dataSource = this.dataSource.map<Order>(e => ({
          ...e,
          order: pageIndex * pageSize
        }));
      });
  }

  /** 查詢單筆訂單資料 */
  queryOrderById() {
    this.queryOrderId = this.form.value.orderId;
    this.empHttpService.queryOrderById(0, this.pageSize, this.queryOrderId).subscribe(
      res => {
        const responseData = res;

        if (responseData.MWHEADER.RETURNCODE !== '0000') {
          Swal.fire({
            icon: 'error',
            title: '查詢失敗',
            text: responseData.MWHEADER.RETURNDESC,
            width: 350,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonText: '確定',
          })
          return;
        }

        this.length = responseData.TRANRS.totalCount;
        this.totalPage = responseData.TRANRS.totalPage;

        this.dataSource = responseData.TRANRS.items as Order[];
        this.dataSource = this.dataSource.map<Order>(e => ({
          ...e,
          order: 0
        }));
      });
  }

  queryOrderDetail(i: number) {
    this.getOrderInfo = {
      orderId: this.dataSource[i].orderId,
      custEmail: this.dataSource[i].custEmail,
    }
    this.dataService.orderInfo = this.getOrderInfo;
    this.openOrderDetail = true;
  }

  /** 全查按鈕 */
  queryAllData() {
    this.pageIndex = 0;
    this.form.patchValue({
      orderId: ''
    });
    this.queryOrder();
  }

  /** 開啟修改彈窗 */
  openEditDialog(i: number) {
    // 將訂單 Id 資料存至 dataService
    this.dataService.orderId = this.dataSource[i].orderId;

    const dialogRef = this.dialog.open(OrderEditComponent, {
      width: '55%'
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.queryPageDatabtn(this.pageIndex, this.pageSize);
    });
  }

  onQueryEmit() {
    this.queryOrder();
  }

}
