import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Service } from 'src/app/interfaces/service';
import { ProductsService } from 'src/app/services/products.service';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { SvcAvaliablePipe } from 'src/app/shared/pipes/svc-avaliable.pipe';
import { ServiceAddComponent } from '../service-add/service-add.component';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-service-list',
  templateUrl: './service-list.component.html',
  styleUrls: ['./service-list.component.css'],
  providers: [SvcAvaliablePipe]

})
export class ServiceListComponent implements OnInit {

  /**
     * 分頁
     * @type {MatPaginator}
     * @memberof EmpListComponent
     */
  @ViewChild('paginator', { static: true }) paginator!: MatPaginator;

  /** 目前頁碼 預設為0 */
  pageIndex = 0;

  /** 每頁呈現幾筆 預設為5 */
  pageSize = 5;

  /** 資料總筆數 */
  length = 0;

  /** 表格資料 */
  dataSource: Service[] = [];

  /** 允許切換的每頁資料筆數 */
  pageSizeOptions = [5, 10];

  /** 欄位名稱 */
  displayedColumns = [
    'type',
    'name',
    // 'brief',
    'petType',
    'petSizeRange',
    'price',
    'isavaliable',
    'edit',
  ];

  /** 欲搜尋服務名稱 */
  queryServiceName = '';

  /** 欲搜尋服務類別 */
  queryServiceType = '';

  /** 欲搜尋服務狀態 */
  queryServiceIsavaliable = '';

  /** 服務類別選項 */
  types = [{ status: '寵物保姆', value: '寵物保姆' },{ status: '寵物住宿', value: '寵物住宿' },
  { status: '寵物美容', value: '寵物美容' },{ status: '全部', value: '' }];

  /** 服務狀態選項 */
  isavaliables = [{ status: '上架', value: 'y' }, { status: '下架', value: 'n' }, { status: '全部', value: '' }];

  /** 查無資料 */
  dataNotFound = false;

  /** 建構表格 */
  searchForm = this.fb.nonNullable.group({
    serviceName: [''],
    type: [''],
    isavaliable: ['']
  });

  /**
   * Creates an instance of ServiceListComponent.
   * @param {FormBuilder} fb
   * @param {ProductsService} productsService
   * @param {MatDialog} dialog
   * @param {SvcAvaliablePipe} svcAvaliablePipe
   * @memberof ServiceListComponent
   */
  constructor(private fb: FormBuilder, private productsService: ProductsService, public dialog: MatDialog, private svcAvaliablePipe: SvcAvaliablePipe) { }

  ngOnInit(): void {
    this.queryServiceByName();

  }

  /**
   *
   *多條件搜尋框
   * @memberof ServiceListComponent
   */
  queryServiceByName() {
    this.pageIndex = 0;
    this.queryServiceName = this.searchForm.controls.serviceName.value;
    this.queryServiceType = this.searchForm.controls.type.value
    this.queryServiceIsavaliable = this.searchForm.controls.isavaliable.value

    this.productsService.postServiceAllFuzzyQuery(0, this.pageSize, this.queryServiceName, this.queryServiceType
      , this.queryServiceIsavaliable).subscribe(response => {

        if (response.MWHEADER.RETURNCODE === '0000') {
          this.dataNotFound = false;
          this.length = response.TRANRS.totalCount;
          this.dataSource = response.TRANRS.datas as Service[];
          this.dataSource = this.dataSource.map<Service>(e => ({
            ...e,
            isavaliable: this.svcAvaliablePipe.transform(e.isavaliable),
          })
          )
        } else if (response.MWHEADER.RETURNCODE === 'E702') {
          this.dataSource = [];
          this.dataNotFound = true;

        } else {
          Swal.fire({
            icon: 'warning',
            title: '系統發生異常',
            html:
              '請聯繫工程師尋求協助</br></br>聯絡資訊:02-00000000</br></br>地址:台北市內湖區瑞光路510號',
            width: 450,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonColor: '#ffbd4a'
          })
        }
      })
  }
  /**
   *
   *分頁器搜尋
   * @param {number} pageIndex
   * @param {number} pageSize
   * @memberof ServiceListComponent
   */
  queryPageDatabtn(pageIndex: number, pageSize: number) {
    this.productsService.postServiceAllFuzzyQuery(pageIndex, pageSize, this.queryServiceName
      , this.queryServiceType, this.queryServiceIsavaliable).subscribe(response => {

        if (response.MWHEADER.RETURNCODE === '0000') {
          this.dataNotFound = false;
          this.length = response.TRANRS.totalCount;
          this.dataSource = response.TRANRS.datas as Service[];
          this.dataSource = this.dataSource.map<Service>(e => ({
            ...e,
            isavaliable: this.svcAvaliablePipe.transform(e.isavaliable),
          })
          )
        } else if (response.MWHEADER.RETURNCODE === 'E702') {
          this.dataSource = [];
          this.dataNotFound = true;
        } else {
          Swal.fire({
            icon: 'warning',
            title: '系統發生異常',
            html:
              '請聯繫工程師尋求協助</br></br>聯絡資訊:02-00000000</br></br>地址:台北市內湖區瑞光路510號',
            width: 450,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonColor: '#ffbd4a'
          })
        }

      })
  }

  // 搜尋框
  // queryServiceByName() {
  //   this.pageIndex = 0;
  //   this.queryServiceName = this.searchForm.controls.serviceName.value;
  //   this.productsService.postServiceAllQuery(0, this.pageSize, this.queryServiceName).subscribe(response => {

  //     if (response.MWHEADER.RETURNCODE === '0000') {
  //       this.dataNotFound = false;
  //       this.length = response.TRANRS.totalCount;
  //       this.dataSource = response.TRANRS.datas as Service[];
  //       this.dataSource = this.dataSource.map<Service>(e => ({
  //         ...e,
  //         isavaliable: this.svcAvaliablePipe.transform(e.isavaliable),
  //       })
  //       )
  //     } else if (response.MWHEADER.RETURNCODE === 'E702') {
  //       this.dataSource = [];
  //       this.dataNotFound = true;

  //     } else {
  //       Swal.fire({
  //         icon: 'warning',
  //         title: '系統發生異常',
  //         html:
  //           '請聯繫工程師尋求協助</br></br>聯絡資訊:02-00000000</br></br>地址:台北市內湖區瑞光路510號',
  //         width: 450,
  //         padding: '3em',
  //         color: '#5d3f0a',
  //         background: '#fff',
  //       })
  //     }

  //   })
  // }

  // 分頁器搜尋
  // queryPageDatabtn(pageIndex: number, pageSize: number) {
  //   this.productsService.postServiceAllQuery(pageIndex, pageSize, this.queryServiceName).subscribe(response => {

  //     if (response.MWHEADER.RETURNCODE === '0000') {
  //       this.dataNotFound = false;
  //       this.length = response.TRANRS.totalCount;
  //       this.dataSource = response.TRANRS.datas as Service[];
  //       this.dataSource = this.dataSource.map<Service>(e => ({
  //         ...e,
  //         isavaliable: this.svcAvaliablePipe.transform(e.isavaliable),
  //       })
  //       )
  //     } else if (response.MWHEADER.RETURNCODE === 'E702') {
  //       this.dataSource = [];
  //       this.dataNotFound = true;
  //     } else {
  //       Swal.fire({
  //         icon: 'warning',
  //         title: '系統發生異常',
  //         html:
  //           '請聯繫工程師尋求協助</br></br>聯絡資訊:02-00000000</br></br>地址:台北市內湖區瑞光路510號',
  //         width: 450,
  //         padding: '3em',
  //         color: '#5d3f0a',
  //         background: '#fff',
  //       })
  //     }

  //   })
  // }

  /**
   *
   *開啟新增Dialog
   * @memberof ServiceListComponent
   */
  openAddDialog() {
    const dialogRef = this.dialog.open(ServiceAddComponent, {
      width: '47%'
    });
    dialogRef.afterClosed().subscribe(result => {
      this.queryPageDatabtn(this.pageIndex, this.pageSize);
    })
  }

  /**
   *
   *開啟修改Dialog
   * @param {number} i
   * @memberof ServiceListComponent
   */
  openEditDialog(i: number) {
    const dialogRef = this.dialog.open(ServiceAddComponent, {
      width: '47%',
      data: this.dataSource[i]
    });
    dialogRef.afterClosed().subscribe(result => {
      this.queryPageDatabtn(this.pageIndex, this.pageSize);

    })
  }

  /**
   *
   *取得分頁器頁碼並查詢
   * @param {PageEvent} event
   * @memberof ServiceListComponent
   */
  getPaginatorData(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.queryPageDatabtn(this.pageIndex, this.pageSize);
  }

  /**
   *
   *查詢全部資料
   * @memberof ServiceListComponent
   */
  queryServiceAll() {
    this.dataNotFound = false;
    this.searchForm.reset();
    this.queryServiceByName();


  }

}
