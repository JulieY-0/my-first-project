import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-data-not-found-dialog',
  templateUrl: './data-not-found-dialog.component.html',
  styleUrls: ['./data-not-found-dialog.component.css']
})
export class DataNotFoundDialogComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<DataNotFoundDialogComponent>,
    // @Inject(MAT_DIALOG_DATA) public data: any,
  ) {}
  ngOnInit(): void {

  }

  onConfirm(){
    this.dialogRef.close();
  }

  onCancel(){
    this.dialogRef.close();
  }

}
