import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DataNotFoundDialogComponent } from './data-not-found-dialog.component';

describe('DataNotFoundDialogComponent', () => {
  let component: DataNotFoundDialogComponent;
  let fixture: ComponentFixture<DataNotFoundDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DataNotFoundDialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DataNotFoundDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
