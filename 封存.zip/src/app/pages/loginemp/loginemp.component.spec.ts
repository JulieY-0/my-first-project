import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginempComponent } from './loginemp.component';

describe('LoginempComponent', () => {
  let component: LoginempComponent;
  let fixture: ComponentFixture<LoginempComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginempComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoginempComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
