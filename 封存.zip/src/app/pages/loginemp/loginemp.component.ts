import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { logindata } from 'src/app/core/interface/login';
import { loginEmpResponse } from 'src/app/core/interface/loginEmp';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-loginemp',
  templateUrl: './loginemp.component.html',
  styleUrls: ['./loginemp.component.css']
})
export class LoginempComponent implements OnInit {

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private loginService: LoginService,
  ) { }

  responseData = {} as loginEmpResponse;

  hide: boolean = true;

  form = this.fb.nonNullable.group({
    /**檢核必填*/
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.maxLength(15)]],
  });


  ngOnInit(): void {
  }

  text() {
    this.form.controls.email.patchValue('12233@eamail');
    this.form.controls.password.patchValue('111111');
  }

  loginemp() {
    const data: logindata = {
      email: this.form.controls.email.value,
      password: this.form.controls.password.value
    };

    this.loginService.loginemp(data).subscribe({
      next: (response) => {
        if (response) {
          this.responseData = response;
          if (response.MWHEADER.RETURNCODE === 'E001') {
            Swal.fire({
              icon: 'error',
              title: '欄位格式錯誤',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
              confirmButtonColor:'#ffbd4a',
            })
          }
          if (response.MWHEADER.RETURNCODE === 'E702') {
            Swal.fire({
              icon: 'warning',
              title: '此帳號尚未開通',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '返回',
              confirmButtonColor:'#ffbd4a',
            })
          }
          if (response.MWHEADER.RETURNCODE === 'E005') {
            Swal.fire({
              icon: 'error',
              title: '密碼錯誤',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
              confirmButtonColor:'#ffbd4a',
            })
          }
          if (response.MWHEADER.RETURNCODE === '0000') {
            sessionStorage.clear();
            this.router.navigate(['/empPawsome/emp']);
            if (response.TRANRS.items[0].email) {
              sessionStorage.setItem('hashempuser', response.TRANRS.items[0].hashEmail);
              sessionStorage.setItem('isQuit', response.TRANRS.items[0].isQuit);
            }
            sessionStorage.setItem('nav', 'emplogin')
          }
        }
      }
    });
  }

  // 聯絡資訊彈跳視窗
  contact() {
    Swal.fire({
      icon: 'info',
      title: '請聯絡客服人員',
      html: '聯絡資訊: 02-55662218</br>地址: 台北市內湖區瑞光路510號',
      width: 450,
      padding: '3em',
      color: '#5d3f0a',
      background: '#fff',
      // confirmButtonText: '再試試',
    })
  }

}
