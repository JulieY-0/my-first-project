
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRouteSnapshot, ActivatedRoute } from '@angular/router';
import { logindata } from 'src/app/core/interface/login';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';
import { Location } from '@angular/common';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private loginService: LoginService,
    private location: Location,
  ) { }

  //須加上介面
  responseData: any = {};

  hide: boolean = true;

  form = this.fb.nonNullable.group({
    /**檢核必填*/
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.maxLength(15), Validators.minLength(6)]],
  });


  ngOnInit(): void {
    this.form.reset();
  }

  register() {
    this.router.navigate(['/register']);
    if (!sessionStorage.getItem('page')) {
      sessionStorage.setItem('page', 'reg');
    }
  }

  test(){
    this.form.controls.email.patchValue('cust1@gmail.com');
    this.form.controls.password.patchValue('cust1111');
  }

  login() {
    const data: logindata = {
      email: this.form.controls.email.value,
      password: this.form.controls.password.value
    };
    this.loginService.login(data).subscribe({
      next: (response) => {
        console.log(response)
        if (response) {
          this.responseData = response;
          if (this.responseData.MWHEADER.RETURNCODE === 'E001') {
            Swal.fire({
              icon: 'error',
              title: '欄位格式錯誤',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
            })
          }
          if (this.responseData.MWHEADER.RETURNCODE === 'E702') {
            sessionStorage.setItem('registerEmail', this.form.controls.email.value);
            Swal.fire({
              icon: 'warning',
              title: '此帳號尚未註冊',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '返回',
              footer: '<a href="register">前往註冊</a>'
            })
          }
          if (this.responseData.MWHEADER.RETURNCODE === 'E005') {
            Swal.fire({
              icon: 'error',
              title: '密碼錯誤',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
            })
          }
          if (this.responseData.MWHEADER.RETURNCODE === '0000') {
            // Swal.fire({
            //   icon: 'success',
            //   title: '登入成功',
            //   width: 350,
            //   padding: '3em',
            //   background: '#fff',
            // })
            if (this.responseData.TRANRS.items[0].email) {
              sessionStorage.setItem('user', this.responseData.TRANRS.items[0].email);
              sessionStorage.setItem('hashuser', this.responseData.TRANRS.items[0].hashEmail);
              console.log(this.responseData.TRANRS.items[0].hashEmail);
            }
            sessionStorage.setItem('nav', 'login')

            // 如果登入成功就返回上一頁，唯獨從註冊進來登入完成的，回去首頁
            if (sessionStorage.getItem('page') === 'reg') {
              this.router.navigate(['/member']);
              sessionStorage.removeItem('page');
            } else {
              this.location.back();
            }
          }
        } else {
          console.log('未收到數據');
        }
      },
      error: (err) => {
        console.log('err', err);
      }
    });
  }

  // 聯絡資訊彈跳視窗
  contact() {
    Swal.fire({
      icon: 'info',
      title: '請聯絡客服人員',
      html: '聯絡資訊:02-55662218</br>地址:台北市內湖區瑞光路510號',
      width: 450,
      padding: '3em',
      color: '#5d3f0a',
      background: '#fff',
      // confirmButtonText: '再試試',
    })
  }

}
