import { PetTypePipe } from './../../shared/pipes/pet-type.pipe';
import { DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DialogComponent, DialogData } from 'src/app/shared/components/dialog/dialog.component';
import { CommCodeItems, OrderDetailDataItems, OrderOneDetailDataItems, PetList, QueryAdminTranrs, ServiceTime, UpdateOrderDetailDataTranrq } from 'src/app/shared/interfaces/EmpElement';
import { EmpDataService } from 'src/app/shared/service/emp-data.service';
import { EmpHttpService } from 'src/app/shared/service/emp-http.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-order-detail-edit',
  templateUrl: './order-detail-edit.component.html',
  styleUrls: ['./order-detail-edit.component.css'],
  providers: [DatePipe, PetTypePipe]
})
export class OrderDetailEditComponent implements OnInit {

  /** 欲修改之訂單編號 */
  selectOrderId: string | undefined;

  /** 欲修改之會員信箱 */
  selectCustEmail: string | undefined;

  /** 欲修改之訂單明細編號 */
  selectItemId: string | undefined;

  /** 最小預約日期 */
  tomorrow = new Date();

  /** 最小結束日期 */
  minEndDate = new Date();

  /** 最大預約日期 */
  maxDate = new Date();

  /** 欲修改之資料 */
  editData = {} as OrderOneDetailDataItems;

  /** 欲修改之性別 */
  selectPetName: string | undefined;

  /** 預約時間選單 */
  timeOptions: ServiceTime[] = [
    { time: '08:00-09:00' },
    { time: '09:00-10:00' },
    { time: '10:00-11:00' },
    { time: '11:00-12:00' },
    { time: '13:00-14:00' },
    { time: '14:00-15:00' },
    { time: '15:00-16:00' },
    { time: '16:00-17:00' },
    { time: '17:00-18:00' },
    { time: '18:00-19:00' },
    { time: '19:00-20:00' },
    { time: '20:00-21:00' },
    { time: '21:00-22:00' }
  ]

  /** 欲修改之預約時間 */
  selectTime: string | undefined;

  /** 會員寵物列表 */
  petList: PetList[] = [];

  /** 訂單狀態選單 */
  orderProcessList: CommCodeItems[] = [];

  /** 異動人員 */
  updateEmp = {} as QueryAdminTranrs;

  /** 異動日期 */
  currentDate: string | undefined | null;

  /** 利用 FormBuilder 群組 nonNullable 和 Validators，檢核 Input 輸入值 */
  form = this.fb.nonNullable.group({
    startDate: ['', [Validators.required]],
    endDate: [''],
    startTime: ['', [Validators.required]],
    petName: ['', [Validators.required]],
    petType: [{ value: '', disabled: true }, Validators.required],
    remarks: [''],
    price: [{ value: '', disabled: true }, Validators.required],
    orderProcess: ['', [Validators.required]]
  });

  /**
   * 取得「預約日期(起)」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get startDate(): FormControl<string | null> {
    return this.form.controls.startDate;
  }

  /**
   * 取得「預約日期(訖)」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get endDate(): FormControl<string | null> {
    return this.form.controls.endDate;
  }

  /**
   * 取得「預約時間」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get startTime(): FormControl<string | null> {
    return this.form.controls.startTime;
  }

  /**
   * 取得「寵物名稱」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get petName(): FormControl<string | null> {
    return this.form.controls.petName;
  }

  /**
   * 取得「寵物種類」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get petType(): FormControl<string | null> {
    return this.form.controls.petType;
  }

  /**
   * 取得「備註」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get remarks(): FormControl<string | null> {
    return this.form.controls.remarks;
  }

  /**
   * 取得「價格」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get price(): FormControl<string | null> {
    return this.form.controls.price;
  }

  /**
   * 取得「訂單狀態」輸入值
   * @readonly
   * @type {(FormControl<string | null>)}
   * @memberof OrderDetailEditComponent
   */
  public get orderProcess(): FormControl<string | null> {
    return this.form.controls.orderProcess;
  }

  constructor(
    private fb: FormBuilder,
    private empHttpService: EmpHttpService,
    private dataService: EmpDataService,
    private datePipe: DatePipe,
    private petTypePipe: PetTypePipe,
    public dialogRef: MatDialogRef<DialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
  ) { }

  ngOnInit(): void {
    this.selectOrderId = this.dataService.orderInfo.orderId as string;
    this.selectCustEmail = this.dataService.orderInfo.custEmail as string;
    this.selectItemId = this.dataService.orderDetailItemId as string;

    // Admin
    this.empHttpService.queryAdminData().subscribe(res => {
      const responseData = res;
      this.updateEmp = responseData.TRANRS;
    });

    // 訂單狀態選單
    this.empHttpService.queryMsgCode('ORDERPROCESS')
      .subscribe(res => {
        const responseData = res;
        this.orderProcessList = responseData.TRANRS.items;
      });

    // 查詢會員寵物資料
    this.empHttpService.queryOnePetByCust(this.selectCustEmail)
      .subscribe(res => {
        const responseData = res;
        this.petList = responseData.TRANRS.map<PetList>(e => ({
          petId: e.pet_id.toString(),
          petName: e.name,
          petType: e.type,
        }));
      });

    // 查詢單筆訂單
    this.empHttpService.queryOneOrderDetail(0, 1, this.selectOrderId, this.selectItemId).subscribe({
      next: res => {
        const responseData = res;
        this.editData = responseData.TRANRS.items[0];
        // this.selectPetName = this.editData.petName;
      },
      complete: () => {
        this.initialization();
        this.currentDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
      }
    });

    this.tomorrow.setDate(this.tomorrow.getDate() + 1);
    this.maxDate.setDate(this.tomorrow.getDate() + 91);
    this.form.get('startDate')?.valueChanges.subscribe(date => {
      this.minEndDate.setDate(new Date(date).getDate() + 1);
      this.form.controls.endDate.setValue('');
    })

  }

  /** 修改訂單狀態 */
  editOrderDetail() {
    const _startDate = !this.form.value.startDate ? '' : new Date(this.form.value.startDate);
    const _endDate = !this.form.value.endDate ? '' : new Date(this.form.value.endDate);

    const updaterq = {
      ...this.form.value,
      orderId: this.selectOrderId,
      itemId: this.selectItemId,
      petId: this.editData.petId,
      startDate: _startDate,
      endDate: _endDate,
      orderProcess: this.orderProcessList.find(element => element.msg === this.form.value.orderProcess)?.commCode
    } as UpdateOrderDetailDataTranrq;

    this.empHttpService.editOrderDetailData(updaterq).subscribe(
      res => {
        const responseData = res;
        // 修改失敗跳出提示訊息
        if (responseData.MWHEADER.RETURNCODE !== '0000') {
          Swal.fire({
            icon: 'error',
            title: '修改失敗',
            text: responseData.MWHEADER.RETURNDESC,
            width: 350,
            padding: '3em',
            color: '#5d3f0a',
            background: '#fff',
            confirmButtonText: '確定',
          })
          return;
        }

        // 修改成功跳出提示訊息
        if (responseData.MWHEADER.RETURNCODE === '0000') {
          Swal.fire({
            icon: 'success',
            title: '修改成功',
            width: 350,
            padding: '3em',
            background: '#fff',
          })
          this.dialogRef.close();
        }
      });
  }

  /** 關閉談窗 */
  closeDialog() {
    this.dialogRef.close();
  }

  /** 初始化-將選取資料帶到畫面顯示 */
  initialization() {
    // 將選取資料帶到畫面顯示
    this.form.patchValue({
      ...this.editData,
      startDate: this.editData.startDate.split(' ')[0],
      endDate: !this.editData.endDate ? "" : this.editData.endDate.split(' ')[0],
      startTime: this.editData.startTime,
      petName: this.editData.petId,
      petType: this.petTypePipe.transform(this.editData.petType),
      // price:
    });

    // 若有 endDate 多設必填 Validators
    if (this.editData.endDate) {
      this.form.get('endDate')?.setValidators(Validators.required);
      this.form.get('endDate')?.updateValueAndValidity();
    }
  }

  /** 自動帶出寵物類別 */
  setPetType() {
    for (const pet of this.petList) {
      if (pet.petId === this.form.value.petName) {
        const typeName = this.petTypePipe.transform(pet.petType);
        this.form.controls.petType.patchValue(typeName);
      }
    }
  }

  /** 自動帶出價格 */
  setPrice() {
    console.log(this.endDate.value);

    const _endDate = this.datePipe.transform(this.endDate.value, 'MM/dd/yyyy');
    const _startDate = this.datePipe.transform(this.startDate.value, 'MM/dd/yyyy');

    console.log(_endDate);
    console.log(new Date(_endDate as string));

    // return parseInt(Math.abs(new Date(_endDate as string) - new Date(_startDate as string)) / 1000 / 60 / 60 / 24);

    // console.log(new Date(this.endDate.value));

    // const price = new Date(this.endDate) - new Date(this.startDate);
    // this.form.controls.price.patchValue(price);
  }



  dateDiff(startDate: string, endDate: string) {
    // const strDate1 = endDate?.split("-");
    // const oDate1 = new Date(strDate1[1]+strDate1[2]+strDate1[0]);
    // const strDate2 = startDate?.split("-");
    // const oDate2 = new Date(strDate2[1]+strDate2[2]+strDate2[0]);
    // const result = parseInt(Math)


  }
}
