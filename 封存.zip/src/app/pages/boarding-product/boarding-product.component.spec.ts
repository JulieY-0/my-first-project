import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BoardingProductComponent } from './boarding-product.component';

describe('BoardingProductComponent', () => {
  let component: BoardingProductComponent;
  let fixture: ComponentFixture<BoardingProductComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BoardingProductComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BoardingProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
