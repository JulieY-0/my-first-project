import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MemberOrderdetailUpdateComponent } from 'src/app/pages/member-orderdetail-update/member-orderdetail-update.component';
import { OneOrderByIDRequest } from 'src/interface/oneOrderByIdRequest';
import { OneOrderDetailRequest } from 'src/interface/oneOrderDetailRequest';
import { Item } from 'src/interface/oneOrderDetailResponse';
import { Tranr } from 'src/interface/orderByCustomerResponse';
import { OrderDetailRequest } from 'src/interface/orderDetailRequest';
import { UpdateOrderDetailRequest } from 'src/interface/updateOrderDetailRequest';
import { UpdateOrderRequest } from 'src/interface/updateOrderRequest';
import { MemberService } from 'src/service/member.service';

@Component({
  selector: 'app-member-orderdetail',
  templateUrl: './member-orderdetail.component.html',
  styleUrls: ['./member-orderdetail.component.css'],
  providers: [DatePipe]
})
export class MemberOrderdetailComponent implements OnInit {
  form = this.fb.nonNullable.group({
    /** 訂單編號的FormControl */
    orderId: [''],
    // /** 會員電子信箱的FormControl*/  disabled: boolean =true
    orderProcess: [''],
    /** 會員電話的FormControl*/
    total: [''],
    confirmDate: [''],
    customer: [''],
    customerEmail: ['']
  });
  form1 = this.fb.nonNullable.group({
    customer: [''],
    customerEmail: ['']
  });
  readonlyMode: boolean = true;
  constructor(private fb: FormBuilder, private memberService: MemberService, private route: ActivatedRoute, private datePipe: DatePipe, public dialog: MatDialog, private router: Router) { }
  /**TABLE欄位*/
  displayedColumns: string[] = [
    'serviceName',
    'startDate',
    'endDate',
    'startTime',
    'petName',
    'petType',
    'remarks',
    'price',
    'update',
    'cancel'
  ];

  dataSource: Item[] = [];
  /** 分頁:總體頁數*/
  totalCount: number = 0;
  /** 分頁:從第幾筆顯示*/
  pageNumber: number = 0;
  /** 分頁:每頁顯示幾筆 */
  pageSize: number = 5;
  /** 用來存路由帶過來的訂單編號orderId*/
  orderId: string = '';

  /** 用來存路由帶過來的訂單編號orderId*/
  orderData: Tranr[] = [];
  /** 用來存查出來的item編號itemId*/
  itemId: string = '';

  isEditable: boolean = false;

  ngOnInit(): void {
    window.scrollTo(0, 0);
    this.route.queryParams.subscribe((params: Params) => { this.orderId = params['orderId']; });
    // this.route.queryParams.subscribe((params: Params) => { this.orderData = params['orderData']; });
    console.log(this.orderId);
    console.log(this.orderData);

    /** 先打一支API去拿item_id */
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-ORDERDETAIL"
      },
      TRANRQ: {
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
        orderId: this.orderId
      }
    }
    console.log(request);

    this.memberService.orderDetail(request as OrderDetailRequest).subscribe(
      response => {
        console.log(response);
        console.log(response.TRANRS.items[0].itemId);
        this.itemId = response.TRANRS.items[0].itemId;
        // this.itemId = response.TRANRS.items[0].itemId;
        /** 進頁面先帶訂單編號查詢到的資料*/
        const request1 = {
          MWHEADER: {
            MSGID: "PAWSOME-ONEORDERDETAIL"
          },
          TRANRQ: {
            pageNumber: this.pageNumber,
            pageSize: this.pageSize,
            orderId: this.orderId,
            itemId: response.TRANRS.items[0].itemId
          }
        }
        console.log(request1);

        this.memberService.oneOrderDetail(request1 as OneOrderDetailRequest).subscribe(
          response1 => {
            console.log(response1);
            this.dataSource = response1.TRANRS.items;
          })
      })
    const request1 = {
      MWHEADER: {
        MSGID: "string"
      },
      TRANRQ: {
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
        orderId: this.orderId
      }
    }
    this.memberService.oneOrderById(request1 as OneOrderByIDRequest).subscribe(
      response1 => {
        console.log(response1);
        this.form.controls.orderId.setValue(response1.TRANRS.items[0].orderId);
        this.form.controls.orderProcess.setValue(response1.TRANRS.items[0].orderProcess);
        this.form.controls.total.setValue(response1.TRANRS.items[0].total);
        const confirmDate: any = this.datePipe.transform(response1.TRANRS.items[0].confirmDate, 'yyyy-MM-dd');
        this.form.controls.confirmDate.setValue(confirmDate);
      })







  }
  /** 訂單詳情變更 */
  editOrderDetail(index: number) {
    console.log(this.itemId);

    const dialogRef = this.dialog.open(MemberOrderdetailUpdateComponent, { //打開對話框組件
      width: '800px',
      height: '850px',
      //可選項，可配置寬高與傳遞數據
      data: {
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
        orderId: this.orderId,
        itemId: this.itemId
      }
    });
    dialogRef.afterClosed().subscribe(() => { })

  }


  /** 訂單狀態案取消 */
  cancelOrder() {

  }

  /** 會員後台-預約管理詳細預約資料-取消按鈕 */
  cancel(index: number) {
    const request = {
      MWHEADER: {
        MSGID: "string"
      },
      TRANRQ: {
        orderId: "string",
        custEmail: "string",
        total: 0,
        orderProcess: "strin"
      }
    }
    this.memberService.updateOrder(request as UpdateOrderRequest).subscribe(
      response1 => {
        console.log(response1);
        // this.form.controls.orderId.setValue(response1.TRANRS.items[0].orderId);
        // this.form.controls.orderProcess.setValue(response1.TRANRS.items[0].orderProcess);
        // this.form.controls.total.setValue(response1.TRANRS.items[0].total);
        // const confirmDate: any = this.datePipe.transform(response1.TRANRS.items[0].confirmDate, 'yyyy-MM-dd');
        // this.form.controls.confirmDate.setValue(confirmDate);
      })
  }
  /** 回上一頁的按鈕 */
  backLastPage() {
    this.router.navigate(['/member']);
  }





}






