import { Customer } from './../../shared/interfaces/EmpElement';
import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HASHCUSTranrq } from 'src/app/interfaces/hashCusTranrq';
import { MemberOrderdetailUpdateComponent } from 'src/app/pages/member-orderdetail-update/member-orderdetail-update.component';
import { OneOrderByIDRequest } from 'src/interface/oneOrderByIdRequest';
import { OneOrderDetailRequest } from 'src/interface/oneOrderDetailRequest';
import { Item } from 'src/interface/oneOrderDetailResponse';
import { OrderDetailRequest } from 'src/interface/orderDetailRequest';
import { UpdateOrderDetailRequest } from 'src/interface/updateOrderDetailRequest';
import { UpdateOrderDetailResponse } from 'src/interface/updateOrderDetailResponse';
import { UpdateOrderRequest } from 'src/interface/updateOrderRequest';
import { MemberService } from 'src/service/member.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-member-orderdetail',
  templateUrl: './member-orderdetail.component.html',
  styleUrls: ['./member-orderdetail.component.css'],
  providers: [DatePipe]
})
export class MemberOrderdetailComponent implements OnInit {
  form = this.fb.nonNullable.group({
    /** 訂單編號的FormControl */
    orderId: [''],
    // /** 會員電子信箱的FormControl*/  disabled: boolean =true
    orderProcess: [''],
    /** 會員電話的FormControl*/
    total: [0],
    confirmDate: ['2023/01/01']
  });
  form1 = this.fb.nonNullable.group({
    customer: [''],
    customerEmail: [''],
    lastCancelDate: ['']
  });
  readonlyMode: boolean = true;

  /** 找出最早日期 */
  earliestDate: Date | undefined;
  lastCancelDate: Date | undefined;

  constructor(private fb: FormBuilder, private memberService: MemberService, private route: ActivatedRoute, private datePipe: DatePipe, public dialog: MatDialog, private router: Router) { }
  /**TABLE欄位*/
  displayedColumns: string[] = [
    'serviceName',
    'startDate',
    'endDate',
    'startTime',
    'petName',
    'petType',
    'remarks',
    'price',
    'cancel'
  ];

  dataSource: any[] = [];
  /** 分頁:總體頁數*/
  totalCount: number = 0;
  /** 分頁:從第幾筆顯示*/
  pageNumber: number = 0;
  /** 分頁:每頁顯示幾筆 */
  pageSize: number = 5;
  /** 用來存路由帶過來的訂單編號orderId*/
  orderId: string = '';

  /** 用來存路由帶過來的訂單編號orderId*/
  orderData: any[] = [];
  /** 用來存查出來的item編號itemId*/
  itemId: string = '';

  isEditable: boolean = false;
  /** 底下刪除按鈕 */
  cancelItems: boolean = false;

  hashuser = sessionStorage.getItem("hashuser");
  custemail: string = '';
  total: string = '';
  serviceName: string = '';
  /** 用來裝後面要更新的狀態 */
  updateOrderProcess: string = '';

  ngOnInit(): void {
    window.scrollTo(0, 0);
    this.initialize();
  }

  initialize() {
    /** 先拿到custemail */
    console.log(this.hashuser);
    const request0 = {
      MWHEADER: {
        MSGID: "PAWSOME-HASHCUST"
      },
      TRANRQ: {
        hashEmail: this.hashuser
      }
    }
    this.memberService.hashCust(request0 as HASHCUSTranrq).subscribe(
      response => {
        console.log(response);
        this.custemail = response.TRANRS.email;

      })


    this.route.queryParams.subscribe((params: Params) => { this.orderId = params['orderId']; });
    // this.route.queryParams.subscribe((params: Params) => { this.orderData = params['orderData']; });
    console.log(this.orderId);
    console.log(this.orderData);

    /** 先打一支API去拿item_id跟底下的訂單內容清單 */
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-ORDERDETAIL"
      },
      TRANRQ: {
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
        orderId: this.orderId
      }
    }
    console.log(request);

    this.memberService.orderDetail(request as OrderDetailRequest).subscribe(
      response => {
        console.log(response);
        console.log(response.TRANRS.items[0].itemId);
        this.itemId = response.TRANRS.items[0].itemId;
        this.dataSource = response.TRANRS.items;

        // 使用 Array.filter() 過濾出 orderProcess 不等於 "已取消" 的資料
        this.dataSource = this.dataSource.filter(items => items.orderProcess !== "已取消");

        /** 這邊去生出最後可以取消日 */
        this.earliestDate = this.findEarliestDate(response.TRANRS.items);
        this.lastCancelDate = this.getLastCancelDate(this.earliestDate);
        console.log(this.lastCancelDate);
        const formatLastDate = this.datePipe.transform(this.lastCancelDate, 'yyyy/MM/dd')
        this.form1.controls.lastCancelDate.setValue(formatLastDate as string);

        /** 這邊確定如果訂單只有一筆，底下的取消鈕要disabled */
        if (response.TRANRS.items.length === 1) {
          this.cancelItems = true;
        }

        /** 這邊確定如果訂單只有一筆，且訂單最後取消日已過，底下的取消鈕要disabled */
        if (response.TRANRS.items.length === 1 && !this.isCancelAllowed()) {
          console.log('只有一筆且已過期');
          this.cancelItems = true;
        }




      })
    /** 左上角的訂單資訊 */
    const request1 = {
      MWHEADER: {
        MSGID: "PAWSOME-ONEORDERBYID"
      },
      TRANRQ: {
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
        orderId: this.orderId
      }
    }
    this.memberService.oneOrderById(request1 as OneOrderByIDRequest).subscribe(
      response1 => {
        console.log(response1);
        this.form.controls.orderId.setValue(response1.TRANRS.items[0].orderId);
        this.form.controls.orderProcess.setValue(response1.TRANRS.items[0].orderProcess);
        this.total = response1.TRANRS.items[0].total;
        // const confirmDate: any = this.datePipe.transform();

        this.form.controls.confirmDate.setValue(this.datePipe.transform(response1.TRANRS.items[0].confirmDate, 'yyyy/MM/dd')!);

      })


  }









  /** 找出最早日期的方法 */
  findEarliestDate(items: any[]): Date {
    /**先拿一個當最初可以去比較的 */
    let compareDate: Date = new Date(items[0].startDate);

    for (const item of items) {
      const startDate = new Date(item.startDate);

      if (startDate < compareDate) {
        compareDate = startDate;
      }
    }
    console.log(compareDate);
    return compareDate;
  }

  /** 減三天的方法 */
  getLastCancelDate(date: Date) {
    const lastCancelDate = new Date(date);
    lastCancelDate.setDate(lastCancelDate.getDate() - 3);
    return lastCancelDate;
  }

  /** 去判斷今天是否大於最後取消日 */
  isCancelAllowed(): boolean {
    const currentDate = new Date();
    const lastCancelDate = new Date(this.form1.value.lastCancelDate!)
    return currentDate <= lastCancelDate;
  }

  /** 訂單詳情變更 */
  // editOrderDetail(index: number) {
  //   console.log(this.itemId);
  //   this.serviceName = this.dataSource[index].serviceName;
  //   const dialogRef = this.dialog.open(MemberOrderdetailUpdateComponent, { //打開對話框組件
  //     width: '700px',
  //     height: '650px',
  //     //可選項，可配置寬高與傳遞數據
  //     data: {
  //       pageNumber: this.pageNumber,
  //       pageSize: this.pageSize,
  //       orderId: this.orderId,
  //       itemId: this.itemId,
  //       serviceName: this.serviceName
  //     }
  //   });
  //   dialogRef.afterClosed().subscribe(() => { })

  // }


  /** 會員後台-預約管理詳細預約資料-取消按鈕 */
  cancel(index: number) {
    const originalItemId = this.dataSource[index].itemId;

    console.log(index);
    /** 先詢問是否要移除這筆服務 */
    Swal.fire({
      icon: 'warning',
      title: '<strong>是否要移除這筆服務？</strong>',
      showCancelButton: true,
      confirmButtonText: '<strong>確認</strong>',
      cancelButtonText: '<strong>取消</strong>',
      padding: '3em',
      background: '#fff',
      confirmButtonColor: '#ffbd4a',
      cancelButtonColor: '#5d3f0a'
    }).then((result) => {
      if (result.isConfirmed) {
        /** 先打一支oneOrderDetail去拿到這筆的資訊 */
        const request0 = {
          MWHEADER: {
            MSGID: "PAWSOME-ONEORDERDETAIL"
          },
          TRANRQ: {
            pageNumber: 0,
            pageSize: 5,
            orderId: this.orderId,
            itemId: this.dataSource[index].itemId
          }
        }
        console.log(request0);

        this.memberService.oneOrderDetail(request0).subscribe({
          next: (response0) => {
            console.log(response0);
            /** 執行取消訂單項目 UpdateOrderDetail */
            const endDate = this.datePipe.transform(response0.TRANRS.items[0].endDate, 'yyyy-MM-dd')?.toString() || '';
            const request1 = {
              MWHEADER: {
                MSGID: "PAWSOME-UPDATEORDERDETAIL"
              },
              TRANRQ: {
                orderId: this.orderId,
                itemId: originalItemId,
                startDate: this.datePipe.transform(response0.TRANRS.items[0].startDate, 'yyyy-MM-dd')?.toString(),
                endDate: endDate,
                startTime: response0.TRANRS.items[0].startTime,
                petId: response0.TRANRS.items[0].petId,
                remarks: response0.TRANRS.items[0].remarks ? response0.TRANRS.items[0].remarks : '',
                orderProcess: "3",
                updateEmp: ''
              }
            }
            console.log(request1);



            this.memberService.updateOrderDetail(request1).subscribe({
              // next: (response) => {
              //   const returnCode = response.MWHEADER.RETURNCODE;
              //   if (returnCode === '0000') {
              //     Swal.fire('取消成功', '', 'success');
              //   } else if (returnCode === 'E001') {
              //     Swal.fire({
              //       icon: 'warning',
              //       title: '<strong>必填欄位不得為空</strong>',
              //       width: 350,
              //       padding: '3em',
              //       color: '#5d3f0a',
              //       background: '#fff',
              //       confirmButtonText: '確認',
              //       confirmButtonColor: '#ffbd4a'
              //     });
              //   } else if (returnCode === 'E702') {
              //     Swal.fire({
              //       icon: 'warning',
              //       title: '<strong>查無該筆服務資料</strong>',
              //       width: 350,
              //       padding: '3em',
              //       color: '#5d3f0a',
              //       background: '#fff',
              //       confirmButtonText: '再試試',
              //       confirmButtonColor: '#ffbd4a'
              //     });
              //   } else if (returnCode === 'E004') {
              //     Swal.fire({
              //       icon: 'error',
              //       title: '<strong>刪除服務失敗</strong>',
              //       width: 350,
              //       padding: '3em',
              //       color: '#5d3f0a',
              //       background: '#fff',
              //       confirmButtonText: '再試試',
              //       confirmButtonColor: '#ffbd4a'
              //     });
              //   } else {
              //     Swal.fire({
              //       icon: 'warning',
              //       title: '<strong>其他系統異常</strong>',
              //       width: 350,
              //       padding: '3em',
              //       color: '#5d3f0a',
              //       background: '#fff',
              //       confirmButtonText: '再試試',
              //       confirmButtonColor: '#ffbd4a'
              //     });
              //   }
              // },
              // complete: () => {
              //   /** 重新更新訂單 */  /** 金額要變動 */
              //   console.log(Number(this.total));
              //   console.log(this.dataSource[index].price);
              //   if (this.form.value.orderProcess === '已確認') {
              //     this.updateOrderProcess = '1'
              //   } else if (this.form.value.orderProcess === '已完成') {
              //     this.updateOrderProcess = '2'
              //   } else if (this.form.value.orderProcess === '已取消') {
              //     this.updateOrderProcess = '3'
              //   }
              //   const request2 = {
              //     MWHEADER: {
              //       MSGID: "PAWSOME-UPDATEORDER"
              //     },
              //     TRANRQ: {
              //       orderId: this.orderId,
              //       custEmail: this.custemail,
              //       total: String(Number(this.total) - this.dataSource[index].price),
              //       orderProcess: this.updateOrderProcess
              //     }
              //   }
              //   console.log(request2);

              //   // this.memberService.updateOrderStatus(request2).subscribe(
              //     // response =>{
              //     // console.log(response);
              //     // {
              //     //   next: (response) => {

              //         /** 重新刷新列表與訂單 */ /** 初始化的事情再重新做一次 */
              //         /** 先打一支API去拿item_id跟底下的訂單內容清單 */
              //         const request = {
              //           MWHEADER: {
              //             MSGID: "PAWSOME-ORDERDETAIL"
              //           },
              //           TRANRQ: {
              //             pageNumber: this.pageNumber,
              //             pageSize: this.pageSize,
              //             orderId: this.orderId
              //           }
              //         }
              //         console.log(request);

              //         this.memberService.orderDetail(request as OrderDetailRequest).subscribe(
              //           response => {
              //             console.log(response);
              //             // console.log(response.TRANRS.items[0].itemId);
              //             // this.itemId = response.TRANRS.items[0].itemId;
              //             this.dataSource = response.TRANRS.items;

              //             // 使用 Array.filter() 過濾出 orderProcess 不等於 "已取消" 的資料
              // this.dataSource = this.dataSource.filter(items => items.orderProcess !== "已取消");

              //             /** 這邊去生出最後可以取消日 */
              //             this.earliestDate = this.findEarliestDate(response.TRANRS.items);
              //             this.lastCancelDate = this.getLastCancelDate(this.earliestDate);
              //             console.log(this.lastCancelDate);
              //             const formatLastDate = this.datePipe.transform(this.lastCancelDate, 'yyyy/MM/dd')
              //             this.form1.controls.lastCancelDate.setValue(formatLastDate as string);

              //             /** 這邊確定如果訂單只有一筆，底下的取消鈕要disabled */
              //             if (response.TRANRS.items.length === 1) {
              //               this.cancelItems = true;
              //             }

              //             /** 這邊確定如果訂單只有一筆，且訂單最後取消日已過，底下的取消鈕要disabled */
              //             if (response.TRANRS.items.length === 1 && !this.isCancelAllowed()) {
              //               console.log('只有一筆且已過期');
              //               this.cancelItems = true;
              //             }




              //           })
              //         /** 左上角的訂單資訊 */
              //         const request1 = {
              //           MWHEADER: {
              //             MSGID: "PAWSOME-ONEORDERBYID"
              //           },
              //           TRANRQ: {
              //             pageNumber: this.pageNumber,
              //             pageSize: this.pageSize,
              //             orderId: this.orderId
              //           }
              //         }
              //         console.log(request1);

              //         this.memberService.oneOrderById(request1 as OneOrderByIDRequest).subscribe(
              //           response1 => {
              //             console.log(response1);
              //             this.form.controls.orderId.setValue(response1.TRANRS.items[0].orderId);
              //             this.form.controls.orderProcess.setValue(response1.TRANRS.items[0].orderProcess);
              //             this.total = response1.TRANRS.items[0].total;
              //             // const confirmDate: any = this.datePipe.transform();

              //             this.form.controls.confirmDate.setValue(this.datePipe.transform(response1.TRANRS.items[0].confirmDate, 'yyyy/MM/dd')!);

              //           })





              //       }
              //     })

              // }
            });
          },
          complete: () => {
            this.dataSource = this.dataSource.filter(items => items.orderProcess !== "已取消");
            this.initialize();
          }
        })
        // );
        // });
      }
    })
  }
  // );

  // }

  /** 回上一頁的按鈕 */
  backLastPage() {
    this.router.navigate(['/member']);
  }




  /** 取消整筆 */
  cancelBooking() {
    /** 先詢問是否取消 */
    // Swal.fire({
    //   title: '確定要取消這筆訂單嗎?',
    // showDenyButton: true,
    //     showCancelButton: true,
    //     confirmButtonText: '確定取消',
    //     denyButtonText: `取消`,
    //   }).then((result) => {
    //     if (result.isConfirmed) {
    //       const request = {
    //         MWHEADER:
    //           MSGID: "PAWSOME-UPDATEORDER"
    //         },
    //         TRANRQ: {
    //           orderId: this.orderId,
    //   custEmail: this.custemail,
    //   total: this.total,
    //   orderProcess: "3"
    // }}

    //       console.log(request);
    // this.memberService.updateOrder(request as UpdateOrderRequest).subscribe(
    //   response1 => {
    //     console.log(response1);
    //     /** 先詢問是否取消 */

    //     /**  */
    //     if (response1.MWHEADER.RETURNCODE !== '0000') {
    //       Swal.fire({
    //         icon: 'error',
    //         title: '修改失敗',
    //         text: response1.MWHEADER.RETURNDESC,
    //         width: 350,
    //         padding: '3em',
    //         color: '#5d3f0a',
    //         background: '#fff',
    //         confirmButtonText: '確定',
    //       });
    //       return;
    //     }

    //     // 修改成功跳出提示訊息
    //     // if (response1.MWHEADER.RETURNCODE === '0000') {
    //     //   Swal.fire({
    //     //     icon: 'success',
    //     //     title: '取消成功',
    //     //     width: 350,
    //     //     padding: '3em',
    //     //     background: '#fff',
    //       // });
    //       /** 修改訂單狀態與刪除按鈕disable */
    //       // this.form.controls.orderProcess.setValue('已取消');
    //       // this.cancelItems = true;


    //     }
    //   )}
    // })}



    // }
  }



}

