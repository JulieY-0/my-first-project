import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Cards } from 'src/app/interfaces/cards';
import { ProductsService } from 'src/app/services/products.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-nanny',
  templateUrl: './nanny.component.html',
  styleUrls: ['./nanny.component.css']
})
export class NannyComponent implements OnInit {

  options: string[] = ['遛狗', '餵藥', '餵食'];
  items: Cards[] = [];


  form = this.fb.nonNullable.group({
    search: ['', Validators.required]

  });

  constructor(private fb: FormBuilder, private productsService: ProductsService, public dialog: MatDialog, private router: Router) { }

  ngOnInit(): void {
    window.scrollTo(0, 0);

    this.productsService.postServiceQuery('寵物保姆').subscribe(response => {
      if (response.MWHEADER.RETURNCODE === '0000') {
        const serviceArray = response.TRANRS.TRANRS;
        for (const service of serviceArray) {
          console.log(service.name);

          // 打圖片API
          this.productsService.postGetImage(service.serviceId).subscribe(imageResponse => {
            if (imageResponse.MWHEADER.RETURNCODE === '0000') {
              const object = { imageUrl: imageResponse.TRANRS, name: service.name };
              this.items.push(object);
              console.log(this.items);
            }
          })
        }
      } else if (response.MWHEADER.RETURNCODE === 'E702') {
        Swal.fire({
          icon: 'warning',
          title: '查無相關服務',
          html:
            '請至員工後台新增該類別服務',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
        })
      } else {
        Swal.fire({
          icon: 'warning',
          title: '系統發生異常',
          html:
            '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
        })
      }
    })
  }


  // 搜尋服務
  queryService() {
    this.items = [];
    this.productsService.postOneServiceQuery(this.form.controls.search.value).subscribe(response => {
      // 查無資料
      if (response.MWHEADER.RETURNCODE === 'E702') {
        Swal.fire({
          icon: 'warning',
          title: '查無相關服務內容',
          html:
            '請重新搜尋或' +
            '<a href="grooming">查看所有服務內容</a> ',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
        })
        // 交易成功
      } else if (response.MWHEADER.RETURNCODE === '0000') {
        const serviceArray = response.TRANRS.datas;
        for (const service of serviceArray) {
          console.log(service.name);

          // 打圖片API
          this.productsService.postGetImage(service.serviceId).subscribe(imageResponse => {
            if (imageResponse.MWHEADER.RETURNCODE === '0000') {
              const object = { imageUrl: imageResponse.TRANRS, name: service.name };
              this.items.push(object);
              console.log(this.items);
            }
          })
        }
      } else {
        Swal.fire({
          icon: 'warning',
          title: '系統發生異常',
          html:
            '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
        })
      }
    })
  }

  //取得服務詳細資料，存service
  sendServiceDetail(serviceName: string) {
    this.productsService.postServiceDetailQuery(serviceName).subscribe(response => {
      if (response.MWHEADER.RETURNCODE === '0000') {
        sessionStorage.setItem('name',response.TRANRS.datas[0].name);
        this.router.navigate(['/product']);
      } else if (response.MWHEADER.RETURNCODE === '9999' || response.MWHEADER.RETURNCODE === 'E702') {
        Swal.fire({
          icon: 'warning',
          title: '系統發生異常',
          html:
            '請聯繫店家尋求協助</br></br>聯絡資訊:02-55662218</br></br>地址:台北市內湖區瑞光路510號',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
        })
      }
    })
  }

}


