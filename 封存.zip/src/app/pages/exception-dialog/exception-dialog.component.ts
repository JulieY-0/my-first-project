import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-exception-dialog',
  templateUrl: './exception-dialog.component.html',
  styleUrls: ['./exception-dialog.component.css']
})
export class ExceptionDialogComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<ExceptionDialogComponent>,
    // @Inject(MAT_DIALOG_DATA) public data: any,
  ) {}
  ngOnInit(): void {

  }

  onConfirm(){
    this.dialogRef.close();
  }

  onCancel(){
    this.dialogRef.close();
  }

}
