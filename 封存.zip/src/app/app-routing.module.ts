import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmpauthGuard } from './core/empauth/empauth.guard';
import { AuthGuard } from './core/memberauth/auth.guard';
import { BoardingProductComponent } from './pages/boarding-product/boarding-product.component';
import { BoardingComponent } from './pages/boarding/boarding.component';
import { CartComponent } from './pages/cart/cart.component';
import { CustListComponent } from './pages/cust-list/cust-list.component';
import { EmpListComponent } from './pages/emp-list/emp-list.component';
import { EmpTestComponent } from './pages/emp-test/emp-test.component';
import { EmpComponent } from './pages/emp/emp.component';
import { GroomingComponent } from './pages/grooming/grooming.component';
import { LoginComponent } from './pages/login/login.component';
import { LoginempComponent } from './pages/loginemp/loginemp.component';
import { MainComponent } from './pages/main/main.component';
import { MemberComponent } from './pages/member/member.component';
import { NannyComponent } from './pages/nanny/nanny.component';
import { OrderDetailListComponent } from './pages/order-detail-list/order-detail-list.component';
import { OrderListComponent } from './pages/order-list/order-list.component';
import { ProductComponent } from './pages/product/product.component';
import { RegisterComponent } from './pages/register/register.component';
import { ServiceListComponent } from './pages/service-list/service-list.component';

import { MemberOrderdetailComponent } from './pages/member-orderdetail/member-orderdetail.component';
import { CalendarComponent } from './pages/calendar/calendar.component';
import { SidenavComponent } from './pages/sidenav/sidenav.component';

const routes: Routes = [
  {
    path: '', redirectTo: "/main", pathMatch: "full",
  },
  {
    path: 'main', component: MainComponent
  },
  {
    path: 'login', component: LoginComponent
  },
  {
    path: 'register', component: RegisterComponent
  },
  {
    path: 'nanny', component: NannyComponent
  },
  {
    path: 'cart', component: CartComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'member', component: MemberComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'orderDetail', component: MemberOrderdetailComponent,
  },
  {
    path: 'boarding', component: BoardingComponent
  },
  {
    path: 'empPawsome', component: SidenavComponent,
    // canActivate: [EmpauthGuard],
    children: [
      {
        path: 'emp', component: EmpComponent,
      },
      {
        path: 'empList', component: EmpListComponent,
      },
      {
        path: 'custList', component: CustListComponent,
      },
      {
        path: 'orderList', component: OrderListComponent,
      },
      {
        path: 'orderDetailList', component: OrderDetailListComponent,
      },
      {
        path: 'serviceList', component: ServiceListComponent,
      }
    ]
  },
  {
    path: 'grooming', component: GroomingComponent
  },
  {
    path: 'product', component: ProductComponent
  },
  {
    path: 'loginemp', component: LoginempComponent
  },
  {
    path: 'boardingproduct', component: BoardingProductComponent
  },
  {
    path: "",
    redirectTo: "/main",
    pathMatch: "full",
  },
];

export const appRouting = RouterModule.forRoot(routes);

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
