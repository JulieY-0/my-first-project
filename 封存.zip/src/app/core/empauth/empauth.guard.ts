import { Injectable, OnInit } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';
import { empTranrs } from '../interface/empGuard';
/**
 *
 * 員工路由守衛
 * @export
 * @class EmpauthGuard
 * @implements {CanActivate}
 */
@Injectable({
  providedIn: 'root'
})

export class EmpauthGuard implements CanActivate, OnInit {
  constructor(
    private router: Router,
    private loginService: LoginService
  ) { }

  responseData = {} as empTranrs;
  EMPData: string[] = [];

  ngOnInit(): void {

  }

  //擋如果沒有登入empuser，打購物車/url會導至EMPLOGIN
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): any {
    // 當前近來的路徑
    let url: string = state.url;
    const token = sessionStorage.getItem('hashempuser');
    const quitStatus = sessionStorage.getItem('isQuit');

    this.loginService.getEmp().subscribe({
      next: (response) => {
        if (response) {
          this.responseData = response;
          for (let i = 0; i < this.responseData.TRANRS.items.length; i++) {
            this.EMPData.push(this.responseData.TRANRS.items[i].hashEmail);
          }
        }
      },
      complete: () => {
        // 新增去查現有的憑證碼token
        if (!token) {
          // Swal.fire({
          //   icon: 'warning',
          //   title: '請輸入員工帳號',
          //   width: 350,
          //   padding: '3em',
          //   background: '#fff',
          // })
          this.router.navigate(['/loginemp']);
          return false;
        }
        //擋金鑰
        else if (!this.EMPData.includes(token)) {
          // Swal.fire({
          //   icon: 'warning',
          //   title: '請輸入員工帳號',
          //   width: 350,
          //   padding: '3em',
          //   background: '#fff',
          // })
          this.router.navigate(['/loginemp']);
          return false;
        }
        else if (quitStatus === 'y') {
          sessionStorage.clear();
          return false;
        }
        else {
          return true;
        }
      }
    });
  }


}
