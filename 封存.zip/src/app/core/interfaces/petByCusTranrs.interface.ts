import { PetByCusTranrsItems } from "./petByCusTranrsItems.interface";
import { TranrsMwheader } from "./tranrsMwheader.interface";

export interface PetByCusTranrs {
  MWHEADER: TranrsMwheader,
  TRANRS: PetByCusTranrsItems[]
}
