import { TranrsMwheader } from "./tranrsMwheader.interface";

export interface EditShareTranrs {
  MWHEADER: TranrsMwheader
}
