import { TranrsMwheader } from "./tranrsMwheader.interface";

export interface HashCustomerTranrs {
  MWHEADER: TranrsMwheader,
  TRANRS: {
    email: string
  }
}
