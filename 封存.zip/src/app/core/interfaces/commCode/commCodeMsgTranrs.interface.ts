import { TranrsMwheader } from "../tranrsMwheader.interface"
import { CommCodeMsgTranrsItems } from "./commCodeMsgTranrsItems.interface"

export interface CommCodeMsgTranrs {
  MWHEADER: TranrsMwheader,
  TRANRS: {
    items: CommCodeMsgTranrsItems[]
  }
}
