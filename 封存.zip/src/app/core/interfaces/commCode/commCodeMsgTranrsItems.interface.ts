export interface CommCodeMsgTranrsItems {
  commCode: string,
  msg: string
}
