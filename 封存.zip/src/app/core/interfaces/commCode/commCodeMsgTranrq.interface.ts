import { TranrqMwheader } from "../tranrqMwheader.interface"

export interface CommCodeMsgTranrq {
  MWHEADER: TranrqMwheader,
  TRANRQ: {
    type: string
  }
}
