import { TranrqMwheader } from "../tranrqMwheader.interface";
import { UpdateCartTranrqItems } from "./updateCartTranrqItems.interface";

export interface UpdateCartTranrq {
  MWHEADER: TranrqMwheader,
  TRANRQ: UpdateCartTranrqItems
}
