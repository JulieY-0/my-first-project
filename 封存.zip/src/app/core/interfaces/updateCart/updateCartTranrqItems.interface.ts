export interface UpdateCartTranrqItems {
  itemId: string,
  custEmail: string,
  serviceId: number,
  startDate: string,
  endDate: string | null,
  startTime: string,
  petId: number,
  remarks: string,
  isSubmit: string,
}
