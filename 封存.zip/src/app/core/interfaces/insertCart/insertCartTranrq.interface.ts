import { TranrqMwheader } from "../tranrqMwheader.interface";
import { InsertCartTranrqItems } from "./insertCartTranrqItems.interface";

export interface InsertCartTranrq {
  MWHEADER: TranrqMwheader,
  TRANRQ: InsertCartTranrqItems
}
