export interface QueryIsSubmitTranrsItems {
  itemId: string,
  serviceId: number,
  serviceName: string,
  startDate: '',
  endDate: '',
  startTime: '',
}
