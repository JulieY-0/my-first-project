import { TranrsMwheader } from "../tranrsMwheader.interface"
import { QueryIsSubmitTranrsItems } from "./queryIsSubmitTranrsItems.interface"

export interface QueryIsSubmitTranrs {
  MWHEADER: TranrsMwheader,
  TRANRS: {
    items: QueryIsSubmitTranrsItems[]
  }
}
