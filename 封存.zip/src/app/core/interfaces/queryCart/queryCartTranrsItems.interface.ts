export interface QueryCartTranrsItems {
  itemId: string,
  custEmail:string,
  serviceId: number,
  serviceName: string,
  startDate: string,
  endDate: string,
  startTime: string,
  petId: number,
  petName: string,
  petType: string,
  serviceTotalPrice: string,
  remarks: string
}
