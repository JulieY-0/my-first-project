import { TranrsMwheader } from "../tranrsMwheader.interface";
import { QueryCartTranrsItems } from "./queryCartTranrsItems.interface";

export interface QueryCartTranrs {
  MWHEADER: TranrsMwheader,
  TRANRS: {
    totalCount: number,
    items: QueryCartTranrsItems[]
  }
}
