import { TranrqMwheader } from "../tranrqMwheader.interface";
import { QueryCartTranrqItems } from "./queryCartTranrqItems.interface";

export interface QueryCartTranrq {
  MWHEADER: TranrqMwheader,
  TRANRQ: QueryCartTranrqItems
}
