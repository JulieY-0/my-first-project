import { TranrqMwheader } from "../tranrqMwheader.interface";

export interface QueryCartTranrqItems {
  custEmail: string,
  isSubmit: string
}
