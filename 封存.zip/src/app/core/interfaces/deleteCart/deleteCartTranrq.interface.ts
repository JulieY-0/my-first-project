import { TranrqMwheader } from "../tranrqMwheader.interface"

export interface DeleteCartTranrq {
  MWHEADER: TranrqMwheader,
  TRANRQ: {
    itemId: string
  }
}
