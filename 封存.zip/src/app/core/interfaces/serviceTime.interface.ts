export interface ServiceTime {
  time: string
}
