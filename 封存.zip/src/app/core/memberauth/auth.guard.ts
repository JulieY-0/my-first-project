import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import Swal from 'sweetalert2';
/**
 *
 * 會員路由守衛
 * @export
 * @class AuthGuard
 * @implements {CanActivate}
 */
@Injectable({
  providedIn: 'root'
})

export class AuthGuard implements CanActivate {

  constructor(private router: Router) { }
  //擋如果沒有登入user，打購物車/會員url會導至LOGIN
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
    //提醒要登入
    if (!sessionStorage.getItem('hashuser')) {
      Swal.fire({
        icon: 'warning',
        title: '請先登入會員',
        width: 350,
        padding: '3em',
        background: '#fff',
        confirmButtonColor:'#ffbd4a',
        confirmButtonText:'OK',
      })
      this.router.navigate(['/login']);
      return false;
    } else {
      return true;
    }
  }

}
