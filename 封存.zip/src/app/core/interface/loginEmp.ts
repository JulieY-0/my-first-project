
export interface loginEmpResponse {
  MWHEADER: Mwheader;
  TRANRS:   Tranrs;
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}

export interface Tranrs {
  items: empItem[];
}

export interface empItem {
  email:       string;
  password:    string;
  name:        string;
  tel:         string;
  sex:         string;
  birthday:    string;
  permissions: string;
  isQuit:      string;
  hashEmail:   string;
}
