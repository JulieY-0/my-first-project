
export interface login {
  MWHEADER: Mwheader;
  TRANRQ: logindata;
}

export interface Mwheader {
  MSGID: string;
}

export interface logindata {
  email: string;
  password: string;
}


export interface insertdata {
  email: string
  password: string
  confirmpassword: string
  name: string
  tel: string
  sex: string
  birthday: string
}



//insert
export interface Item {
  email: string
  password: string
  name: string
  tel: string
  sex: string
  birthday: string
}


export interface loginResponse{
  MWHEADER: Mwheader;
  TRANRS:   Tranrs;
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}

export interface Tranrs {
  items: loginItem[];
}

export interface loginItem {
  email:     string;
  name:      string;
  tel:       string;
  sex:       string;
  birthday:  string;
  hashEmail: string;
}




