import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { QueryCartTranrqItems } from '../interfaces/queryCart/queryCartTranrqItems.interface';
import { QueryCartTranrq } from '../interfaces/queryCart/queryCartTranrq.interface';
import { QueryCartTranrs } from '../interfaces/queryCart/queryCartTranrs.interface';
import { UpdateCartTranrq } from '../interfaces/updateCart/updateCartTranrq.interface';
import { UpdateCartTranrqItems } from '../interfaces/updateCart/updateCartTranrqItems.interface';
import { EditShareTranrs } from '../interfaces/editShareTranrs.interface';
import { DeleteCartTranrq } from '../interfaces/deleteCart/deleteCartTranrq.interface';
import { InsertCartTranrqItems } from '../interfaces/insertCart/insertCartTranrqItems.interface';
import { InsertCartTranrq } from '../interfaces/insertCart/insertCartTranrq.interface';
import { PetByCusTranrs } from '../interfaces/petByCusTranrs.interface';
import { QueryCartTranrsItems } from '../interfaces/queryCart/queryCartTranrsItems.interface';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  /** 儲存購物車資料筆數 */
  countInCart = new BehaviorSubject<number>(0);

  /** 取得購物車資料筆數變化 */
  countInCart$ = this.countInCart.asObservable();

  /**
   * 設置購物車資料筆數的值
   * @param count
   */
  setCountInCart(count: number): void {
    this.countInCart.next(count);
  }

  /**
   * 取得購物車資料筆數的值
   * @returns
   */
  getCountInCart(): number {
    return this.countInCart.getValue();
  }

  constructor(private http: HttpClient) { }

  /**
   * 購物車資料查詢服務
   * @param params
   * @returns
   */
  query(params: QueryCartTranrqItems) {
    const rqBody: QueryCartTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-CART'
      },
      TRANRQ: {
        custEmail: params.custEmail,
        isSubmit: params.isSubmit
      }
    };
    return this.http.post<QueryCartTranrs>('http://localhost:8080/cart', rqBody);
  }

  /**
   * 購物車資料新增服務
   * @param params
   * @returns
   */
  insert(params: InsertCartTranrqItems) {
    const rqBody: InsertCartTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-INSERTCART'
      },
      TRANRQ: {
        custEmail: params.custEmail,
        serviceId: params.serviceId,
        startDate: params.startDate,
        endDate: params.endDate,
        startTime: params.startTime,
        petId: params.petId,
        remarks: params.remarks,
        isSubmit: params.isSubmit,
      }
    };
    return this.http.post<EditShareTranrs>('http://localhost:8080/insertCart', rqBody);
  }

  /**
   * 購物車資料更新服務
   * @param params
   * @returns
   */
  update(params: UpdateCartTranrqItems) {
    const rqBody: UpdateCartTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-UPDATECART'
      },
      TRANRQ: {
        itemId: params.itemId,
        custEmail: params.custEmail,
        serviceId: params.serviceId,
        startDate: params.startDate,
        endDate: params.endDate,
        startTime: params.startTime,
        petId: params.petId,
        remarks: params.remarks,
        isSubmit: params.isSubmit,
      }
    };
    return this.http.post<EditShareTranrs>('http://localhost:8080/updateCart', rqBody);
  }

  /**
   * 購物車資料刪除服務
   * @param itemId
   * @returns
   */
  delete(itemId: string) {
    const rqBody: DeleteCartTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-DELETECART'
      },
      TRANRQ: {
        itemId: itemId
      }
    };
    return this.http.post<EditShareTranrs>('http://localhost:8080/deleteCart', rqBody);
  }

  /**
   * 單個會員寵物資料查詢
   * @param custEmail
   * @returns
   */
  petByCus(custEmail: string) {
    const rqBody = {
      MWHEADER: {
        MSGID: 'PAWSOME-ONEPETBYCUSTOMER'
      },
      TRANRQ: {
        custEmail: custEmail
      }
    };
    return this.http.post<PetByCusTranrs>('http://localhost:8080/onePetByCustomer', rqBody);
  }

  /**
   *
   * 欲更新的單筆購物車資料
   * @private
   * @type {QueryCartTranrsItems}
   * @memberof CartService
   */
  private editItem: QueryCartTranrsItems = {
    itemId: '',
    custEmail: '',
    serviceId: 0,
    serviceName: '',
    startDate: '',
    endDate: '',
    startTime: '',
    petId: 0,
    petName: '',
    petType: '',
    serviceTotalPrice: '',
    remarks: ''
  };

  /**
   * 設置editItem的值
   * @param item
   */
  setEditItem(item: QueryCartTranrsItems) {
    this.editItem = item;
  }

  /**
   * 取得editItem的值
   * @returns
   */
  getEditItem(): QueryCartTranrsItems {
    return this.editItem;
  }

}
