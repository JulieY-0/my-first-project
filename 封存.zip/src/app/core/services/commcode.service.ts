import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CommCodeMsgTranrq } from '../interfaces/commCode/commCodeMsgTranrq.interface';
import { CommCodeMsgTranrs } from '../interfaces/commCode/commCodeMsgTranrs.interface';

@Injectable({
  providedIn: 'root'
})
export class CommcodeService {

  constructor(private http: HttpClient) { }

  /**
   * 取得寵物類別列表
   * @param type
   * @returns
   */
  getPetCommCodeMsg(type: string) {
    const rqBody: CommCodeMsgTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-COMMCODEMSG'
      },
      TRANRQ: {
        type: type
      }
    };
    return this.http.post<CommCodeMsgTranrs>('http://localhost:8080/commCodeMsg', rqBody);
  }

}
