import { TestBed } from '@angular/core/testing';

import { CommcodeService } from './commcode.service';

describe('CommcodeService', () => {
  let service: CommcodeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CommcodeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
