export interface SERVICEALLFUZZYTranrq {
  MWHEADER: {
    MSGID: string;
  }
  TRANRQ: {
    pageNumber: number;
    pageSize: number;
    name: string | undefined;
    type: string | undefined;
    isavaliable: string | undefined;
  }
}
