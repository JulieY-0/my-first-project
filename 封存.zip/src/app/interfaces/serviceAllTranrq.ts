export interface SERVICEALLTranrq {
  MWHEADER: {
    MSGID: string;
  }
  TRANRQ: {
    pageNumber: number;
    pageSize: number;
    name: string | undefined;
  }
}
