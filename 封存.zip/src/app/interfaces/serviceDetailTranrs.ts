export interface ServiceDetailTranrs {
  MWHEADER: {
    MSGID: string;
    RETURNCODE: string;
    RETURNDESC: string;
  }
  TRANRS: {
    datas: Array<{
      serviceId: number;
      type: string;
      name: string;
      brief: string;
      petType: string;
      petSizeRange: string;
      price: string;
    }>
  }
}
