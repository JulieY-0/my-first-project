export interface UpdateServiceTranrs {
  MSGID: string;
  RETURNCODE: string;
  RETURNDESC: string;
}
