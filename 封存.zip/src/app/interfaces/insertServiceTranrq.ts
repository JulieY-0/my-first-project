export interface InsertServiceTranrq {
  MWHEADER: {
    MSGID: string;
  }
  TRANRQ: {
    serviceId: any;
    type: string;
    name: string;
    brief: string;
    petType: string;
    petSizeRange: string;
    price: string;
    isavaliable: string;
  }
}

