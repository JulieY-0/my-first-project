export interface InsertServiceTranrs {
  MWHEADER: {
    MSGID: string;
    RETURNCODE: string;
    RETURNDESC: string;
  }
  TRANRS: {
    serviceId: number;
  }
}
