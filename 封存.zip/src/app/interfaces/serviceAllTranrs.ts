export interface SERVICEALLTranrs {
  MWHEADER: {
    MSGID: string;
    RETURNCODE: string;
    RETURNDESC: string;
  }
  TRANRS: {
    totalCount: number;
    datas: Array<{
      serviceId: number;
      type: string;
      name: string;
      brief: string;
      petType: string;
      petSizeRange: string;
      price: string;
      isavaliable: string;
    }>
  }
}
