export interface HASHCUSTranrq {
  MWHEADER: {
    MSGID: string;
  }
  TRANRQ: {
    hashEmail: string;
  }
}
