export interface ServiceTranrs {
  MWHEADER: {
    MSGID: string
    RETURNCODE: string
    RETURNDESC: string
  }
  TRANRS: {
    TRANRS: Array<{
      serviceId: number
      name: string
    }>
  }
}
