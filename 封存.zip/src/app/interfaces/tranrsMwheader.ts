export interface TranrsMwheader {
  MSGID: string;
  RETURNCODE: string;
  RETURNDESC: string;
}
