export interface OneServiceTranrs {
  MWHEADER: {
    MSGID: string;
    RETURNCODE: string;
    RETURNDESC: string;
  }
  TRANRS: {
    datas: Array<{
      serviceId: number;
      name: string;
    }>
  }
}
