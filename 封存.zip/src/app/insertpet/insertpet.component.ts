import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { typeArrInterface } from 'src/interface/commCodeMsgResponse';
import { Item } from 'src/interface/oneCustomerResponse';
import { MemberService } from 'src/service/member.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-insertpet',
  templateUrl: './insertpet.component.html',
  styleUrls: ['./insertpet.component.css']
})
export class InsertpetComponent implements OnInit {
  typeArr: typeArrInterface[] = []

  form = this.fb.nonNullable.group({
    petName: ['', Validators.required],
    type: ['', Validators.required],
    sex: [''],
    birth: [''],
    weight: [''],
    remarks: ['']
  });
  constructor(private memberService: MemberService, private fb: FormBuilder, public dialogRef: MatDialogRef<InsertpetComponent>) { }

  ngOnInit(): void {
    const request = {
      MWHEADER: {
        MSGID: 'PAWSOME-COMMCODEMSG'
      },
      TRANRQ: {
        type: 'PET'
      }
    }
    this.memberService.typeData(request).subscribe(
      response => {
        console.log(response.TRANRS.items);

        this.typeArr = response.TRANRS.items;

      });

  }
  /** 新增頁面的確定新增按鈕 */
  insertData() {
    const request = {
      MWHEADER: {
        "MSGID": "PAWSOME-INSERTPET"
      },
      TRANRQ: {
        custEmail: "123@gmail.com",
        petName: this.form.value.petName,
        petType: this.form.value.type,
        sex: this.form.value.sex,
        birth: this.form.value.birth,
        weight: this.form.value.weight,
        remarks: this.form.value.remarks
      }
    }
    this.memberService.insertData(request).subscribe(
      response => {
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: '新增成功',
          showConfirmButton: false,
          timer: 1500
        })

      });

  }

  /**新增頁面的回上一頁按鈕 */
  editBack() {

  }
  close() {
    this.dialogRef.close();
  }

}
