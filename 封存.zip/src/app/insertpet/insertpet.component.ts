import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { typeArrInterface } from 'src/interface/commCodeMsgResponse';
import { Item } from 'src/interface/oneCustomerResponse';
import { MemberService } from 'src/service/member.service';
import Swal from 'sweetalert2';
import { HASHCUSTranrq } from '../interfaces/hashCusTranrq';
@Component({
  selector: 'app-insertpet',
  templateUrl: './insertpet.component.html',
  styleUrls: ['./insertpet.component.css']
})
export class InsertpetComponent implements OnInit {
  typeArr: typeArrInterface[] = [];
  hashuser = sessionStorage.getItem("hashuser");
  custemail: string = '';

  form = this.fb.nonNullable.group({
    petName: ['', Validators.required],
    type: ['', Validators.required],
    sex: [''],
    birth: [''],
    weight: ['', [Validators.pattern('^((\\d+)|(0.\\d{1,2})|([1-9]\\d*.\\d{1,2}))$'), Validators.min(0.1), Validators.max(99)]],
    remarks: ['']
  });
  constructor(private memberService: MemberService, private fb: FormBuilder, public dialogRef: MatDialogRef<InsertpetComponent>) { }

  ngOnInit(): void {
    /** 先拿到custemail */
    console.log(this.hashuser);
    const request0 = {
      MWHEADER: {
        MSGID: "PAWSOME-HASHCUST"
      },
      TRANRQ: {
        hashEmail: this.hashuser
      }
    }
    this.memberService.hashCust(request0 as HASHCUSTranrq).subscribe(
      response => {
        console.log(response);
        this.custemail = response.TRANRS.email;

      })







    const request = {
      MWHEADER: {
        MSGID: 'PAWSOME-COMMCODEMSG'
      },
      TRANRQ: {
        type: 'PET'
      }
    }
    this.memberService.typeData(request).subscribe(
      response => {
        console.log(response.TRANRS.items);

        this.typeArr = response.TRANRS.items;

      });

  }
  /** 新增頁面的確定新增按鈕 */
  insertData() {
    if (this.form.controls.petName.invalid || this.form.controls.type.invalid) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: '寵物名稱與種類必填!!',
      })
      return;
    }

    const request = {
      MWHEADER: {
        "MSGID": "PAWSOME-INSERTPET"
      },
      TRANRQ: {
        custEmail: this.custemail,
        petName: this.form.value.petName,
        petType: this.form.value.type,
        sex: this.form.value.sex,
        birth: this.form.value.birth,
        weight: this.form.value.weight,
        remarks: this.form.value.remarks
      }
    }
    console.log(request);

    this.memberService.insertData(request).subscribe(
      response => {
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: '新增成功',
          showConfirmButton: false,
          timer: 1500
        })

      });

  }

  /**新增頁面的回上一頁按鈕 */
  editBack() {

  }
  close() {
    this.dialogRef.close();
  }
  /** 測試按鈕 */
  test() {
    this.form.controls.petName.setValue('小呆呆');
    this.form.controls.type.setValue('1');
    this.form.controls.sex.setValue('F');




  }

}
