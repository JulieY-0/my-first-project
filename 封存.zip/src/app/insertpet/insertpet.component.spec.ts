import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InsertpetComponent } from './insertpet.component';

describe('InsertpetComponent', () => {
  let component: InsertpetComponent;
  let fixture: ComponentFixture<InsertpetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InsertpetComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InsertpetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
