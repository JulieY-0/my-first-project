import { Component, OnInit } from '@angular/core';
import { OnePetByCustomerRequest } from 'src/interface/onePetByCustomerRequest';
import { Tranr } from 'src/interface/onePetByCustomerResponse';
import { Pet } from 'src/interface/pet';
import { MemberService } from 'src/service/member.service';
import { InsertpetComponent } from '../insertpet/insertpet.component';
import { MatDialog } from '@angular/material/dialog';
import { UpdatepetComponent } from '../updatepet/updatepet.component';
import Swal from 'sweetalert2';
import { DeletePetRequest } from 'src/interface/deletePetRequest';

@Component({
  selector: 'app-member-pet',
  templateUrl: './member-pet.component.html',
  styleUrls: ['./member-pet.component.css']
})
export class MemberPetComponent implements OnInit {

  constructor(private memberService: MemberService, public dialog: MatDialog) { }

  /**TABLE欄位*/
  displayedColumns: string[] = [
    'number',
    'name',
    'type',
    'sex',
    'birth',
    'weight',
    'remarks',
    'update',
    'delete'
  ];

  dataSource: Tranr[] = [];
  ngOnInit(): void {
    /** 會員寵物列表 */
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-ONEPETBYCUSTOMER"
      },
      TRANRQ: {
        custEmail: '123@gmail.com',
      }
    }
    this.memberService.onePetByCustomer(request as OnePetByCustomerRequest).subscribe(
      response => {
        console.log(response);
        this.dataSource = response.TRANRS;
      })

  }
  /** 點加號跳新增寵物Dialog */
  insertPet() {
    const dialogRef = this.dialog.open(InsertpetComponent, { //打開對話框組件
      width: '800px',
      height: '800px',
      //可選項，可配置寬高與傳遞數據
      data: {

      }
    });
    dialogRef.afterClosed().subscribe(() => {
      console.log('回來');
      /** 再打一次會員寵物列表 */
      const request = {
        MWHEADER: {
          MSGID: "PAWSOME-ONEPETBYCUSTOMER"
        },
        TRANRQ: {
          custEmail: '123@gmail.com',
        }
      }
      this.memberService.onePetByCustomer(request as OnePetByCustomerRequest).subscribe(
        response => {
          console.log(response);
          this.dataSource = response.TRANRS;
        })

    });

  }
  /** 點下寵物列表中的修改按鈕 */
  updateOnePet(i: number) {
    console.log(i);
    console.log(this.dataSource[i].pet_id);
    const dialogRef = this.dialog.open(UpdatepetComponent, { //打開對話框組件
      width: '800px',
      height: '800px',
      //可選項，可配置寬高與傳遞數據
      data: {
        petId: this.dataSource[i].pet_id
      }
    });
    dialogRef.afterClosed().subscribe(() => {
      console.log('回來');
      /** 再打一次會員寵物列表 */
      const request = {
        MWHEADER: {
          MSGID: "PAWSOME-ONEPETBYCUSTOMER"
        },
        TRANRQ: {
          custEmail: '123@gmail.com',
        }
      }
      this.memberService.onePetByCustomer(request as OnePetByCustomerRequest).subscribe(
        response => {
          console.log(response);
          this.dataSource = response.TRANRS;
        })

    });
  }

  /** 點下寵物列表中的刪除按鈕*/
  deleteSelectedRows(i: number) {
    /** 先詢問是否刪除 */
    Swal.fire({
      title: '確定要刪除這筆寵物資料嗎?',
      // showDenyButton: true,
      showCancelButton: true,
      confirmButtonText: '確認刪除',
      denyButtonText: `取消`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        const request = {
          MWHEADER: {
            MSGID: "PAWSOME-DELETEPET"
          },
          TRANRQ: {
            petId: this.dataSource[i].pet_id,
          }
        }
        this.memberService.deletePet(request as DeletePetRequest).subscribe(
          response => {
            /** 再打一次會員寵物列表 */
            const request = {
              MWHEADER: {
                MSGID: "PAWSOME-ONEPETBYCUSTOMER"
              },
              TRANRQ: {
                custEmail: '123@gmail.com',
              }
            }
            this.memberService.onePetByCustomer(request as OnePetByCustomerRequest).subscribe(
              response => {
                console.log(response);
                this.dataSource = response.TRANRS;
              })
            console.log(response);
            Swal.fire('刪除成功', '', 'success');

          })
      }



    })




  }








}
