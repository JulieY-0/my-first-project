import { Component, OnInit } from '@angular/core';
import { PageEvent } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { OrderByCustomerRequest } from 'src/interface/orderByCustomerRequest';
import { Item } from 'src/interface/orderByCustomerResponse';
import { UpdateOrderRequest } from 'src/interface/updateOrderRequest';
import { MemberService } from 'src/service/member.service';
import Swal from 'sweetalert2';
import { FormBuilder, FormControl } from '@angular/forms';
import { HASHCUSTranrq } from '../interfaces/hashCusTranrq';
import { OrderByCustomerAndIDRequest } from 'src/interface/orderByCustomerAndIdRequest';

@Component({
  selector: 'app-member-order',
  templateUrl: './member-order.component.html',
  styleUrls: ['./member-order.component.css']
})
export class MemberOrderComponent implements OnInit {
  form = this.fb.nonNullable.group({
    orderId: [''],
    orderProcess: [''],
    startDate: ['']
  });
  constructor(private memberService: MemberService, private router: Router, private fb: FormBuilder) { }
  /**TABLE欄位*/
  displayedColumns: string[] = [
    'orderId',
    'total',
    'confirmDate',
    'orderProcess',
    'viewMore'
  ];

  dataSource: Item[] = [];

  /** 分頁:總體頁數*/
  totalCount: number = 20;
  /** 分頁:從第幾筆顯示*/
  pageNumber: number = 0;
  /** 分頁:每頁顯示幾筆 */
  pageSize: number = 5;
  hashuser = sessionStorage.getItem("hashuser");
  custemail: string = '';
  /** 沒有訂單的情況 */
  noOrder: boolean = true;
  ngOnInit(): void {
    /** 先拿到custemail */
    console.log(this.hashuser);
    const request0 = {
      MWHEADER: {
        MSGID: "PAWSOME-HASHCUST"
      },
      TRANRQ: {
        hashEmail: this.hashuser
      }
    }
    this.memberService.hashCust(request0 as HASHCUSTranrq).subscribe({
      next: (response) => {

        console.log(response);
        this.custemail = response.TRANRS.email;
        this.queryOrderByCust();



      }

    }
    )
    console.log(this.custemail);

    // /** 會員訂單列表 */
    // const request = {
    //   MWHEADER: {
    //     MSGID: "PAWSOME-ONEPETBYCUSTOMER"
    //   },
    //   TRANRQ: {
    //     custEmail: this.custemail,
    //     pageNumber: this.pageNumber,
    //     pageSize: this.pageSize,
    //     totalCount: this.totalCount
    //   }
    // }
    // console.log(request);

    // this.memberService.orderByCustomer(request as OrderByCustomerRequest).subscribe(
    //   response => {
    //     console.log(response);
    //     this.dataSource = response.TRANRS.items;
    //     this.totalCount = response.TRANRS.totalCount;
    //   })

    // this.queryOrderByCust();

  }


  /** 查看更多按鈕 */
  viewMore(index: number) {
    this.router.navigate(['/orderDetail'], { queryParams: { orderId: this.dataSource[index].orderId }, skipLocationChange: true })
    // this.router.navigate(['/orderDetail'], { queryParams: { orderData: this.dataSource[index]} })
  }

  /** 會員管理-會員預約管理取消按鈕*/
  // cancel(index: number) {
  //   console.log(this.custemail);

  //   /** 先詢問是否取消 */
  //   Swal.fire({
  //     title: '確定要取消這筆訂單嗎?',
  //     // showDenyButton: true,
  //     showCancelButton: true,
  //     confirmButtonText: '確定取消',
  //     denyButtonText: `取消`,
  //   }).then((result) => {
  //     /* Read more about isConfirmed, isDenied below */
  //     console.log(this.dataSource[index].orderId);

  //     if (result.isConfirmed) {
  //       const request = {
  //         MWHEADER: {
  //           MSGID: "PAWSOME-UPDATEORDER"
  //         },
  //         TRANRQ: {
  //           orderId: this.dataSource[index].orderId,
  //           custEmail: this.custemail,
  //           total: this.dataSource[index].total,
  //           orderProcess: "3"
  //         }
  //       }
  //       this.memberService.updateOrder(request as UpdateOrderRequest).subscribe(
  //         response1 => {
  //           console.log(response1);

  //         })
  //       Swal.fire('取消成功', '', 'success');
  //     }
  //     /** 會員訂單列表 */
  //     const request = {
  //       MWHEADER: {
  //         MSGID: "PAWSOME-ORDERBYCUSTOMER"
  //       },
  //       TRANRQ: {
  //         custEmail: this.custemail,
  //         pageNumber: this.pageNumber,
  //         pageSize: this.pageSize,
  //         totalCount: this.totalCount
  //       }
  //     }
  //     console.log(request);

  //     this.memberService.orderByCustomer(request as OrderByCustomerRequest).subscribe(
  //       response => {
  //         console.log(response);
  //         this.dataSource = response.TRANRS.items;
  //       })

  //   })
  // }





  //當前頁變化時執行
  OnPageChange(pageEvent: PageEvent) {
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-ORDERBYCUSTOMER"
      },
      TRANRQ: {
        custEmail: this.custemail,
        pageNumber: pageEvent.pageIndex,
        pageSize: pageEvent.pageSize,
        totalCount: 0
      }
    }
    this.memberService.orderByCustomer(request as OrderByCustomerRequest).subscribe(
      response => {
        console.log(response);
        this.dataSource = response.TRANRS.items;
        this.totalCount = response.TRANRS.totalCount;
      })






  }



  queryOrderByCust() {
    /** 會員訂單列表 */
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-ONEPETBYCUSTOMER"
      },
      TRANRQ: {
        custEmail: this.custemail,
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
        totalCount: this.totalCount
      }
    }
    console.log(request);

    this.memberService.orderByCustomer(request as OrderByCustomerRequest).subscribe(
      response => {
        console.log(response);
        if (response.MWHEADER.RETURNCODE== 'E702') {
          this.noOrder = false;
          return;
        }

        this.dataSource = response.TRANRS.items;
        this.totalCount = response.TRANRS.totalCount;
      })
  }


  /**
  * 取得 input orderProcess
  * @readonly
  * @type {(FormControl<string | null>)}
  * @memberof FormComponent
  */
  public get orderProcess(): FormControl<string | null> {
    return this.form.controls.orderProcess;
  }

  /** 訂單搜尋 */
  orderSerach() {
    const request = {
      MWHEADER: {
        MSGID: "PAWSOME-ONEPETBYCUSTOMER"
      },
      TRANRQ: {
        custEmail: this.custemail,
        orderId: this.form.value.orderId,
        pageSize: this.pageSize,
        totalCount: this.totalCount
      }
    }
    console.log(request);

    this.memberService.orderByCustomerAndId(request as OrderByCustomerAndIDRequest).subscribe(
      response => {
        console.log(response);
        this.dataSource = response.TRANRS.items;
        // this.totalCount = response.TRANRS.totalCount;
      })
  }






}













