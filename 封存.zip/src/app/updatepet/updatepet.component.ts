import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { typeArrInterface } from 'src/interface/commCodeMsgResponse';
import { MemberService } from 'src/service/member.service';
import Swal from 'sweetalert2';
import { HASHCUSTranrq } from '../interfaces/hashCusTranrq';
import { CartService } from '../core/services/cart.service';

export interface DialogData {
  petId: string;
}

@Component({
  selector: 'app-updatepet',
  templateUrl: './updatepet.component.html',
  styleUrls: ['./updatepet.component.css']
})
export class UpdatepetComponent implements OnInit {
  typeArr: typeArrInterface[] = []
  form = this.fb.nonNullable.group({
    petName: ['', Validators.required],
    type: ['', Validators.required],
    sex: [''],
    birth: [''],
    weight: ['',[ Validators.pattern('^((\\d+)|(0.\\d{1,2})|([1-9]\\d*.\\d{1,2}))$'),Validators.min(0.1),Validators.max(99)]],
    remarks: ['']
  });
  hashuser = sessionStorage.getItem("hashuser");
  custemail: string = '';
  constructor(private memberService: MemberService, private fb: FormBuilder, public dialogRef: MatDialogRef<UpdatepetComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) { }

  ngOnInit(): void {
    /** 先拿到custemail */
    console.log(this.hashuser);
    const request0 = {
      MWHEADER: {
        MSGID: "PAWSOME-HASHCUST"
      },
      TRANRQ: {
        hashEmail: this.hashuser
      }
    }
    this.memberService.hashCust(request0 as HASHCUSTranrq).subscribe(
      {
        next: (response) => {
          console.log(response);
          this.custemail = response.TRANRS.email;
        }
      })


    const request = {
      MWHEADER: {
        MSGID: 'PAWSOME-COMMCODEMSG'
      },
      TRANRQ: {
        type: 'PET'
      }
    }
    this.memberService.typeData(request).subscribe(

      {
        next: (response) => {
          console.log(response);
          this.typeArr = response.TRANRS.items;
        }
      });

    console.log(this.data.petId);

    /** 修改按鈕點進去要先載入選取的那筆資料剛剛的資料(用Dialog帶pet_id過來) */
    const request1 = {
      MWHEADER: {
        MSGID: 'PAWSOME-ONEPETBYID'
      },
      TRANRQ: {
        petId: Number(this.data.petId)
      }
    }
    this.memberService.onePetById(request1).subscribe(
      response1 => {
        console.log(response1);


        this.form.controls.petName.setValue(response1.TRANRS[0].name);
        this.form.controls.type.setValue(response1.TRANRS[0].type);
        this.form.controls.sex.setValue(response1.TRANRS[0].sex);
        this.form.controls.birth.setValue(response1.TRANRS[0].birth);
        this.form.controls.weight.setValue(response1.TRANRS[0].weight);
        this.form.controls.remarks.setValue(response1.TRANRS[0].remarks);

      });
  }
  /** 修改頁面的確定修改按鈕 */
  updateData() {
    if (this.form.controls.petName.invalid || this.form.controls.type.invalid) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: '寵物名稱與種類必填!!',
      })
      return;
    }

    /** 先拿到custemail */
    console.log(this.hashuser);
    const request0 = {
      MWHEADER: {
        MSGID: "PAWSOME-HASHCUST"
      },
      TRANRQ: {
        hashEmail: this.hashuser
      }
    }
    this.memberService.hashCust(request0 as HASHCUSTranrq).subscribe({
      next: (response) => {
        console.log(response);
        this.custemail = response.TRANRS.email;
      }
    });

    const request = {
      MWHEADER: {
        "MSGID": "PAWSOME-UPDATEPET"
      },
      TRANRQ: {
        petId: Number(this.data.petId),
        custEmail: this.custemail,
        petName: this.form.value.petName,
        petType: this.form.value.type,
        sex: this.form.value.sex,
        birth: this.form.value.birth,
        weight: this.form.value.weight,
        remarks: this.form.value.remarks
      }
    }
    console.log(request);

    this.memberService.updatePet(request).subscribe(
      response => {
        console.log(response);
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: '修改成功',
          showConfirmButton: false,
          timer: 1500
        })
      });
    this.dialogRef.close();



  }

  /**修改頁面的取消按鈕 */
  back() {
    this.dialogRef.close();

  }
  close() {
    this.dialogRef.close();
  }

  /** 修改按鈕要修改剛剛的資料(用Dialog帶pet_id過來) */


}
