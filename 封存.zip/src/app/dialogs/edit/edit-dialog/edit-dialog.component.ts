import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { CommCodeMsgTranrs } from 'src/app/core/interfaces/commCode/commCodeMsgTranrs.interface';
import { CommCodeMsgTranrsItems } from 'src/app/core/interfaces/commCode/commCodeMsgTranrsItems.interface';
import { PetByCusTranrsItems } from 'src/app/core/interfaces/petByCusTranrsItems.interface';
import { QueryCartTranrqItems } from 'src/app/core/interfaces/queryCart/queryCartTranrqItems.interface';
import { QueryCartTranrsItems } from 'src/app/core/interfaces/queryCart/queryCartTranrsItems.interface';
import { ServiceTime } from 'src/app/core/interfaces/serviceTime.interface';
import { UpdateCartTranrqItems } from 'src/app/core/interfaces/updateCart/updateCartTranrqItems.interface';
import { CartService } from 'src/app/core/services/cart.service';
import { CommcodeService } from 'src/app/core/services/commcode.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-dialog',
  templateUrl: './edit-dialog.component.html',
  styleUrls: ['./edit-dialog.component.css']
})
export class EditDialogComponent implements OnInit {

  /** startDate datepicker最小可選取日 */
  tomorrow: Date = new Date();
  /** endDate datepicker最小可選取日 */
  minEndDate: Date = new Date();
  /** datepicker最大可選取日 */
  maxDate: Date = new Date();
  /** 取得寵物種類 */
  petTypeOptions: CommCodeMsgTranrsItems[] = [];
  /** 取得會員寵物列表 */
  petByCusOptions: PetByCusTranrsItems[] = [];
  /** 購物車ID */
  itemId: string = '';
  /** 會員信箱 */
  custEmail: string = '';
  /** 服務ID */
  serviceId: number = 0;
  /** 預約日期 */
  startDate: string | null = '';
  /** 預約時間 */
  endDate: string | null = '';
  /** 取得cartService的editItem 預設為空 */
  item: QueryCartTranrsItems = {
    itemId: '',
    custEmail: '',
    serviceId: 0,
    serviceName: '',
    startDate: '',
    endDate: '',
    startTime: '',
    petId: 0,
    petName: '',
    petType: '',
    serviceTotalPrice: '',
    remarks: ''
  };
  /** 預約時間欄位 */
  timeOptions: ServiceTime[] = [
    { time: '08:00-09:00' },
    { time: '09:00-10:00' },
    { time: '10:00-11:00' },
    { time: '11:00-12:00' },
    { time: '13:00-14:00' },
    { time: '14:00-15:00' },
    { time: '15:00-16:00' },
    { time: '16:00-17:00' },
    { time: '17:00-18:00' },
    { time: '18:00-19:00' },
    { time: '19:00-20:00' },
    { time: '20:00-21:00' },
    { time: '21:00-22:00' }
  ]

  constructor(private fb: FormBuilder, private commCodeService: CommcodeService, private cartService: CartService, private diologRef: MatDialogRef<EditDialogComponent>, private datePipe: DatePipe) { }

  /** updateCartForm */
  updateCartForm = this.fb.nonNullable.group({
    serviceName: [{ value: '', disabled: true }, Validators.required],
    startDate: ['', Validators.required],
    endDate: [''],
    startTime: ['', Validators.required],
    petId: [0, Validators.required],
    petType: [{ value: '', disabled: true }, Validators.required],
    remarks: ['']
  });

  /**
   * 設定datepicker最大及最小可選取日期
   * 當使用者變動預約日期，則讓他重選結束日期
   * 取得cartService中editItem帶入dialog各欄位
   * 取得會員寵物名稱列表及寵物類別列表
   */
  ngOnInit(): void {
    this.tomorrow.setDate(this.tomorrow.getDate() + 1);
    this.maxDate.setDate(this.maxDate.getDate() + 91);
    this.updateCartForm.get('startDate')?.valueChanges.subscribe(date => {
      this.minEndDate.setDate(new Date(date).getDate() + 1);
      this.updateCartForm.controls.endDate.setValue('');
    })
    this.item = this.cartService.getEditItem();
    this.itemId = this.item.itemId;
    this.custEmail = this.item.custEmail;
    this.serviceId = this.item.serviceId;
    this.updateCartForm.patchValue({
      serviceName: this.item.serviceName,
      startDate: this.item.startDate,
      endDate: this.item.endDate,
      startTime: this.item.startTime,
      petId: this.item.petId,
      petType: this.item.petType,
      remarks: this.item.remarks
    })
    if (this.item.endDate) {
      this.updateCartForm.get('endDate')?.setValidators(Validators.required);
      this.updateCartForm.get('endDate')?.updateValueAndValidity();
    }
    this.commCodeService.getPetCommCodeMsg('PET').subscribe((rs: CommCodeMsgTranrs) => {
      this.petTypeOptions = rs.TRANRS.items;
    });
    this.cartService.petByCus(this.custEmail).subscribe(rs => {
      this.petByCusOptions = rs.TRANRS;
      for (const petByCus of this.petByCusOptions) {
        if (petByCus.pet_id === this.updateCartForm.controls.petId.value) {
          this.updateCartForm.controls.petType.patchValue(petByCus.type);
        }
      }
    });
  }

  /**
   * 購物車資料更新服務
   */
  onEdit() {
    this.startDate = this.datePipe.transform(this.updateCartForm.controls.startDate.value, 'yyyy-MM-dd');
    if (this.item.endDate) {
      this.endDate = this.datePipe.transform(this.updateCartForm.controls.endDate.value, 'yyyy-MM-dd');
    }
    const input: UpdateCartTranrqItems = {
      itemId: this.itemId,
      custEmail: this.custEmail,
      serviceId: this.serviceId,
      startDate: this.startDate!,
      endDate: this.endDate,
      startTime: this.updateCartForm.controls.startTime.value,
      petId: this.updateCartForm.controls.petId.value,
      remarks: this.updateCartForm.controls.remarks.value,
      isSubmit: 'n'
    }
    const inputQueryCartAlreadySubmit: QueryCartTranrqItems = {
      custEmail: this.custEmail,
      isSubmit: 'y'
    };
    this.cartService.query(inputQueryCartAlreadySubmit).subscribe(rs => {
      rs.TRANRS.items.map(itemsInOreder => {
        if (input.serviceId === itemsInOreder.serviceId) {
          if (input.startDate === itemsInOreder.startDate) {
            if (input.endDate === null) {
              if (input.startTime === itemsInOreder.startTime) {
                Swal.fire({
                  icon: 'warning',
                  html: '請修改預約日期或預約時間</br>該日期之該時段已無空位',
                  padding: '3em',
                  color: '#5d3f0a',
                  background: '#fff',
                  confirmButtonText: '確認',
                });
              }
            } else if (input.startDate < itemsInOreder.endDate) {
              Swal.fire({
                icon: 'warning',
                html: '請修改預約日期或預約時間</br>該日期之該時段已無空位',
                padding: '3em',
                color: '#5d3f0a',
                background: '#fff',
                confirmButtonText: '確認',
              });
            } else {
              this.cartService.update(input).subscribe(rs => {
                const returnCode = rs.MWHEADER.RETURNCODE;
                if (returnCode === '0000') {
                  this.diologRef.close();
                  Swal.fire({
                    icon: 'success',
                    title: '修改完成',
                    width: 350,
                    padding: '3em',
                    background: '#fff',
                    confirmButtonText: '確認'
                  }).then((result) => {
                    if (result.isConfirmed) {
                      location.reload();
                    }
                  });
                } else if (returnCode === 'E001') {
                  Swal.fire({
                    icon: 'warning',
                    title: '必填欄位不得為空',
                    width: 350,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonText: '確認',
                  });
                } else if (returnCode === 'E002') {
                  Swal.fire({
                    icon: 'error',
                    title: '更新失敗',
                    width: 350,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonText: '再試試',
                  });
                } else if (returnCode === 'E702') {
                  Swal.fire({
                    icon: 'warning',
                    title: '查無該筆購物車資料',
                    width: 350,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonText: '再試試',
                  });
                } else {
                  Swal.fire({
                    icon: 'warning',
                    title: '其他系統異常',
                    width: 350,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonText: '再試試',
                  });
                }
              });
            }
          }
        }
      });
    });
    const inputQueryCartNotSubmit: QueryCartTranrqItems = {
      custEmail: this.custEmail,
      isSubmit: 'n'
    };
    this.cartService.query(inputQueryCartNotSubmit).subscribe(rs => {
      rs.TRANRS.items.map(itemsInCart => {
        if (input.serviceId === itemsInCart.serviceId) {
          if (input.startDate === itemsInCart.startDate) {
            if (input.endDate === null) {
              if (input.startTime === itemsInCart.startTime) {
                Swal.fire({
                  icon: 'warning',
                  html: '請修改預約日期或預約時間</br>購物車已有相同時間之服務',
                  padding: '3em',
                  color: '#5d3f0a',
                  background: '#fff',
                  confirmButtonText: '確認',
                });
              }
            } else if (input.endDate === itemsInCart.endDate) {
              Swal.fire({
                icon: 'warning',
                html: '請修改預約日期或預約時間</br>購物車已有相同時間之服務',
                padding: '3em',
                color: '#5d3f0a',
                background: '#fff',
                confirmButtonText: '確認',
              });
              return;
            } else {
              this.cartService.update(input).subscribe(rs => {
                const returnCode = rs.MWHEADER.RETURNCODE;
                if (returnCode === '0000') {
                  this.diologRef.close();
                  Swal.fire({
                    icon: 'success',
                    title: '修改完成',
                    width: 350,
                    padding: '3em',
                    background: '#fff',
                    confirmButtonText: '確認'
                  }).then((result) => {
                    if (result.isConfirmed) {
                      location.reload();
                    }
                  });
                } else if (returnCode === 'E001') {
                  Swal.fire({
                    icon: 'warning',
                    title: '必填欄位不得為空',
                    width: 350,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonText: '確認',
                  });
                } else if (returnCode === 'E002') {
                  Swal.fire({
                    icon: 'error',
                    title: '更新失敗',
                    width: 350,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonText: '再試試',
                  });
                } else if (returnCode === 'E702') {
                  Swal.fire({
                    icon: 'warning',
                    title: '查無該筆購物車資料',
                    width: 350,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonText: '再試試',
                  });
                } else {
                  Swal.fire({
                    icon: 'warning',
                    title: '其他系統異常',
                    width: 350,
                    padding: '3em',
                    color: '#5d3f0a',
                    background: '#fff',
                    confirmButtonText: '再試試',
                  });
                }
              });
            }
          }
        }
      })
    });

  }

  /**
   * 點擊取消按鈕
   */
  onCancel() {
    this.diologRef.close(false);
  }

  /**
   * 選取寵物名稱觸發
   */
  setPetType() {
    for (const petByCus of this.petByCusOptions) {
      if (petByCus.pet_id === this.updateCartForm.controls.petId.value) {
        this.updateCartForm.controls.petType.patchValue(petByCus.type);
      }
    }
  }

}
