import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { combineLatest } from 'rxjs';
import { CommCodeMsgTranrs } from 'src/app/core/interfaces/commCode/commCodeMsgTranrs.interface';
import { CommCodeMsgTranrsItems } from 'src/app/core/interfaces/commCode/commCodeMsgTranrsItems.interface';
import { PetByCusTranrsItems } from 'src/app/core/interfaces/petByCusTranrsItems.interface';
import { QueryCartTranrqItems } from 'src/app/core/interfaces/queryCart/queryCartTranrqItems.interface';
import { QueryCartTranrsItems } from 'src/app/core/interfaces/queryCart/queryCartTranrsItems.interface';
import { ServiceTime } from 'src/app/core/interfaces/serviceTime.interface';
import { UpdateCartTranrqItems } from 'src/app/core/interfaces/updateCart/updateCartTranrqItems.interface';
import { CartService } from 'src/app/core/services/cart.service';
import { CommcodeService } from 'src/app/core/services/commcode.service';
import { ServiceDetailTranrs } from 'src/app/interfaces/serviceDetailTranrs';
import { ProductsService } from 'src/app/services/products.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-dialog',
  templateUrl: './edit-dialog.component.html',
  styleUrls: ['./edit-dialog.component.css']
})
export class EditDialogComponent implements OnInit {

  /** startDate datepicker最小可選取日 */
  tomorrow: Date = new Date();
  /** endDate datepicker最小可選取日 */
  minEndDate: Date = new Date();
  /** startDate datepicker最大可選取日 */
  maxDate: Date = new Date();
  /** endDate datepicker最大可選取日 */
  maxEndDate: Date = new Date();
  /** 取得寵物種類 */
  petTypeOptions: CommCodeMsgTranrsItems[] = [];
  /** 取得會員寵物列表 */
  petByCusOptions: PetByCusTranrsItems[] = [];
  /** 購物車ID */
  itemId: string = '';
  /** 會員信箱 */
  custEmail: string = '';
  /** 服務ID */
  serviceId: number = 0;
  /** 預約日期 */
  startDate: string | null = '';
  /** 預約時間 */
  endDate: string | null = '';
  /** 取得cartService的editItem 預設為空 */
  item: QueryCartTranrsItems = {
    itemId: '',
    custEmail: '',
    serviceId: 0,
    serviceName: '',
    startDate: '',
    endDate: '',
    startTime: '',
    petId: 0,
    petName: '',
    petType: '',
    serviceTotalPrice: '',
    remarks: ''
  };
  /** 預約時間欄位 */
  timeOptions: ServiceTime[] = [
    { time: '08:00-09:00' },
    { time: '09:00-10:00' },
    { time: '10:00-11:00' },
    { time: '11:00-12:00' },
    { time: '13:00-14:00' },
    { time: '14:00-15:00' },
    { time: '15:00-16:00' },
    { time: '16:00-17:00' },
    { time: '17:00-18:00' },
    { time: '18:00-19:00' },
    { time: '19:00-20:00' },
    { time: '20:00-21:00' },
    { time: '21:00-22:00' }
  ]
  /** 服務限制種類 */
  petType: string = '';
  /** 服務限制體重 */
  petSizeRange: string = '';

  constructor(private fb: FormBuilder, private commCodeService: CommcodeService, private cartService: CartService, private productsService: ProductsService, private dialogRef: MatDialogRef<EditDialogComponent>, private datePipe: DatePipe) { }

  /** updateCartForm */
  updateCartForm = this.fb.nonNullable.group({
    serviceName: [{ value: '', disabled: true }, Validators.required],
    startDate: ['', Validators.required],
    endDate: [''],
    startTime: ['', Validators.required],
    petId: [0, Validators.required],
    petType: [{ value: '', disabled: true }, Validators.required],
    remarks: ['']
  });

  /**
   * 設定datepicker最大及最小可選取日期
   * 當使用者變動預約日期，則讓他重選結束日期
   * 取得cartService中editItem帶入dialog各欄位
   * 取得會員寵物名稱列表及寵物類別列表並篩選符合條件的毛孩
   */
  ngOnInit(): void {
    this.tomorrow.setDate(this.tomorrow.getDate() + 1);
    this.maxDate.setDate(this.maxDate.getDate() + 31);
    this.updateCartForm.get('startDate')?.valueChanges.subscribe(date => {
      const selectedDate = new Date(date);
      this.minEndDate = new Date(selectedDate);
      this.minEndDate.setDate(this.minEndDate.getDate() + 1);
      this.maxEndDate = new Date(selectedDate);
      this.maxEndDate.setDate(this.maxEndDate.getDate() + 91);
      this.updateCartForm.controls.endDate.setValue('');
    });
    this.item = this.cartService.getEditItem();
    this.itemId = this.item.itemId;
    this.custEmail = this.item.custEmail;
    this.serviceId = this.item.serviceId;
    this.updateCartForm.patchValue({
      serviceName: this.item.serviceName,
      startDate: this.item.startDate,
      endDate: this.item.endDate,
      startTime: this.item.startTime,
      petId: this.item.petId,
      petType: this.item.petType,
      remarks: this.item.remarks
    });
    if (this.item.endDate) {
      this.updateCartForm.get('endDate')?.setValidators(Validators.required);
      this.updateCartForm.get('endDate')?.updateValueAndValidity();
    }
    this.commCodeService.getPetCommCodeMsg('PET').subscribe((rs: CommCodeMsgTranrs) => {
      this.petTypeOptions = rs.TRANRS.items;
    });
    this.productsService.postServiceDetailQuery(this.item.serviceName).subscribe((rs: ServiceDetailTranrs) => {
      rs.TRANRS.datas.map(data => {
        this.petType = data.petType;
        this.petSizeRange = data.petSizeRange;
      });
    });
    this.cartService.petByCus(this.custEmail).subscribe(rs => {
      this.petByCusOptions = rs.TRANRS;
      if (this.petType === '狗狗') {
        this.petByCusOptions = this.petByCusOptions.filter((pet) => pet.type === '2' && +pet.weight <= +this.petSizeRange);
      } else if (this.petType === '貓貓') {
        this.petByCusOptions = this.petByCusOptions.filter((pet) => pet.type === '1' && +pet.weight <= +this.petSizeRange);
      } else {
        this.petByCusOptions = this.petByCusOptions.filter((pet) => +pet.weight <= +this.petSizeRange);
      }
      // 篩選後就沒有寵物的話
      if (this.petByCusOptions.length === 0) {
        Swal.fire({
          icon: 'warning',
          title: '您未有不超過' + this.petSizeRange + '公斤的' + this.petType,
          html: '請至<a href="http://localhost:4200/member">會員專區</a></br>修改或新增該類型毛孩以利後續預約',
          width: 450,
          padding: '3em',
          color: '#5d3f0a',
          background: '#fff',
        });
      }
      for (const petByCus of this.petByCusOptions) {
        if (petByCus.pet_id === this.updateCartForm.controls.petId.value) {
          this.updateCartForm.controls.petType.patchValue(petByCus.type);
        }
      }
    });
  }

  /**
   * 購物車資料更新服務
   */
  onEdit() {
    this.startDate = this.datePipe.transform(this.updateCartForm.controls.startDate.value, 'yyyy-MM-dd');
    if (this.item.endDate) {
      this.endDate = this.datePipe.transform(this.updateCartForm.controls.endDate.value, 'yyyy-MM-dd');
    }
    const input: UpdateCartTranrqItems = {
      itemId: this.itemId,
      custEmail: this.custEmail,
      serviceId: this.serviceId,
      startDate: this.startDate!,
      endDate: this.endDate,
      startTime: this.updateCartForm.controls.startTime.value,
      petId: this.updateCartForm.controls.petId.value,
      remarks: this.updateCartForm.controls.remarks.value,
      isSubmit: 'n'
    };
    const inputQueryCartNotSubmit: QueryCartTranrqItems = {
      custEmail: this.custEmail,
      isSubmit: 'n'
    };
    const isSubmit: string = 'y'
    combineLatest([this.cartService.query(inputQueryCartNotSubmit), this.cartService.queryCartIsSubmit(isSubmit)]).subscribe(([notSubmitRs, isSubmitRs]) => {
      let hasWarning = false;
      notSubmitRs.TRANRS.items.map(itemsInCart => {
        if (input.itemId !== itemsInCart.itemId && //排除同一筆
          input.serviceId === itemsInCart.serviceId && //是否與購物車中相同服務
          input.startDate === itemsInCart.startDate) { //是否與購物車中相同預約日
          if (input.endDate === '' && input.startTime === itemsInCart.startTime) { //是否與購物車相同時間
            hasWarning = true;
            Swal.fire({
              icon: 'warning',
              html: '請修改預約日期或預約時間</br>購物車已有相同時間之服務',
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '確認',
              confirmButtonColor: '#ffbd4a'
            });
          } else if (input.endDate === itemsInCart.endDate) { //是否與購物車相同結束日
            hasWarning = true;
            Swal.fire({
              icon: 'warning',
              html: '請修改預約日期或預約時間</br>購物車已有相同時間之服務',
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '確認',
              confirmButtonColor: '#ffbd4a'
            });
          }
        }
      });

      isSubmitRs.TRANRS.items.map(itemsInOrder => {
        if (input.serviceId === itemsInOrder.serviceId) { //是否與訂單中相同服務
          if (input.startDate === itemsInOrder.startDate) { //是否與訂單中相同預約日
            if (input.endDate === '') { //若為非過夜
              if (input.startTime === itemsInOrder.startTime) { //是否與訂單中相同時間
                hasWarning = true;
                Swal.fire({
                  icon: 'warning',
                  html: '請修改預約日期或預約時間</br>該日期之該時段已無空位',
                  padding: '3em',
                  color: '#5d3f0a',
                  background: '#fff',
                  confirmButtonText: '確認',
                  confirmButtonColor: '#ffbd4a'
                });
              }
            } else if (input.endDate) {  //只要相同預約日，不論結束日為何皆無空位
              hasWarning = true;
              Swal.fire({
                icon: 'warning',
                html: '請修改預約日期或預約時間</br>該日期之該時段已無空位',
                padding: '3em',
                color: '#5d3f0a',
                background: '#fff',
                confirmButtonText: '確認',
                confirmButtonColor: '#ffbd4a'
              });
            } // 訂單11/1-11/4 10/31-11/2
          } else if (input.endDate !== '') {
            if (input.startDate < itemsInOrder.startDate && input.endDate! > itemsInOrder.startDate) { //當預約日早於訂單預約日且結束日晚於訂單預約日（時間與訂單重疊）
              hasWarning = true;
              Swal.fire({
                icon: 'warning',
                html: '請修改預約日期或預約時間</br>該日期之該時段已無空位',
                padding: '3em',
                color: '#5d3f0a',
                background: '#fff',
                confirmButtonText: '確認',
                confirmButtonColor: '#ffbd4a'
              }); //11/2-11/3
            } else if (input.startDate > itemsInOrder.startDate && input.startDate < itemsInOrder.endDate) {  //當預約日晚於訂單預約日且早於訂單結束日（在訂單日期之間發生）
              hasWarning = true;
              Swal.fire({
                icon: 'warning',
                html: '請修改預約日期或預約時間</br>該日期之該時段已無空位',
                padding: '3em',
                color: '#5d3f0a',
                background: '#fff',
                confirmButtonText: '確認',
                confirmButtonColor: '#ffbd4a'
              });
            }
          }
        }
      });
      if (!hasWarning) {
        this.cartService.update(input).subscribe(rs => {
          const returnCode = rs.MWHEADER.RETURNCODE;
          if (returnCode === '0000') {
            this.dialogRef.close(true);
            Swal.fire({
              icon: 'success',
              title: '修改完成',
              width: 350,
              padding: '3em',
              background: '#fff',
              confirmButtonText: '確認',
              confirmButtonColor: '#ffbd4a'
            });
          } else if (returnCode === 'E001') {
            Swal.fire({
              icon: 'warning',
              title: '必填欄位不得為空',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '確認',
              confirmButtonColor: '#ffbd4a'
            });
          } else if (returnCode === 'E002') {
            Swal.fire({
              icon: 'error',
              title: '更新失敗',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
              confirmButtonColor: '#ffbd4a'
            });
          } else if (returnCode === 'E702') {
            Swal.fire({
              icon: 'warning',
              title: '查無該筆購物車資料',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
              confirmButtonColor: '#ffbd4a'
            });
          } else {
            Swal.fire({
              icon: 'warning',
              title: '其他系統異常',
              width: 350,
              padding: '3em',
              color: '#5d3f0a',
              background: '#fff',
              confirmButtonText: '再試試',
              confirmButtonColor: '#ffbd4a'
            });
          }
        });
      }
    });
  }

  /**
   * 點擊取消按鈕
   */
  onCancel() {
    this.dialogRef.close(false);
  }

  /**
   * 選取寵物名稱觸發
   */
  setPetType() {
    for (const petByCus of this.petByCusOptions) {
      if (petByCus.pet_id === this.updateCartForm.controls.petId.value) {
        this.updateCartForm.controls.petType.patchValue(petByCus.type);
      }
    }
  }

}
