import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { GetImageResponse } from 'src/interface/getImageResponse';
import { DELETESERVICETranrq } from '../interfaces/deleteServiceTranrq';
import { Imagers } from '../interfaces/imagers';
import { InsertServiceTranrq } from '../interfaces/insertServiceTranrq';
import { InsertServiceTranrs } from '../interfaces/insertServiceTranrs';
import { OneServiceTranrq } from '../interfaces/oneServiceTranrq';
import { OneServiceTranrs } from '../interfaces/oneServiceTranrs';
import { PetsTranrq } from '../interfaces/pets-tranrq';
import { PetsTranrs } from '../interfaces/pets-tranrs';
import { SERVICEALLTranrq } from '../interfaces/serviceAllTranrq';
import { SERVICEALLTranrs } from '../interfaces/serviceAllTranrs';
import { ServiceDetailTranrq } from '../interfaces/serviceDetailTranrq';
import { ServiceDetailTranrs } from '../interfaces/serviceDetailTranrs';
import { ServiceTranrq } from '../interfaces/serviceTranrq';
import { ServiceTranrs } from '../interfaces/serviceTranrs';
import { TranrsMwheader } from '../interfaces/tranrsMwheader';
import { UpdateServiceTranrq } from '../interfaces/updateServiceTranrq';
import { UpdateServiceTranrs } from '../interfaces/updateServiceTranrs';
import { SERVICEALLFUZZYTranrq } from '../interfaces/serviceallfuzzytranrq';
import { SERVICEALLFUZZYTranrs } from '../interfaces/serviceallfuzzytranrs';


@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  serviceDetailResponse = {} as ServiceDetailTranrs;

  constructor(private http: HttpClient) { }

  // 顯示小服務
  postServiceQuery(type: string) {
    const serviceQueryUrl = 'http://localhost:8080/service';
    const request: ServiceTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-SERVICE'
      },
      TRANRQ: {
        type: type
      }
    }
    return this.http.post<ServiceTranrs>(serviceQueryUrl, request)
  }

  // 顯示小服務細節
  postServiceDetailQuery(name: string | null) {
    const serviceDetailQueryUrl = 'http://localhost:8080/serviceDetail';
    const request: ServiceDetailTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-SERVICEDETAIL'
      },
      TRANRQ: {
        name: name
      }
    }
    return this.http.post<ServiceDetailTranrs>(serviceDetailQueryUrl, request)
  }

  // 服務搜尋框
  postOneServiceQuery(name: string | null, type: string) {
    const oneServiceQueryUrl = 'http://localhost:8080/oneService';
    const request: OneServiceTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-ONESERVICE'
      },
      TRANRQ: {
        name: name,
        type: type
      }
    }
    return this.http.post<OneServiceTranrs>(oneServiceQueryUrl, request)
  }

  // 更新服務
  postUpdateService(serviceId: number, type: string, name: string, brief: string, petType: string, petSizeRange: string, price: string, isavaliable: string) {
    const updateServiceUrl = 'http://localhost:8080/updateService';
    const request: UpdateServiceTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-UPDATESERVICE'
      },
      TRANRQ: {
        serviceId: serviceId,
        type: type,
        name: name,
        brief: brief,
        petType: petType,
        petSizeRange: petSizeRange,
        price: price,
        isavaliable: isavaliable
      }
    }
    return this.http.post<UpdateServiceTranrs>(updateServiceUrl, request)
  }

  postDeleteService(serviceId: number) {
    const deleteServiceUrl = 'http://localhost:8080/deleteService';
    const request: DELETESERVICETranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-DELETESERVICE'
      },
      TRANRQ: {
        serviceId: serviceId
      }
    }
    return this.http.post<TranrsMwheader>(deleteServiceUrl, request)
  }


  // 新增服務
  postInsertService(type: string, name: string, brief: string, petType: string, petSizeRange: string, price: string, isavaliable: string) {
    const insertServiceUrl = 'http://localhost:8080/insertService';
    const request: InsertServiceTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-INSERTSERVICE'
      },
      TRANRQ: {
        serviceId: null,
        type: type,
        name: name,
        brief: brief,
        petType: petType,
        petSizeRange: petSizeRange,
        price: price,
        isavaliable: isavaliable
      }
    }
    return this.http.post<InsertServiceTranrs>(insertServiceUrl, request)
  }

  // 取得圖片
  postGetImage(imageId: number) {
    const GetImageUrl = 'http://localhost:8080/images/' + imageId;
    return this.http.get<Imagers>(GetImageUrl)
  }

  // 取得灰色圖片
  getImage() {
    let url = 'http://localhost:8080/images/0000';
    return this.http.get<GetImageResponse>(url);
  }

  // TODO先暫時寫取得寵物
  postPetQuery(custEmail: string | null) {
    const PetQueryUrl = 'http://localhost:8080/onePetByCustomer';
    const request: PetsTranrq = {
      MWHEADER: {
        MSGID: 'string'
      },
      TRANRQ: {
        custEmail: custEmail
      }
    }
    return this.http.post<PetsTranrs>(PetQueryUrl, request)
  }

  // 取得所有服務&搜尋服務
  postServiceAllQuery(pageNumber: number, pageSize: number, name: string | undefined) {
    const serviceAllQueryUrl = 'http://localhost:8080/serviceAll';
    const request: SERVICEALLTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-SERVICEALL'
      },
      TRANRQ: {
        pageNumber: pageNumber,
        pageSize: pageSize,
        name: name
      }
    }
    return this.http.post<SERVICEALLTranrs>(serviceAllQueryUrl, request)
  }


  // TODO先暫時寫轉換email
  //  postHashCusQuery(hashEmail: string) {
  //   const HashCusQueryUrl = 'http://localhost:8080/hashCustomer';
  //   const request: HASHCUSTranrq = {
  //     MWHEADER: {
  //       MSGID: 'PAWSOME-hashCustomer'
  //     },
  //     TRANRQ: {
  //       hashEmail: hashEmail
  //     }
  //   }
  //   return this.http.post<HASHCUSTranrs>(HashCusQueryUrl, request)
  // }

  // 取得所有服務&搜尋服務
  postServiceAllFuzzyQuery(pageNumber: number, pageSize: number, name: string | undefined, type: string | undefined, isavaliable: string | undefined) {
    const serviceAllFuzzyQueryUrl = 'http://localhost:8080/serviceAllFuzzy';
    const request: SERVICEALLFUZZYTranrq = {
      MWHEADER: {
        MSGID: 'PAWSOME-SERVICEALLFUZZY'
      },
      TRANRQ: {
        pageNumber: pageNumber,
        pageSize: pageSize,
        name: name,
        type: type,
        isavaliable: isavaliable
      }
    }
    return this.http.post<SERVICEALLFUZZYTranrs>(serviceAllFuzzyQueryUrl, request)
  }

}


