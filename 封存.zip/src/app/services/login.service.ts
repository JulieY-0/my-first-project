import { Item, logindata } from 'src/app/core/interface/login';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }

  registerEmail: string = '';

  /**
   * login登入
   */
  login(data: logindata) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    const urlLogin = 'http://localhost:8080/loginCustomer';
    const postData = {
      "MWHEADER": {
        "MSGID": "PAWSOME-loginCustomer"
      },
      "TRANRQ":
        data
    };
    return this.http.post<string[]>(urlLogin, postData, { headers });
  }

  /**
   * loginemp登入
   */
  loginemp(data: logindata) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    const urlLogin = 'http://localhost:8080/loginEmp';
    const postData = {
      "MWHEADER": {
        "MSGID": "PAWSOME-loginEmp"
      },
      "TRANRQ":
        data
    };
    return this.http.post<string[]>(urlLogin, postData, { headers });
  }

  /**
   * 寵物數字
   * @returns
   */
  petNumber() {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    const urlLogin = 'http://localhost:8080/pet';
    const postData = {
      "MWHEADER": {
        "MSGID": "PAWSOME-PET"
      },
    };
    return this.http.post<string[]>(urlLogin, postData, { headers });
  }
  /**
   * 會員人數
   * @returns
   */
  cusNumber() {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    const urlLogin = 'http://localhost:8080/customer';
    const postData = {
      "MWHEADER": {
        "MSGID": "PAWSOME-CUSTOMER"
      },
      "TRANRQ": {
        "pageNumber": 0,
        "pageSize": 5
      }
    };
    return this.http.post<string[]>(urlLogin, postData, { headers });
  }
  /**
   * 訂單人數
   * @returns
   */
  orderNumber() {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    const urlLogin = 'http://localhost:8080/order';
    const postData = {
      "MWHEADER": {
        "MSGID": "PAWSOME-ORDER"
      },
      "TRANRQ": {
        "pageNumber": 0,
        "pageSize": 5
      }
    };
    return this.http.post<string[]>(urlLogin, postData, { headers });
  }
  /**
   * 註冊
   * @param data
   * @returns
   */
  insert(data: Item) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    const urlLogin = 'http://localhost:8080/insertCustomer';
    const postData = {
      "MWHEADER": {
        "MSGID": "PAWSOME-insertCustomer"
      },
      "TRANRQ": {
        "items":
          [data]
      }
    };
    return this.http.post<string[]>(urlLogin, postData, { headers });
  }

  getEmp() {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    const urlLogin = 'http://localhost:8080/emp';
    const postData = {
        "MWHEADER": {
          "MSGID": "string"
        },
        "TRANRQ": {
          "pageNumber": 0,
          "pageSize": 100,
          "email": ""
        }
    };
    return this.http.post<string[]>(urlLogin, postData, { headers });
  }




}

