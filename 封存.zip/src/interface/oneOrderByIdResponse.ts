export interface OneOrderByIDResponse {
  MWHEADER: Mwheader;
  TRANRS:   Tranrs;
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}

export interface Tranrs {
  totalPage:  number;
  totalCount: number;
  pageNumber: number;
  pageSize:   number;
  items:      Item[];
}

export interface Item {
  orderId:      string;
  custEmail:    string;
  custName:     string;
  custTel:      string;
  total:        string;
  orderProcess: string;
  confirmDate:  string;
}
