export interface FavoriteByCustomerResponse {
  MWHEADER: Mwheader;
  TRANRS:   Tranrs;
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}

export interface Tranrs {
  items: Item[];
}

export interface Item {
  custEmail:   string;
  serviceId:   string;
  serviceName: string;
}
