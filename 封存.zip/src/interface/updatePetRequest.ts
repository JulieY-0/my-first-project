export interface UpdatePetRequest {
  MWHEADER: Mwheader;
  TRANRQ:   Tranrq;
}

export interface Mwheader {
  MSGID: string;
}

export interface Tranrq {
  petId:     number | undefined;
  custEmail: string | undefined;
  petName:   string | undefined;
  petType:   string | undefined;
  sex:       string | undefined;
  birth:     string | undefined;
  weight:    string | undefined;
  remarks:   string | undefined;
}
