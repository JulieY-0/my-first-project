export interface UpdateImageResponse {
  MWHEADER: Mwheader;
  TRANRS:   null;
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}
