export interface LoginCustResponse {
  MWHEADER: Mwheader;
  TRANRS:   Tranrs;
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}

export interface Tranrs {
  items: Item[];
}

export interface Item {
  email:     string;
  name:      string;
  tel:       string;
  sex:       string;
  birthday:  string;
  hashEmail: string;
}
