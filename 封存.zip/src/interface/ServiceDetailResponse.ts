export interface ServiceDetailResponse {
  MWHEADER: Mwheader;
  TRANRS:   Tranrs;
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}

export interface Tranrs {
  datas: Data[];
}

export interface Data {
  serviceId:    number;
  type:         string;
  name:         string;
  brief:        string;
  petType:      string;
  petSizeRange: string;
  price:        string;
}
