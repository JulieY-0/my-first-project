export interface CartResponse {
  MWHEADER: Mwheader;
  TRANRS:   Tranrs;
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}

export interface Tranrs {
  totalCount: number;
  items:      Item[];
}

export interface Item {
  itemId:            string;
  custEmail:         string;
  serviceId:         number;
  serviceName:       string;
  startDate:         string;
  endDate:           string;
  startTime:         string;
  petId:             number;
  petName:           string;
  petType:           string;
  serviceTotalPrice: string;
  remarks:           string;
}
