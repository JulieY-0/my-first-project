export interface OrderByCustomerResponse {
  MWHEADER: Mwheader;
  TRANRS:   Tranr[];
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}

export interface Tranr {
  orderId:      string;
  custEmail:    string;
  total:        number;
  orderProcess: string;
  confirmDate:  string;
}
