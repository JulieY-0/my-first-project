export interface OrderByCustomerAndIDResponse {
  MWHEADER: Mwheader;
  TRANRS:   Tranrs;
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}

export interface Tranrs {
  items: Item[];
}

export interface Item {
  orderId:      string;
  custEmail:    string;
  total:        string;
  orderProcess: string;
  confirmDate:  string;
}
