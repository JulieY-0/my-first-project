export interface OrderByCustomerAndIDRequest {
  MWHEADER: Mwheader;
  TRANRQ:   Tranrq;
}

export interface Mwheader {
  MSGID: string;
}

export interface Tranrq {
  custEmail: string;
  orderId:   string;
}
