export interface UpdateOrderDetailRequest {
  MWHEADER: Mwheader;
  TRANRQ:   Tranrq;
}

export interface Mwheader {
  MSGID: string;
}

export interface Tranrq {
  orderId:      string;
  itemId:       string;
  startDate:    string;
  endDate:      string;
  startTime:    string;
  petId:        string;
  remarks:      string;
  orderProcess: string;
}
