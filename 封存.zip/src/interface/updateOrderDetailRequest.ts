export interface UpdateOrderDetailRequest {
  MWHEADER: Mwheader;
  TRANRQ:   Tranrq;
}

export interface Mwheader {
  MSGID: string;
}

export interface Tranrq {
  orderId:      string | undefined;
  itemId:       string| undefined;
  startDate:    string| undefined;
  endDate:      string| undefined;
  startTime:    string| undefined;
  petId:        string| undefined;
  remarks:      string| undefined;
  orderProcess: string| undefined;
}
