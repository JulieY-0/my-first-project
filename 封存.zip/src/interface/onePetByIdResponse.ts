export interface OnePetByIDResponse {
  MWHEADER: Mwheader;
  TRANRS: Tranr[];
}

export interface Mwheader {
  MSGID: string;
  RETURNCODE: string;
  RETURNDESC: string;
}

export interface Tranr {
  pet_id: string | undefined;
  cust_email: string | undefined;
  name: string;
  type: string;
  sex: string;
  birth: string;
  weight: string;
  remarks: string;
}
