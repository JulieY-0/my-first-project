export interface OnePetByCustomerResponse {
  MWHEADER: Mwheader;
  TRANRS:   Tranr[];
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}

export interface Tranr {
  pet_id:     number;
  cust_email: string;
  name:       string;
  type:       string;
  sex:        string;
  birth:      Date;
  weight:     string;
  remarks:    string;
}
