export interface CartRequest {
  MWHEADER: Mwheader;
  TRANRQ:   Tranrq;
}

export interface Mwheader {
  MSGID: string;
}

export interface Tranrq {
  custEmail: string;
  isSubmit:  string;
}
