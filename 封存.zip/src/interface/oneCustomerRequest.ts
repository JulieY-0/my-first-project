export interface OneCustomerRequest {
  MWHEADER: Mwheader;
  TRANRQ:   Tranrq;
}

export interface Mwheader {
  MSGID: string;
}

export interface Tranrq {
  email:      string;
  pageNumber: number;
  pageSize:   number;
}
