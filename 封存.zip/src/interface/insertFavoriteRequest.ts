export interface InsertFavoriteRequest {
  MWHEADER: Mwheader;
  TRANRQ:   Tranrq;
}

export interface Mwheader {
  MSGID: string;
}

export interface Tranrq {
  custEmail:   string;
  serviceId:   number;
  serviceName: string;
}
