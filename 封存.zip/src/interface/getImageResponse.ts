export interface GetImageResponse {
  MWHEADER: Mwheader;
  TRANRS:   string;
}

export interface Mwheader {
  MSGID:      string;
  RETURNCODE: string;
  RETURNDESC: string;
}
