package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;
@Data
public class FAVORITEBYCUSTOMERTranrsItems {
    /** custEmail 會員信箱 */
    @NotBlank
    @Size(message = "會員名稱長度不得超過20", max = 50)
    private String custEmail;
    
    /** serviceName */
    @NotBlank
    private String ServiceName;
    
    /** serviceId */
    @NotBlank
    private String ServiceId;
}
