package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;


@Data
public class ADMINTranrsTranrs {
    
    /** email 員工信箱 */
    @NotBlank
    @Size(message = "員工信箱長度不得超過50", max = 50)
    private String email;
    
    /** name 員工名稱 */
    @NotBlank
    @Size(message = "員工名稱長度不得超過20", max = 20)
    private String name;

}
