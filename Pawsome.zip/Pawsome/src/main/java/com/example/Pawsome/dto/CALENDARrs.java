package com.example.Pawsome.dto;

import java.util.List;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CALENDARrs {

    /** MWHEADER */
    @Valid
    @JsonProperty("MWHEADER")
    private TranrsMwheader rsMwheader;

    /** TRANRS */
    @Valid
    @JsonProperty("TRANRS")
    private List<CALENDARItems> rsTranrs;
    
}
