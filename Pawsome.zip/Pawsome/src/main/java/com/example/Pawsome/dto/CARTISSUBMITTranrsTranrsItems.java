package com.example.Pawsome.dto;

import lombok.Data;

@Data
public class CARTISSUBMITTranrsTranrsItems {

    /** 購物車ID */
    private String itemId;
    
    /** 服務ID */
    private int serviceId;
    
    /** 服務名稱 */
    private String serviceName;

    /** 開始日期 */
    private String startDate;

    /** 結束日期 */
    private String endDate;

    /** 開始時間 */
    private String startTime;

}
