package com.example.Pawsome.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
@Table(name = "PS_SERVICE")
public class PsServiceEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TRIG_SERIAL_NUMBER")
    @SequenceGenerator(name = "TRIG_SERIAL_NUMBER", sequenceName = "PS_SEQUENCE_NUMBER", allocationSize = 1)
    @Column(name = "SERVICE_ID")
    private int serviceId;

    @NotBlank
    @Column(name = "TYPE")
    private String type;

    @NotBlank
    @Column(name = "NAME")
    private String name;

    @NotBlank
    @Column(name = "BRIEF")
    private String brief;

    @NotBlank
    @Column(name = "PET_TYPE")
    private String petType;

    @NotBlank
    @Column(name = "PET_SIZE_RANGE")
    private String petSizeRange;

    @NotBlank
    @Column(name = "PRICE")
    private String price;

    @Column(name = "ISAVALIABLE")
    private String isAvaliable;

}
