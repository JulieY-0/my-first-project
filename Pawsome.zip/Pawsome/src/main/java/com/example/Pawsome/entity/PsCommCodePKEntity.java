package com.example.Pawsome.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;


@Data
@Embeddable
public class PsCommCodePKEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 類別 */
    @Column(name = "TYPE")
    private String type;

    /** 代碼 */
    @Column(name = "COMMCODE")
    private String commCode;

}
