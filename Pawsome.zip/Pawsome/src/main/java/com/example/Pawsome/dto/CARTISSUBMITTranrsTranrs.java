package com.example.Pawsome.dto;

import java.util.List;

import javax.validation.Valid;

import lombok.Data;

@Data
public class CARTISSUBMITTranrsTranrs {

    /** List<CARTISSUBMITTranrsTranrsItems> */
    @Valid
    private List<CARTISSUBMITTranrsTranrsItems> items;

}
