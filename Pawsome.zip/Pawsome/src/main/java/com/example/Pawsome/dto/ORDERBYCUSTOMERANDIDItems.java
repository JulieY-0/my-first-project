package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class ORDERBYCUSTOMERANDIDItems {

    /** orderId 訂單細項編號 */
    @NotBlank
    @Size(message = "訂單編號長度不得超過20", max = 20)
    private String orderId;

    /** custEmail 會員信箱 */
    @NotBlank
    @Size(message = "會員名稱長度不得超過20", max = 50)
    private String custEmail;

    /** total 總金額 */
    @NotBlank
    private String total;

    /** orderProcess 訂單狀態 */
    @NotBlank
    private String orderProcess;

    /** confirmDate 訂單確認日期 */
    @NotBlank
    private String confirmDate;
}
