package com.example.Pawsome.controller;

import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Pawsome.dto.CALENDARrq;
import com.example.Pawsome.dto.CALENDARrs;
import com.example.Pawsome.dto.ONEORDERDETAILTranrq;
import com.example.Pawsome.dto.ONEORDERDETAILTranrs;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.ErrorInputException;
import com.example.Pawsome.service.OrderDetailSvc;

@RestController
@CrossOrigin("http://localhost:4200")
public class OrderDetailController {

    /** OrderDetailSvc */
    @Autowired
    private OrderDetailSvc orderDetailSvc;

    /** LOGIN 員工登入查詢服務 */
    private static final String ONEORDERDETAIL = "PAWSOME-ONEORDERDETAIL";

    /** 必填欄位不完整 */
    private static final String ERRORINPUT = "E001";

    /**
     * 查詢單筆訂單明細
     * @param request
     * @param errors
     * @return
     * @throws ErrorInputException
     * @throws DataNotFoundException
     * @throws IOException
     */
    @PostMapping(value = "/oneOrderDetail")
    public ONEORDERDETAILTranrs queryOneOrderDetail(@Valid
    @RequestBody
    ONEORDERDETAILTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException, IOException {
        // 檢查上行 Errors 是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append("; ");
            }
            throw new ErrorInputException(ONEORDERDETAIL + sb, ERRORINPUT);
        }
        return orderDetailSvc.queryOneOrderDetail(request);
    }

    /**
     * 查詢"已確認"訂單明細
     * @param tranrq
     * @param errs
     * @return  
     * @throws IOException
     * @throws DataNotFoundException 
     */
    @PostMapping("/calendar")
    public CALENDARrs calendar(@Valid
    @RequestBody
    CALENDARrq tranrq, Errors errs) throws IOException, DataNotFoundException {
        return orderDetailSvc.calendar(tranrq);
    }

}
