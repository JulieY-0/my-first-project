package com.example.Pawsome.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;

@Data
@Embeddable
public class PsCommCodePK implements  Serializable {

    private static final long serialVersionUID = 1L;
    
    @Column(name = "COMMCODE")
    private String commCode;
    
    @Column(name = "TYPE")
    private String type;

}
