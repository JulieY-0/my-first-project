package com.example.Pawsome.service.impl;

import java.sql.Date;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.dto.DELETEPETRq;
import com.example.Pawsome.dto.DELETEPETRs;
import com.example.Pawsome.dto.DELETEPETTranrq;
import com.example.Pawsome.dto.INSERTPETRq;
import com.example.Pawsome.dto.INSERTPETRs;
import com.example.Pawsome.dto.INSERTPETTranrq;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERRq;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERRs;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERTranrs;
import com.example.Pawsome.dto.ONEPETBYIDRq;
import com.example.Pawsome.dto.ONEPETBYIDRs;
import com.example.Pawsome.dto.ONEPETBYIDTranrs;
import com.example.Pawsome.dto.PETTranrq;
import com.example.Pawsome.dto.PETTranrs;
import com.example.Pawsome.dto.PETTranrsTranrs;
import com.example.Pawsome.dto.PETTranrsTranrsItems;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.dto.UPDATEPETRq;
import com.example.Pawsome.dto.UPDATEPETRs;
import com.example.Pawsome.dto.UPDATEPETTranrq;
import com.example.Pawsome.entity.PsPetEntity;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.repository.PsPetEntityRepository;
import com.example.Pawsome.service.PetSvc;

@Service
public class PetSvcImpl implements PetSvc {

    @Autowired
    private PsPetEntityRepository petRepo;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public INSERTPETRs insertPet(INSERTPETRq tranrq) {
        INSERTPETTranrq dataEntity = tranrq.getTranrq();
        PsPetEntity entity = new PsPetEntity();
        entity.setCustEmail(dataEntity.getCustEmail());
        entity.setName(dataEntity.getPetName());
        entity.setType(dataEntity.getPetType());
        if (StringUtils.isNotBlank(dataEntity.getSex())) {
            entity.setSex(dataEntity.getSex());
        }
        if (StringUtils.isNotBlank(dataEntity.getBirth())) {
            Instant instant = Instant.parse(dataEntity.getBirth());
            ZonedDateTime zonedDateTime = instant.atZone(java.time.ZoneOffset.of("+08:00"));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            entity.setBirth(Date.valueOf(formatter.format(zonedDateTime)));
        }
        if (StringUtils.isNotBlank(dataEntity.getWeight())) {
            entity.setWeight(dataEntity.getWeight());
        }
        if (StringUtils.isNotBlank(dataEntity.getRemarks())) {
            entity.setRemarks(dataEntity.getRemarks());
        }
        petRepo.save(entity);

        // 返回成功的回應
        TranrsMwheader mwheader = new TranrsMwheader();
        INSERTPETRs rs = new INSERTPETRs();
        mwheader.setMsgid("PAWSOME-INSERTPET");
        ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(traSuccess.getCode());
        mwheader.setReturnDesc(traSuccess.getDesc());
        rs.setMwheader(mwheader);
        return rs;
    }

    @Override
    public UPDATEPETRs updatePet(UPDATEPETRq tranrq) throws DataNotFoundException {

        UPDATEPETTranrq dataEntity = tranrq.getTranrq();
        int petId = dataEntity.getPetId();
        PsPetEntity entity = petRepo.findById(petId).get();
        if (null == entity) {
            throw new DataNotFoundException("PAWSOME-UPDATEPET", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
        }
        entity.setPetId(petId);
        entity.setCustEmail(dataEntity.getCustEmail());
        entity.setName(dataEntity.getPetName());
        entity.setType(dataEntity.getPetType());
        if (StringUtils.isNotBlank(dataEntity.getSex())) {
            entity.setSex(dataEntity.getSex());
        }
        if (StringUtils.isNotBlank(dataEntity.getBirth())) {
            Instant instant = Instant.parse(dataEntity.getBirth());
            ZonedDateTime zonedDateTime = instant.atZone(java.time.ZoneOffset.of("+08:00"));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            entity.setBirth(Date.valueOf(formatter.format(zonedDateTime)));
        }
        if (StringUtils.isNotBlank(dataEntity.getWeight())) {
            entity.setWeight(dataEntity.getWeight());
        }
        if (StringUtils.isNotBlank(dataEntity.getRemarks())) {
            entity.setRemarks(dataEntity.getRemarks());
        }
        // 更新資料
        petRepo.save(entity);

        // 返回成功的回應
        TranrsMwheader mwheader = new TranrsMwheader();
        UPDATEPETRs rs = new UPDATEPETRs();
        mwheader.setMsgid("PAWSOME-UPDATEPET");
        ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(traSuccess.getCode());
        mwheader.setReturnDesc(traSuccess.getDesc());
        rs.setMwheader(mwheader);
        return rs;
    }

    @Override
    public DELETEPETRs deletePet(DELETEPETRq tranrq) throws DataNotFoundException {
        DELETEPETTranrq dataEntity = tranrq.getTranrq();
        int petId = dataEntity.getPetId();

        // 根據 custEmail 查詢資料
        Optional<PsPetEntity> petsWithEmail = petRepo.findById(petId);
        if (!petsWithEmail.isPresent()) {
            throw new DataNotFoundException("PAWSOME-DELETEPET", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
        }
        petRepo.deleteById(petId);
        // 返回成功的回應
        TranrsMwheader mwheader = new TranrsMwheader();
        DELETEPETRs rs = new DELETEPETRs();
        mwheader.setMsgid("PAWSOME-DELETEPET");
        ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(traSuccess.getCode());
        mwheader.setReturnDesc(traSuccess.getDesc());
        rs.setMwheader(mwheader);
        return rs;
    }

    @Override
    public ONEPETBYCUSTOMERRs onePetByCustomer(ONEPETBYCUSTOMERRq tranrq) throws DataNotFoundException {
        String custEmail = tranrq.getTranrq().getCustEmail();
        // 根據 custEmail 查詢資料
        List<PsPetEntity> petsWithEmail = petRepo.findByCustEmail(custEmail);
        if (petsWithEmail.isEmpty()) {
            throw new DataNotFoundException("PAWSOME-ONEPETBYCUSTOMER", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
        }
        // 使用repository 將Table資料裡面cust_email為特定值的查詢出來為一個List
        List<ONEPETBYCUSTOMERTranrs> datas = new ArrayList<>();
        // 查出來的Data全部變成data並存進List裡
        for (PsPetEntity pet : petsWithEmail) {
            ONEPETBYCUSTOMERTranrs data = new ONEPETBYCUSTOMERTranrs();
            data.setPetId(pet.getPetId());
            data.setCustEmail(pet.getCustEmail());
            data.setName(pet.getName());
            data.setType(pet.getType());
            if (pet.getSex() != null) {
                data.setSex(pet.getSex());
            }
            if (pet.getBirth() != null) {
                data.setBirth(pet.getBirth());
            }
            if (pet.getWeight() != null) {
                data.setWeight(pet.getWeight());
            }
            if (pet.getRemarks() != null) {
                data.setRemarks(pet.getRemarks());
            }
            datas.add(data);
        }
        // 返回成功的回應
        TranrsMwheader mwheader = new TranrsMwheader();
        ONEPETBYCUSTOMERRs rs = new ONEPETBYCUSTOMERRs();
        mwheader.setMsgid("PAWSOME-ONEPETBYCUSTOMER");
        ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(traSuccess.getCode());
        mwheader.setReturnDesc(traSuccess.getDesc());
        rs.setMwheader(mwheader);
        rs.setTranrs(datas);
        return rs;
    }

    /** EMP 員工資料查詢服務 */
    private static final String PET = "PAWSOME-PET";

    /** 交易成功代碼 */
    private static final String SUCCESSCODE = ReturnCodeAndDescEnum.SUCCESS.getCode();

    /** 交易成功訊息 */
    private static final String SUCCESSDESC = ReturnCodeAndDescEnum.SUCCESS.getDesc();

    /** 查無資料 */
    private static final String DATANOTFOUND = "E702";

    @Override
    public PETTranrs pet(PETTranrq request) throws DataNotFoundException {
        List<PsPetEntity> entityOptional = petRepo.findAll();
        if (entityOptional.isEmpty()) {
            throw new DataNotFoundException(PET, DATANOTFOUND);
        }

        PETTranrsTranrs tranrsTranrs = new PETTranrsTranrs();
        List<PETTranrsTranrsItems> queryData = new ArrayList<>();
        for (PsPetEntity entityData : entityOptional) {
            PETTranrsTranrsItems items = new PETTranrsTranrsItems();
            items.setCustEmail(entityData.getCustEmail());
            items.setName(entityData.getName());
            items.setPetId(String.valueOf(entityData.getPetId()));
            items.setType(entityData.getType());

            if (entityData.getBirth() != null) {
                items.setBirth(entityData.getBirth().toString());
            }

            if (entityData.getRemarks() != null) {
                items.setRemarks(entityData.getRemarks());
            }

            if (entityData.getSex() != null) {
                items.setSex(entityData.getSex());
            }

            if (entityData.getWeight() != null) {
                items.setWeight(entityData.getWeight());
            }
            queryData.add(items);
        }
        tranrsTranrs.setPetNumber(entityOptional.size());
        tranrsTranrs.setItems(queryData);

        TranrsMwheader PETTranrsMwheader = new TranrsMwheader();
        PETTranrsMwheader.setMsgid(PET);
        PETTranrsMwheader.setReturnCode(SUCCESSCODE);
        PETTranrsMwheader.setReturnDesc(SUCCESSDESC);
        PETTranrs tranrs = new PETTranrs();
        tranrs.setTranrs(tranrsTranrs);
        tranrs.setMwheader(PETTranrsMwheader);
        return tranrs;
    }

    @Override
    public ONEPETBYIDRs onePetById(ONEPETBYIDRq tranrq) throws DataNotFoundException {
        int petId = tranrq.getTranrq().getPetId();
        // 根據 petId 查詢資料
        Optional<PsPetEntity> petsWithEmail = petRepo.findById(petId);
        if (!petsWithEmail.isPresent()) {
            throw new DataNotFoundException("PAWSOME-ONEPETBYID", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
        }
        // 使用repository 將Table資料裡面cust_email為特定值的查詢出來為一個List
        List<ONEPETBYIDTranrs> datas = new ArrayList<>();
        // 查出來的Data全部變成data並存進List裡
        PsPetEntity pet = petsWithEmail.get();
        ONEPETBYIDTranrs data = new ONEPETBYIDTranrs();
        data.setPetId(pet.getPetId());
        data.setCustEmail(pet.getCustEmail());
        data.setName(pet.getName());
        data.setType(pet.getType());
        if (pet.getSex() != null) {
            data.setSex(pet.getSex());
        }
        if (pet.getBirth() != null) {
            data.setBirth(pet.getBirth().toString());
        }
        if (pet.getWeight() != null) {
            data.setWeight(pet.getWeight());
        }
        if (pet.getRemarks() != null) {
            data.setRemarks(pet.getRemarks());
        }
        datas.add(data);
        // 返回成功的回應
        TranrsMwheader mwheader = new TranrsMwheader();
        ONEPETBYIDRs rs = new ONEPETBYIDRs();
        mwheader.setMsgid("PAWSOME-ONEPETBYID");
        ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(traSuccess.getCode());
        mwheader.setReturnDesc(traSuccess.getDesc());
        rs.setMwheader(mwheader);
        rs.setTranrs(datas);
        return rs;
    }

}
