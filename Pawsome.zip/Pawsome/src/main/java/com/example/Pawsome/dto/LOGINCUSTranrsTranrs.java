package com.example.Pawsome.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LOGINCUSTranrsTranrs {

    /** items 客戶資料*/
    @JsonProperty("items")
    private List<LOGINCUSTranrsTranrsItems> items;
}
