package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


@Data
public class TranrqMwheader {
    
    /** MSGID */
    @JsonProperty("MSGID")
    @NotBlank(message = "MSGID 不得為空")
    @Size(message = "MSGID 長度不得超過30", max = 30)
    private String msgid;

}
