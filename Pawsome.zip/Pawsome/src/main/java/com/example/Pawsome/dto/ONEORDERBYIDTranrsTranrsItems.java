package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class ONEORDERBYIDTranrsTranrsItems {

	/** orderId 訂單細項編號 */
	@NotBlank
	@Size(message = "訂單編號長度不得超過20", max = 20)
	private String orderId;
	
	/** custEmail 會員名稱 */
    @NotBlank
    @Size(message = "會員信箱長度不得超過50", max = 50)
    private String custEmail;

	/** custName 會員名稱 */
    @NotBlank
    @Size(message = "會員名稱長度不得超過20", max = 20)
    private String custName;
    
    /** custTel 會員手機 */
    @NotBlank
    @Size(message = "會員手機長度不得超過15", max = 15)
    private String custTel;
    
    /** total 總金額 */
    @NotBlank
    private String total;

    /** orderProcess 訂單狀態 */
    @NotBlank
    private String orderProcess;

    /** confirmDate 訂單確認日期 */
    @NotBlank
    private String confirmDate;

}
