package com.example.Pawsome.dto;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ONEPETBYCUSTOMERTranrs {

	@JsonProperty("pet_id")
	private int petId;

	@JsonProperty("cust_email")
	private String custEmail;

	@JsonProperty("name")
	private String name;

	@JsonProperty("type")
	private String type;

	@JsonProperty("sex")
	private String sex;

	@JsonProperty("birth")
	private Date birth;

	@JsonProperty("weight")
	private String weight;

	@JsonProperty("remarks")
	private String remarks;

}
