package com.example.Pawsome.controller;

import java.text.ParseException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Pawsome.dto.DELETEFAVORITERq;
import com.example.Pawsome.dto.DELETEFAVORITERs;
import com.example.Pawsome.dto.FAVORITEBYCUSTOMERRq;
import com.example.Pawsome.dto.FAVORITEBYCUSTOMERRs;
import com.example.Pawsome.dto.INSERTFAVORITERq;
import com.example.Pawsome.dto.INSERTFAVORITERs;
import com.example.Pawsome.dto.ORDERBYCUSTOMERRq;
import com.example.Pawsome.dto.ORDERBYCUSTOMERRs;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataDuplicateException;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.ErrorInputException;
import com.example.Pawsome.service.FavoriteSvc;

@RestController
@CrossOrigin("http://localhost:4200")
public class FavoriteController {
    @Autowired
    private FavoriteSvc favoriteSvc;

    //加入收藏
    @PostMapping(value = "/insertFavorite")
    public INSERTFAVORITERs insertFavorite(@Valid
    @RequestBody
    INSERTFAVORITERq tranrq, Errors errors) throws ErrorInputException, ParseException, DataDuplicateException {
        //檢查errors是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            ReturnCodeAndDescEnum traErrorInput = ReturnCodeAndDescEnum.ERROR_INPUT;
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append(";");
            }
            throw new ErrorInputException("PAWSOME-INSERTFAVORITE", traErrorInput.getCode());
        }
        return favoriteSvc.insertFavorite(tranrq);
    }

    //取消收藏
    @PostMapping(value = "/deleteFavorite")
    public DELETEFAVORITERs deleteFavorite(@Valid
    @RequestBody
    DELETEFAVORITERq tranrq, Errors errors) throws ErrorInputException, ParseException, DataNotFoundException {
        //檢查errors是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            ReturnCodeAndDescEnum traErrorInput = ReturnCodeAndDescEnum.ERROR_INPUT;
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append(";");
            }
            throw new ErrorInputException("PAWSOME-DELETEFAVORITE", traErrorInput.getCode());
        }
        return favoriteSvc.deleteFavorite(tranrq);
    }

    //查出卡片
    @PostMapping(value = "/favoriteByCustomer")
    public FAVORITEBYCUSTOMERRs favoriteByCustomer(@Valid
    @RequestBody
    FAVORITEBYCUSTOMERRq tranrq, Errors errors) throws DataNotFoundException, ErrorInputException {
        //檢查errors是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            ReturnCodeAndDescEnum traErrorInput = ReturnCodeAndDescEnum.ERROR_INPUT;
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append(";");
            }
            throw new ErrorInputException("PAWSOME-UPDATEPET", traErrorInput.getCode());
        }
        return favoriteSvc.favoriteByCustomer(tranrq);
    }
}
