package com.example.Pawsome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PawsomeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PawsomeApplication.class, args);
	}

}
