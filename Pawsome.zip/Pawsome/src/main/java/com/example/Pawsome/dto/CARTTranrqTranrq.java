package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class CARTTranrqTranrq {

    /** 會員信箱 */
    @NotBlank(message = "會員信箱不得為空")
    @Size(message = "會員信箱長度不得超過70", max = 70)
    private String custEmail;

    /** 送單狀態 */
    @NotBlank(message = "送單狀態不得為空")
    @Size(message = "送單狀態長度不得超過20", max = 5)
    private String isSubmit;

}
