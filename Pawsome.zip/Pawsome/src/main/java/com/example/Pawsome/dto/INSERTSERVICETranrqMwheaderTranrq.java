package com.example.Pawsome.dto;


import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class INSERTSERVICETranrqMwheaderTranrq {

    /** 服務序號*/
    @JsonProperty("serviceId")
    @Size(message = "serviceId 長度不得超過20", max = 20)
    private String serviceId;
    
    /** 服務類別*/
    @JsonProperty("type")
    @NotBlank(message = "type 不得為空")
    @Size(message = "type 長度不得超過20", max = 20)
    private String type;
    
    /** 服務名稱*/
    @JsonProperty("name")
    @NotBlank(message = "NAME 不得為空")
    @Size(message = "NAME 長度不得超過10", max = 10)
    private String name;
    
    /** 服務簡介*/
    @JsonProperty("brief")
    @NotBlank(message = "brief 不得為空")
    @Size(message = "brief 長度不得超過50", max = 50)
    private String brief;
    
    /** 寵物類型*/
    @JsonProperty("petType")
    @NotBlank(message = "petType 不得為空")
    @Size(message = "petType 長度不得超過5", max = 5)
    private String petType;
    
    /** 寵物尺寸範圍*/
    @JsonProperty("petSizeRange")
    @NotBlank(message = "petSizeRange 不得為空")
    @Size(message = "petSizeRange 長度不得超過20", max = 20)
    private String petSizeRange;
    
    /** 價錢*/
    @JsonProperty("price")
    @NotBlank(message = "price 不得為空")
    private String price;
    
    /** 是否啟用服務*/
    @JsonProperty("isavaliable")
    @Size(message = "isavaliable 長度不得超過5", max = 5)
    private String isavaliable;
    
    
    
}
