package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class ORDERBYCUSTOMERTranrq {

    @NotBlank(message = "會員信箱不可為空")
    @Size(message = "會員信箱不得超過50", max = 50)
    private String custEmail;

    /** pageNumber 目前頁碼 */
    @NotNull(message = "目前頁碼不得為空")
    private int pageNumber;

    /** pageSize 每頁筆數 */
    @NotNull(message = "每頁筆數不得為空")
    private int pageSize;
    
}
