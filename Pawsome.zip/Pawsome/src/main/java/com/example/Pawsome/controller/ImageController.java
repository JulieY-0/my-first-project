package com.example.Pawsome.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.Pawsome.dto.IMAGERs;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.service.ImageSvc;

@RestController
@CrossOrigin("http://localhost:4200")
public class ImageController {
    @Autowired
    private ImageSvc imageSvc;
    
    /**
     * 上傳圖片功能
     * @param file
     * @param imageId
     * @return
     * @throws IOException
     */
    @PostMapping(value = "/updateImage", consumes = "multipart/form-data")
    public IMAGERs uploadImage(@RequestParam("file") MultipartFile file, String imageId) throws IOException{
        return imageSvc.uploadImage(file,imageId);
    }
    /**
     * 從資料庫把圖片拿出來
     * @param imageId
     * @return
     * @throws DataNotFoundException
     */
    @GetMapping(value = "/images/{imageId}")
    public IMAGERs getImage(@PathVariable String imageId) throws DataNotFoundException{
        return imageSvc.getImage(imageId);
    }
}
