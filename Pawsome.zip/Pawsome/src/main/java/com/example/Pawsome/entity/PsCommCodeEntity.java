package com.example.Pawsome.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
@Entity
@Table(name = "PS_COMMCODE")
@IdClass(value = PsCommCodePK.class)
public class PsCommCodeEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 類別 */
    @Id
    @NotBlank
    @Column(name = "TYPE")
    private String type;

    /** 代碼 */
    @Id
    @NotBlank
    @Column(name = "COMMCODE")
    private String commCode;

    /** 描述 */
    @NotBlank
    @Column(name = "MSG")
    private String msg;

}
