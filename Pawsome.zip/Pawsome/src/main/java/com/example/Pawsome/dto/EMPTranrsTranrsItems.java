package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class EMPTranrsTranrsItems {

    /** email 員工信箱 */
    @NotBlank
    @Size(message = "員工信箱長度不得超過50", max = 50)
    private String email;

    /** password 員工密碼 */
    @NotBlank
    @Size(message = "員工密碼長度不得超過15", max = 15)
    private String password;

    /** name 員工名稱 */
    @NotBlank
    @Size(message = "員工名稱長度不得超過20", max = 20)
    private String name;

    /** tel 員工電話 */
    @NotBlank
    @Size(message = "員工電話長度不得超過15", max = 15)
    private String tel;

    /** sex 性別 */
    private String sex;

    /** birthday 生日 */
    private String birthday;

    /** permissions 權限 */
    @NotBlank
    private String permissions;

    /** isQuit 是否離職 */
    @NotBlank
    private String isQuit;

    /** updateTime 異動時間 */
    @NotBlank
    private String updateTime;

    /** hashEmail 加密信箱*/
    @Size(max = 70)
    private String hashEmail;
}
