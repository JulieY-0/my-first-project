package com.example.Pawsome.service;

import java.io.IOException;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.Pawsome.dto.IMAGERs;
import com.example.Pawsome.exception.DataNotFoundException;

public interface ImageSvc {
    IMAGERs uploadImage(@RequestParam("file")
    MultipartFile file, String imageId) throws IOException;

    IMAGERs getImage(String imageId) throws DataNotFoundException;
}
