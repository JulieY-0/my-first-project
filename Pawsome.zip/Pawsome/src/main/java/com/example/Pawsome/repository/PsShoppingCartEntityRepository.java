package com.example.Pawsome.repository;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.Pawsome.entity.PsShoppingCartEntity;

@Repository
public interface PsShoppingCartEntityRepository extends JpaRepository<PsShoppingCartEntity, String> {

    /**
     * 會員購物車查詢
     * @param CustEmail
     * @return
     */
    public List<PsShoppingCartEntity> findByCustEmail(String custEmail);

    /**
     * 當送出訂單，查找會員及itemId後將isSubmit改為y
     * @param CustEmail
     * @param itemId
     * @return
     */
    public List<PsShoppingCartEntity> findByCustEmailAndItemId(String custEmail, String itemId);

    /**
     * 會員購物車查詢，篩選isSubmit=n的商品
     * @param CustEmail
     * @param isSubmit
     * @return
     */
    public List<PsShoppingCartEntity> findByCustEmailAndIsSubmitOrderByStartDateAscStartTimeAsc(String custEmail, String isSubmit);

    /**
     * 新增購物車時，查詢會員購物車中是否已有同時間的該筆服務
     * @param custEmail
     * @param serviceId
     * @param startDate
     * @param startTime
     * @return
     */
    public Optional<PsShoppingCartEntity> findByCustEmailAndServiceIdAndStartDateAndStartTime(String custEmail, int serviceId,
            Date startDate, String startTime);

    /**
     * 查找目前最大itemId的值
     * @return
     */
    @Query(value = "SELECT COALESCE(MAX(TO_NUMBER(ITEM_ID)),0) FROM PS_SHOPPING_CART", nativeQuery = true)
    public int findMaxItemIdNumber();

    /**
     * 查找isSubmit的服務
     * @param isSubmit
     * @return
     */
    public List<PsShoppingCartEntity> findByIsSubmit(String isSubmit);

}
