package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class HASHEMPTranrqTranrq {
    /** hashEmail 會員信箱 */
    @NotBlank
    @Size(message = "長度不得超過70", max = 70)
    private String hashEmail;
}
