package com.example.Pawsome.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Pawsome.entity.PsImageEntity;

@Repository
public interface PsImageEntityRepository extends JpaRepository<PsImageEntity, String> {

}