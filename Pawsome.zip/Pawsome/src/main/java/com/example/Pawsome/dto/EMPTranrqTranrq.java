package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;


@Data
public class EMPTranrqTranrq {
    
    /** pageNumber 目前頁碼 */
    @NotNull(message = "目前頁碼不得為空")
    private int pageNumber;

    /** pageSize 每頁筆數 */
    @NotNull(message = "每頁筆數不得為空")
    private int pageSize;
    
    /** email 員工信箱 */
    @Size(message = "員工信箱長度不得超過50", max = 50)
    private String email;
    
    /** name 員工姓名 */
    @NotBlank
    private String name;
    
    /** tel 員工電話 */
    private String tel;
    
    /** isQuit 就職狀態 */
    private String isQuit;
}
