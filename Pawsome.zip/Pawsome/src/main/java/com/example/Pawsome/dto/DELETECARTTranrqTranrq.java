package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class DELETECARTTranrqTranrq {

    /** 購物車ID */
    @NotBlank(message = "購物車ID不得為空")
    @Size(message = "購物車ID長度不得超過20", max = 20)
    private String itemId;

}
