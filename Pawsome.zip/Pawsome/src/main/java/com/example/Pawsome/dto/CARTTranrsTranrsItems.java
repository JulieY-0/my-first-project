package com.example.Pawsome.dto;

import lombok.Data;

@Data
public class CARTTranrsTranrsItems {

    /** 購物車ID */
    private String itemId;
    
    /** 會員信箱 */
    private String custEmail;
    
    /** 服務ID */
    private int serviceId;

    /** 服務名稱 */
    private String serviceName;

    /** 開始日期 */
    private String startDate;

    /** 結束日期 */
    private String endDate;

    /** 開始時間 */
    private String startTime;

    /** 寵物ID */
    private int petId;

    /** 寵物名稱 */
    private String petName;

    /** 寵物種類 */
    private String petType;

    /** 服務總金額 */
    private String serviceTotalPrice;

    /** 備註 */
    private String remarks;

}
