package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class DELETEPETTranrq {

    @NotBlank(message = "寵物名稱不可為空")
    private int petId;
}
