package com.example.Pawsome.dto;

import lombok.Data;

@Data
public class INSERTORDERTranrsTranrs {

    /** 訂單編號 */
    private String orderId;

}
