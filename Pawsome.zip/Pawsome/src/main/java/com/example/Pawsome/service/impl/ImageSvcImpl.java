package com.example.Pawsome.service.impl;

import java.io.IOException;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.Pawsome.dto.IMAGERs;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.entity.PsImageEntity;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.repository.PsImageEntityRepository;
import com.example.Pawsome.service.ImageSvc;

@Service
public class ImageSvcImpl implements ImageSvc {

    @Autowired
    private PsImageEntityRepository imgRepo;

    @Override
    public IMAGERs uploadImage(MultipartFile file, String imageId) throws IOException {
        PsImageEntity imageEntity = new PsImageEntity();
        imageEntity.setImageId(imageId);
        imageEntity.setImageData(file.getBytes());
        imgRepo.save(imageEntity);

        TranrsMwheader mwheader = new TranrsMwheader();
        IMAGERs rs = new IMAGERs();
        mwheader.setMsgid("PAWSOME-UPLOADIMAGE");
        ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(traSuccess.getCode());
        mwheader.setReturnDesc(traSuccess.getDesc());
        rs.setMwheader(mwheader);
        return rs;
    }

    @Override
    public IMAGERs getImage(String imageId) throws DataNotFoundException {
        byte[] img = imgRepo.findById(imageId).get().getImageData();
        ReturnCodeAndDescEnum traDataNotFound = ReturnCodeAndDescEnum.DATA_NOT_FOUND;
        if (null == img) {
            throw new DataNotFoundException("PAWSOME-GETIMAGE", traDataNotFound.getCode());
        }
        String base64 = "data:image/jpeg;base64,"+Base64.getEncoder().encodeToString(img);
        System.out.println(base64);

        TranrsMwheader mwheader = new TranrsMwheader();
        IMAGERs rs = new IMAGERs();
        rs.setImage(base64);
        mwheader.setMsgid("PAWSOME-UPLOADIMAGE");
        ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(traSuccess.getCode());
        mwheader.setReturnDesc(traSuccess.getDesc());
        rs.setMwheader(mwheader);
        return rs;
    }

}