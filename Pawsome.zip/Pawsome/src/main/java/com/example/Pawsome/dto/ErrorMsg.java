package com.example.Pawsome.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * StoreErrorMsg
 * @author 00550283
 *
 */
@Data
public class ErrorMsg {

    /** MWHEADER */
    @JsonProperty("MWHEADER")
    private ErrorMsgMwheader mwheader;

}
