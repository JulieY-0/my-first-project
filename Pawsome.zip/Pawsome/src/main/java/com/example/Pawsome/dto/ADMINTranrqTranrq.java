package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;


@Data
public class ADMINTranrqTranrq {
    
    /** permissions 權限 */
	@NotBlank
    private String permissions;
    
}
