package com.example.Pawsome.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Pawsome.dto.DELETESERVICETranrq;
import com.example.Pawsome.dto.INSERTSERVICETranrq;
import com.example.Pawsome.dto.INSERTSERVICETranrs;
import com.example.Pawsome.dto.ONESERVICETranrq;
import com.example.Pawsome.dto.ONESERVICETranrs;
import com.example.Pawsome.dto.SERVICEALLFUZZYTranrq;
import com.example.Pawsome.dto.SERVICEALLFUZZYTranrs;
import com.example.Pawsome.dto.SERVICEALLTranrq;
import com.example.Pawsome.dto.SERVICEALLTranrs;
import com.example.Pawsome.dto.SERVICEDETAILTranrq;
import com.example.Pawsome.dto.SERVICEDETAILTranrs;
import com.example.Pawsome.dto.SERVICETranrq;
import com.example.Pawsome.dto.SERVICETranrs;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.dto.UPDATESERVICETranrq;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.ErrorInputException;
import com.example.Pawsome.service.ServiceSvc;

@RestController
@CrossOrigin("http://localhost:4200")
public class ServiceController {

    @Autowired
    private ServiceSvc serviceSvc;

    @PostMapping("/service")
    public SERVICETranrs serviceByTypeAndisAvaliable(@Valid
    @RequestBody
    SERVICETranrq request, Errors err) throws ErrorInputException, DataNotFoundException, Exception {
        if (err.hasErrors()) {
            throw new ErrorInputException("PAWSOME-SERVICE", ReturnCodeAndDescEnum.ERROR_INPUT.getCode());
        }
        return serviceSvc.serviceByTypeAndIsAvaliable(request);
    }

    @PostMapping("/serviceDetail")
    public SERVICEDETAILTranrs serviceByTypeAndisAvaliable(@Valid
    @RequestBody
    SERVICEDETAILTranrq request, Errors err) throws ErrorInputException, DataNotFoundException, Exception {
        if (err.hasErrors()) {
            throw new ErrorInputException("PAWSOME-SERVICEDETAIL", ReturnCodeAndDescEnum.ERROR_INPUT.getCode());
        }
        return serviceSvc.serviceByName(request);
    }

    @PostMapping("/oneService")
    public ONESERVICETranrs serviceByNameFuzzyAndIsAvaliableAndType(@Valid
    @RequestBody
    ONESERVICETranrq request, Errors err) throws ErrorInputException, DataNotFoundException, Exception {
        if (err.hasErrors()) {
            throw new ErrorInputException("PAWSOME-ONESERVICE", ReturnCodeAndDescEnum.ERROR_INPUT.getCode());
        }
        return serviceSvc.serviceByNameFuzzyAndIsAvaliableAndType(request);
    }

    @PostMapping("/updateService")
    public TranrsMwheader updateService(@Valid
    @RequestBody
    UPDATESERVICETranrq request, Errors err) throws ErrorInputException, DataNotFoundException, Exception {
        if (err.hasErrors()) {
            throw new ErrorInputException("PAWSOME-UPDATESERVICE", ReturnCodeAndDescEnum.ERROR_INPUT.getCode());
        }
        return serviceSvc.updateService(request);
    }

    @PostMapping("/deleteService")
    public TranrsMwheader deleteService(@Valid
    @RequestBody
    DELETESERVICETranrq request, Errors err) throws ErrorInputException, DataNotFoundException, Exception {
        if (err.hasErrors()) {
            throw new ErrorInputException("PAWSOME-DELETESERVICE", ReturnCodeAndDescEnum.ERROR_INPUT.getCode());
        }
        return serviceSvc.deleteService(request);
    }

    @PostMapping("/insertService")
    public INSERTSERVICETranrs insertService(@Valid
    @RequestBody
    INSERTSERVICETranrq request, Errors err) throws ErrorInputException, Exception {
        if (err.hasErrors()) {
            throw new ErrorInputException("PAWSOME-INSERTSERVICE", ReturnCodeAndDescEnum.ERROR_INPUT.getCode());
        }
        return serviceSvc.insertService(request);
    }

    @PostMapping("/serviceAll")
    public SERVICEALLTranrs serviceAll(@Valid
    @RequestBody
    SERVICEALLTranrq request, Errors err) throws ErrorInputException, DataNotFoundException, Exception {
        if (err.hasErrors()) {
            throw new ErrorInputException("PAWSOME-SERVICEALL", ReturnCodeAndDescEnum.ERROR_INPUT.getCode());
        }
        return serviceSvc.serviceAll(request);
    }
    
    @PostMapping("/serviceAllFuzzy")
    public SERVICEALLFUZZYTranrs serviceAllFuzzy(@Valid
    @RequestBody
    SERVICEALLFUZZYTranrq request, Errors err) throws ErrorInputException, DataNotFoundException, Exception {
        if (err.hasErrors()) {
            throw new ErrorInputException("PAWSOME-SERVICEALLFUZZY", ReturnCodeAndDescEnum.ERROR_INPUT.getCode());
        }
        return serviceSvc.serviceAllFUZZY(request);
    }
    
}
