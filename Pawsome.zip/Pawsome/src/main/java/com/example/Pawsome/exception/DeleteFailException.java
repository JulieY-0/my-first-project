package com.example.Pawsome.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * DeleteFailException
 * @author 00550283
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
public class DeleteFailException extends Exception {
    
    /** 序列化 */
    private static final long serialVersionUID = 1L;

    /** action 服務名稱 */
    private String action;    
    
    /** returnCode 處理結果代碼 */
    private String returnCode;

}
