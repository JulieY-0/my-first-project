package com.example.Pawsome.dto;

import java.util.List;

import javax.validation.Valid;

import lombok.Data;

@Data
public class CARTTranrsTranrs {

    /** 總筆數 */
    private int totalCount;

    /** List<CARTTranrsTranrsItems> */
    @Valid
    private List<CARTTranrsTranrsItems> items;

}
