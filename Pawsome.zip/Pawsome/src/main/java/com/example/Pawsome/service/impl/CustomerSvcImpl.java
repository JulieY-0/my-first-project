package com.example.Pawsome.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Date;
import java.text.ParseException;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.dto.CUSTranrq;
import com.example.Pawsome.dto.CUSTranrqTranrq;
import com.example.Pawsome.dto.CUSTranrs;
import com.example.Pawsome.dto.CUSTranrsTranrs;
import com.example.Pawsome.dto.CUSTranrsTranrsItems;
import com.example.Pawsome.dto.HASHCUSTranrq;
import com.example.Pawsome.dto.HASHCUSTranrs;
import com.example.Pawsome.dto.HASHCUSTranrsTranrs;
import com.example.Pawsome.dto.INSERTCUSTranrq;
import com.example.Pawsome.dto.INSERTCUSTranrqTranrqItems;
import com.example.Pawsome.dto.INSERTCUSTranrs;
import com.example.Pawsome.dto.LOGINCUSTranrq;
import com.example.Pawsome.dto.LOGINCUSTranrs;
import com.example.Pawsome.dto.LOGINCUSTranrsTranrs;
import com.example.Pawsome.dto.LOGINCUSTranrsTranrsItems;
import com.example.Pawsome.dto.ONECUSTranrq;
import com.example.Pawsome.dto.ONECUSTranrqTranrq;
import com.example.Pawsome.dto.ONECUSTranrs;
import com.example.Pawsome.dto.ONECUSTranrsTranrs;
import com.example.Pawsome.dto.ONECUSTranrsTranrsItem;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.dto.UPDATECUSTOMERRq;
import com.example.Pawsome.dto.UPDATECUSTOMERRs;
import com.example.Pawsome.dto.UPDATECUSTOMERTranrq;
import com.example.Pawsome.entity.PsCustomerEntity;
import com.example.Pawsome.entity.PsImageEntity;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.InsertFailException;
import com.example.Pawsome.exception.PasswordException;
import com.example.Pawsome.repository.PsCustomerRepository;
import com.example.Pawsome.repository.PsImageEntityRepository;
import com.example.Pawsome.service.CustomerSvc;
import com.example.Pawsome.service.sql.SqlAction;
import com.example.Pawsome.service.sql.SqlUtils;

@Service
public class CustomerSvcImpl implements CustomerSvc {

    /** SqlAction */
    @Autowired
    private SqlAction sqlAction;

    /** SqlUtils */
    @Autowired
    private SqlUtils sqlUtils;

    @Autowired
    private PsCustomerRepository custRepo;

    @Autowired
    private PsImageEntityRepository imgRepo;

    @Override
    public UPDATECUSTOMERRs updateCustomer(UPDATECUSTOMERRq tranrq) throws DataNotFoundException, ParseException {
        UPDATECUSTOMERTranrq dataEntity = tranrq.getTranrq();
        String custEmail = dataEntity.getCustEmail();
        // 根據 custEmail 查詢資料
        Optional<PsCustomerEntity> petsWithEmail = custRepo.findById(custEmail);
        if (!petsWithEmail.isPresent()) {
            ReturnCodeAndDescEnum traDataNotFound = ReturnCodeAndDescEnum.DATA_NOT_FOUND;
            throw new DataNotFoundException("PAWSOME-UPDATEORDER", traDataNotFound.getCode());
        }
        PsCustomerEntity entity = new PsCustomerEntity();
        entity.setEmail(custEmail);
        entity.setPassword(dataEntity.getPassword());
        entity.setName(dataEntity.getName());
        entity.setTel(dataEntity.getTel());
        if (null != dataEntity.getSex()) {
            entity.setSex(dataEntity.getSex());
        }
        if (dataEntity.getBirthday() != null) {
            Instant instant = Instant.parse(dataEntity.getBirthday());
            ZonedDateTime zoneDateTime = instant.atZone(java.time.ZoneOffset.of("+08:00"));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            entity.setBirthday(Date.valueOf(formatter.format(zoneDateTime)));
        }

        String hashEmail = custRepo.findByEmail(custEmail).get().getHashEmail();
        entity.setHashEmail(hashEmail);
        
        custRepo.save(entity);
        // 返回成功的回應
        TranrsMwheader mwheader = new TranrsMwheader();
        UPDATECUSTOMERRs rs = new UPDATECUSTOMERRs();
        mwheader.setMsgid("PAWSOME-UPDATECUSTOMER");
        ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(traSuccess.getCode());
        mwheader.setReturnDesc(traSuccess.getDesc());
        rs.setMwheader(mwheader);
        return rs;
    }

    /** LOGIN 客戶登入新增服務 */
    private static final String INSERTCUS = "PAWSOME-insertCustomer";

    /** 客戶列表查詢服務 */
    private static final String CUS = "PAWSOME-customer";

    /** LOGIN 客戶登入查詢服務 */
    private static final String LOGINCUS = "PAWSOME-loginCustomer";

    /** 客戶單筆查詢服務 */
    private static final String ONECUS = "PAWSOME-oneCustomer";

    /** 客戶單筆查詢服務 */
    private static final String HASHCUS = "PAWSOME-hashCustomer";

    /** 交易成功代碼 */
    private static final String SUCCESSCODE = ReturnCodeAndDescEnum.SUCCESS.getCode();

    /** 交易成功訊息 */
    private static final String SUCCESSDESC = ReturnCodeAndDescEnum.SUCCESS.getDesc();

    /** 查無資料 */
    private static final String DATANOTFOUND = "E702";

    /** 新增失敗 */
    private static final String INSERTFAIL = "E003";

    /** 更新失敗 */
    private static final String UPDATEFAIL = "E002";

    /** 刪除失敗 */
    private static final String DELETEFAIL = "E004";

    /** 刪除失敗 */
    private static final String PASSWORDFAIL = "E005";

    /** 必填欄位不完整 */
    private static final String ERRORINPUT = "E001";

    /** SQL_CUS */
    private static final String SQL_CUS_TOTALCOUNT = "CUS_QUERY_TOTALCOUNT.sql";

    /** SQL_CUS */
    private static final String SQL_CUS = "CUS_QUERY_001.sql";

    /** SQL_CUS */
    private static final String SQL_ONE_CUS = "ONECUSBYID_QUERY_001.sql";

    @Override
    public LOGINCUSTranrs loginCustomer(LOGINCUSTranrq request) throws DataNotFoundException, PasswordException {
        Optional<PsCustomerEntity> entityOptional = custRepo.findById(request.getTranrq().getEmail());
        // 密碼輸入不正確開寫
        if (!entityOptional.isPresent()) {
            throw new DataNotFoundException(LOGINCUS, DATANOTFOUND);
        }

        if (!entityOptional.get().getPassword().equals(request.getTranrq().getPassword())) {
            throw new PasswordException(LOGINCUS, PASSWORDFAIL);
        }

        System.out.println(entityOptional.toString());

        PsCustomerEntity entityData = entityOptional.get();
        LOGINCUSTranrsTranrsItems items = new LOGINCUSTranrsTranrsItems();
        items.setEmail(entityData.getEmail());
        items.setPassword(entityData.getPassword());
        items.setName(entityData.getName());
        items.setTel(entityData.getTel());
        items.setHashEmail(entityData.getHashEmail());

        if (entityData.getSex() != null) {
            items.setSex(entityData.getSex());
        }
        if (entityData.getBirthday() != null) {
            items.setBirthday(entityData.getBirthday().toString());
        }

        List<LOGINCUSTranrsTranrsItems> itemsList = new ArrayList<>();
        itemsList.add(items);
        LOGINCUSTranrsTranrs loginCUSTranrsTranrs = new LOGINCUSTranrsTranrs();
        loginCUSTranrsTranrs.setItems(itemsList);

        TranrsMwheader loginCUSTranrsMwheader = new TranrsMwheader();
        loginCUSTranrsMwheader.setMsgid(LOGINCUS);
        loginCUSTranrsMwheader.setReturnCode(SUCCESSCODE);
        loginCUSTranrsMwheader.setReturnDesc(SUCCESSDESC);

        LOGINCUSTranrs loginCusTranrs = new LOGINCUSTranrs();
        loginCusTranrs.setMwheader(loginCUSTranrsMwheader);
        loginCusTranrs.setTranrs(loginCUSTranrsTranrs);

        return loginCusTranrs;
    }

    @Override
    public INSERTCUSTranrs insertCustomer(INSERTCUSTranrq Tranrq) throws InsertFailException {
        Optional<PsCustomerEntity> entityOptional = custRepo.findById(Tranrq.getTranrq().getItems().get(0).getEmail());
        if (entityOptional.isPresent()) {
            throw new InsertFailException(INSERTCUS, INSERTFAIL);
        }
        INSERTCUSTranrqTranrqItems data = Tranrq.getTranrq().getItems().get(0);
        PsCustomerEntity entity = new PsCustomerEntity();
        //email轉換hashed加鹽
        String email = data.getEmail();
        byte[] salt = generateSalt();
        String hashedEmail = hashPassword(email, salt);

        //        System.out.println("加密:" + hashedEmail);
        //        System.out.println("鹽巴:" + bytesToHex(salt));
        //        if (!(data.getPassword()).equals(data.getConfirmPassword())) {
        //            throw new InsertFailException(INSERTCUS, ERRORINPUT);
        //        }
        entity.setEmail(email);
        entity.setPassword(data.getPassword());
        entity.setName(data.getName());
        entity.setTel(data.getTel());
        entity.setHashEmail(hashedEmail);
        if (!data.getSex().isEmpty()) {
            entity.setSex(data.getSex());
        }

        if (!data.getBirthday().isEmpty()) {
            Instant instant = Instant.parse(data.getBirthday());
            ZonedDateTime zoneDateTime = instant.atZone(ZoneOffset.of("+08:00"));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            entity.setBirthday(Date.valueOf(formatter.format(zoneDateTime)));
        }
        try {
            custRepo.save(entity);
        } catch (Exception e) {
        }
        //圖片預設空白頭
        PsImageEntity imgEntity = new PsImageEntity();
        imgEntity.setImageId(data.getEmail());
        byte[] img = imgRepo.findById("000").get().getImageData();
        imgEntity.setImageData(img);
        imgRepo.save(imgEntity);

        TranrsMwheader insertCUSTranrsMwheader = new TranrsMwheader();
        insertCUSTranrsMwheader.setMsgid(LOGINCUS);
        insertCUSTranrsMwheader.setReturnCode(SUCCESSCODE);
        insertCUSTranrsMwheader.setReturnDesc(SUCCESSDESC);
        INSERTCUSTranrs insertCusTranrs = new INSERTCUSTranrs();
        insertCusTranrs.setMwheader(insertCUSTranrsMwheader);
        return insertCusTranrs;

    }

    @Override
    public ONECUSTranrs oneCustomer(ONECUSTranrq tranrq) throws DataNotFoundException, IOException {
        ONECUSTranrqTranrq requestData = tranrq.getTranrq();

        String cusmail = tranrq.getTranrq().getEmail();
        // 當前頁數
        int pageNumber = requestData.getPageNumber();

        // 顯示筆數
        int pageSize = (int) requestData.getPageSize();

        // 顯示筆數的 Index
        int pageSizeIndex = pageNumber * pageSize;

        // 總筆數
        int totalCount = 1;

        // 總頁數 (無條件進位)
        int totalPage = (int) Math.ceil(totalCount / pageSize);

        Map<String, Object> mapQueryCusByID = new HashMap<>();

        mapQueryCusByID.put("cusmail", cusmail);
        mapQueryCusByID.put("pageSizeIndex", pageSizeIndex);
        mapQueryCusByID.put("pageSize", pageSize);

        String querySql = sqlUtils.getDynamicQuerySQL(SQL_ONE_CUS, mapQueryCusByID);
        List<Map<String, Object>> queryEntitys = sqlAction.queryForList(querySql, mapQueryCusByID);
        // 查詢是否有資料
        if (queryEntitys.isEmpty()) {
            throw new DataNotFoundException(ONECUS, DATANOTFOUND);
        }
        String imageId = tranrq.getTranrq().getEmail();

        Map<String, Object> queryEntity = queryEntitys.get(0);
        ONECUSTranrsTranrsItem items = new ONECUSTranrsTranrsItem();
        items.setEmail(queryEntity.get("EMAIL").toString());
        items.setName(queryEntity.get("NAME").toString());
        items.setPassword(queryEntity.get("PASSWORD").toString());
        items.setTel(queryEntity.get("TEL").toString());
        if (queryEntity.get("BIRTHDAY") != null) {
            items.setBirthday(queryEntity.get("BIRTHDAY").toString());
        }
        if (queryEntity.get("SEX") != null) {
            items.setSex(queryEntity.get("SEX").toString());
        }
        List<ONECUSTranrsTranrsItem> itemsList = new ArrayList<>();
        itemsList.add(items);

        ONECUSTranrsTranrs cusTranrsTranrs = new ONECUSTranrsTranrs();
        //圖片
        byte[] img = imgRepo.findById(imageId).get().getImageData();
        String base64 = "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(img);
        cusTranrsTranrs.setImgData(base64);
        cusTranrsTranrs.setItems(itemsList);
        cusTranrsTranrs.setCusNumber(totalCount);
        cusTranrsTranrs.setPageNumber(pageNumber);
        cusTranrsTranrs.setPageSize(pageSizeIndex);
        cusTranrsTranrs.setTotalPage(totalPage);

        TranrsMwheader oneCusTranrsMwheader = new TranrsMwheader();
        oneCusTranrsMwheader.setMsgid(ONECUS);
        oneCusTranrsMwheader.setReturnCode(SUCCESSCODE);
        oneCusTranrsMwheader.setReturnDesc(SUCCESSDESC);

        ONECUSTranrs oneCusTranrs = new ONECUSTranrs();
        oneCusTranrs.setMwheader(oneCusTranrsMwheader);
        oneCusTranrs.setTranrs(cusTranrsTranrs);
        return oneCusTranrs;
    }

    @Override
    public CUSTranrs customer(CUSTranrq Tranrq) throws DataNotFoundException, IOException {
        CUSTranrqTranrq requestData = Tranrq.getTranrq();
        Map<String, Object> mapTotalCount = new HashMap<>();
        String email = requestData.getEmail();
        mapTotalCount.put("email", email);
        String name = requestData.getName();
        mapTotalCount.put("name", name);
        String tel = requestData.getTel();
        mapTotalCount.put("tel", tel);

        String queryTotalCountSql = sqlUtils.getDynamicQuerySQL(SQL_CUS_TOTALCOUNT, mapTotalCount);
        List<Map<String, Object>> queryTotalCountEntity = sqlAction.queryForList(queryTotalCountSql, mapTotalCount);

        // 當前頁數
        int pageNumber = requestData.getPageNumber();

        // 顯示筆數
        int pageSize = (int) requestData.getPageSize();

        // 顯示筆數的 Index
        int pageSizeIndex = pageNumber * pageSize;

        // 總筆數
        double totalCount = ((BigDecimal) queryTotalCountEntity.get(0).get("TOTALCOUNT")).intValue();

        // 總頁數 (無條件進位)
        int totalPage = (int) Math.ceil(totalCount / pageSize);

        Map<String, Object> mapQueryCUS = new HashMap<>();

        mapQueryCUS.put("email", email);
        mapQueryCUS.put("name", name);
        mapQueryCUS.put("tel", tel);
        mapQueryCUS.put("pageSizeIndex", pageSizeIndex);
        mapQueryCUS.put("pageSize", pageSize);

        String querySql = sqlUtils.getDynamicQuerySQL(SQL_CUS, mapQueryCUS);
        List<Map<String, Object>> queryEntitys = sqlAction.queryForList(querySql, mapQueryCUS);

        if (queryEntitys.isEmpty()) {
            throw new DataNotFoundException(CUS, DATANOTFOUND);
        }

        List<CUSTranrsTranrsItems> itemsList = new ArrayList<>();
        for (Map<String, Object> queryEntity : queryEntitys) {
            CUSTranrsTranrsItems items = new CUSTranrsTranrsItems();
            items.setEmail(queryEntity.get("EMAIL").toString());
            items.setName(queryEntity.get("NAME").toString());
            items.setPassword(queryEntity.get("PASSWORD").toString());
            items.setTel(queryEntity.get("TEL").toString());

            if (queryEntity.get("BIRTHDAY") != null) {
                items.setBirthday(queryEntity.get("BIRTHDAY").toString());
            }
            if (queryEntity.get("SEX") != null) {
                items.setSex(queryEntity.get("SEX").toString());
            }
            itemsList.add(items);
        }

        CUSTranrsTranrs cusTranrsTranrs = new CUSTranrsTranrs();
        cusTranrsTranrs.setCusNumber(totalCount);
        cusTranrsTranrs.setPageNumber(pageNumber);
        cusTranrsTranrs.setPageSize(pageSize);
        cusTranrsTranrs.setTotalPage(totalPage);
        cusTranrsTranrs.setItems(itemsList);

        TranrsMwheader CusTranrsMwheader = new TranrsMwheader();
        CusTranrsMwheader.setMsgid(CUS);
        CusTranrsMwheader.setReturnCode(SUCCESSCODE);
        CusTranrsMwheader.setReturnDesc(SUCCESSDESC);
        CUSTranrs tranrs = new CUSTranrs();
        tranrs.setTranrs(cusTranrsTranrs);
        tranrs.setMwheader(CusTranrsMwheader);
        return tranrs;

    }

    @Override
    public HASHCUSTranrs hashCustomer(HASHCUSTranrq request) throws DataNotFoundException {
        Optional<PsCustomerEntity> entityOptional = custRepo.findByHashEmail(request.getTranrq().getHashEmail());

        if (!entityOptional.isPresent()) {
            throw new DataNotFoundException(HASHCUS, DATANOTFOUND);
        }

        PsCustomerEntity entityData = entityOptional.get();
        HASHCUSTranrsTranrs tranrsTranrs = new HASHCUSTranrsTranrs();
        tranrsTranrs.setEmail(entityData.getEmail());

        TranrsMwheader HASHCUSTranrsMwheader = new TranrsMwheader();
        HASHCUSTranrsMwheader.setMsgid(HASHCUS);
        HASHCUSTranrsMwheader.setReturnCode(SUCCESSCODE);
        HASHCUSTranrsMwheader.setReturnDesc(SUCCESSDESC);

        HASHCUSTranrs hashTranrs = new HASHCUSTranrs();
        hashTranrs.setMwheader(HASHCUSTranrsMwheader);
        hashTranrs.setTranrs(tranrsTranrs);

        return hashTranrs;
    }

    /**
     * 生成隨機鹽
     * @return
     */
    private static byte[] generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return salt;
    }

    /**
     * 生成加密email
     * @param email
     * @param salt
     * @return
     */
    private static String hashPassword(String email, byte[] salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            byte[] hashedPassword = md.digest(email.getBytes());
            return bytesToHex(hashedPassword);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }

    }

    /**
     * 將每個字節轉換成16進位
     * @param bytes
     * @return
     */
    private static String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) {
            result.append(String.format("%02X", b));
        }
        return result.toString();
    }

}
