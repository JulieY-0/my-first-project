package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class UPDATEORDERTranrq {

	@NotBlank(message = "訂單編號不可為空")
	@Size(message = "訂單編號不得超過20", max = 20)
	private String orderId;

	@NotBlank(message = "會員信箱不可為空")
	@Size(message = "會員信箱不得超過50", max = 50)
	private String custEmail;

	@NotBlank(message = "商品總額不可為空")
	private int total;

	@NotBlank(message = "訂單進度不可為空")
	@Size(message = "訂單進度不得超過5", max = 5)
	private String orderProcess;
	
	
}
