package com.example.Pawsome.controller;

import java.io.IOException;
import java.text.ParseException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Pawsome.dto.CUSTranrq;
import com.example.Pawsome.dto.CUSTranrs;
import com.example.Pawsome.dto.HASHCUSTranrq;
import com.example.Pawsome.dto.HASHCUSTranrs;
import com.example.Pawsome.dto.INSERTCUSTranrq;
import com.example.Pawsome.dto.INSERTCUSTranrs;
import com.example.Pawsome.dto.LOGINCUSTranrq;
import com.example.Pawsome.dto.LOGINCUSTranrs;
import com.example.Pawsome.dto.ONECUSTranrq;
import com.example.Pawsome.dto.ONECUSTranrs;
import com.example.Pawsome.dto.UPDATECUSTOMERRq;
import com.example.Pawsome.dto.UPDATECUSTOMERRs;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.ErrorInputException;
import com.example.Pawsome.exception.InsertFailException;
import com.example.Pawsome.exception.PasswordException;
import com.example.Pawsome.service.CustomerSvc;

@RestController
@CrossOrigin("http://localhost:4200")
public class CustomerController {

    @Autowired
    private CustomerSvc customerSvc;
    

    /** LOGIN 客戶登入查詢服務 */
    private static final String LOGINCUS = "PAWSOME-loginCustomer";

    /** LOGIN 客戶登入查詢服務 */
    private static final String INSERTCUS = "PAWSOME-insertCustomer";

    /** LOGIN 客戶登入查詢服務 */
    private static final String ONECUS = "PAWSOME-oneCustomer";
    
    /** LOGIN 客戶登入查詢服務 */
    private static final String HASHCUS = "PAWSOME-hashCustomer";

    /** customer 客戶查詢服務 */
    private static final String CUS = "PAWSOME-customer";

    /** 必填欄位不完整 */
    private static final String ERRORINPUT = "E001";

    /**
     * 更新會員
     * @param tranrq
     * @param errors
     * @return
     * @throws DataNotFoundException
     * @throws ErrorInputException
     * @throws ParseException
     */
    @PostMapping(value = "/updateCustomer")
    public UPDATECUSTOMERRs updateCustomer(@Valid
            @RequestBody
            UPDATECUSTOMERRq tranrq, Errors errors) throws DataNotFoundException, ErrorInputException, ParseException {
        //檢查errors是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            ReturnCodeAndDescEnum traErrorInput = ReturnCodeAndDescEnum.ERROR_INPUT;
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append(";");
            }
            throw new ErrorInputException("PAWSOME-UPDATECUSTOMER", traErrorInput.getCode());
        }
        return customerSvc.updateCustomer(tranrq);
    }
    
    /**
     * 會員登入
     * @param request
     * @param errors
     * @return
     * @throws ErrorInputException
     * @throws DataNotFoundException
     * @throws PasswordException 
     */
    @PostMapping(value = "/loginCustomer")
    public LOGINCUSTranrs loginCustomer(@Valid
    @RequestBody
    LOGINCUSTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException, PasswordException {
        if (errors.hasErrors()) {
            throw new ErrorInputException(LOGINCUS, ERRORINPUT);
        }
        return customerSvc.loginCustomer(request);
    }

    /**
     * 新增會員
     * @param request
     * @param errors
     * @return
     * @throws DataNotFoundException
     * @throws ErrorInputException
     * @throws InsertFailException
     */
    @PostMapping(value = "/insertCustomer")
    public INSERTCUSTranrs insertCustomer(@Valid
    @RequestBody
    INSERTCUSTranrq request, Errors errors) throws DataNotFoundException, ErrorInputException, InsertFailException {
        System.out.println(request.getTranrq().getItems());
        if (errors.hasErrors()) {
            System.out.println(request.getTranrq().getItems());
            throw new ErrorInputException(INSERTCUS, ERRORINPUT);
        }
        return customerSvc.insertCustomer(request);
    }

    /**
     * 查詢單一會員
     * @param request
     * @param errors
     * @return
     * @throws ErrorInputException
     * @throws DataNotFoundException
     * @throws IOException 
     */
    @PostMapping(value = "/oneCustomer")
    public ONECUSTranrs oneCustomer(@Valid
    @RequestBody
    ONECUSTranrq request, Errors errors) throws ErrorInputException, DataNotFoundException, IOException {
        if (errors.hasErrors()) {
            throw new ErrorInputException(ONECUS, ERRORINPUT);
        }
        return customerSvc.oneCustomer(request);
    }

    /**
     * 查詢首頁會員數量/資料
     * @param request
     * @param errors
     * @return
     * @throws DataNotFoundException
     * @throws ErrorInputException
     * @throws IOException 
     */
    @PostMapping(value = "/customer")
    public CUSTranrs customer(@Valid
    @RequestBody
    CUSTranrq request, Errors errors) throws DataNotFoundException, ErrorInputException, IOException {
        if (errors.hasErrors()) {
            throw new ErrorInputException(CUS, ERRORINPUT);
        }
        return customerSvc.customer(request);
    }
    
    /**
     * HASHEMAIL查詢EMAIL
     * @param request
     * @param errors
     * @return
     * @throws DataNotFoundException
     * @throws ErrorInputException
     */
    @PostMapping(value = "/hashCustomer")
    public HASHCUSTranrs hashcustomer(@Valid
    @RequestBody
    HASHCUSTranrq request, Errors errors) throws DataNotFoundException, ErrorInputException{
        if (errors.hasErrors()) {
            throw new ErrorInputException(HASHCUS, ERRORINPUT);
        }
        return customerSvc.hashCustomer(request);
    }
}
