package com.example.Pawsome.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Pawsome.entity.PsFavoriteEntity;

public interface PsFavorityEntityRepository extends JpaRepository<PsFavoriteEntity, String> {
    public List<PsFavoriteEntity> findByCustEmail(String custEmail);

    public Optional<PsFavoriteEntity> findByCustEmailAndServiceId(String custEmail, String serviceId);

    public Optional<PsFavoriteEntity> deleteByCustEmailAndServiceId(String custEmail, String serviceId);
}
