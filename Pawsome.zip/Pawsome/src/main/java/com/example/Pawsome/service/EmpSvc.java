package com.example.Pawsome.service;

import java.io.IOException;

import com.example.Pawsome.dto.ADMINTranrq;
import com.example.Pawsome.dto.ADMINTranrs;
import com.example.Pawsome.dto.EMPTranrq;
import com.example.Pawsome.dto.EMPTranrs;
import com.example.Pawsome.dto.HASHEMPTranrq;
import com.example.Pawsome.dto.HASHEMPTranrs;
import com.example.Pawsome.dto.INSERTEMPTranrq;
import com.example.Pawsome.dto.INSERTEMPTranrs;
import com.example.Pawsome.dto.LOGINEMPTranrq;
import com.example.Pawsome.dto.LOGINEMPTranrs;
import com.example.Pawsome.dto.ONEORDERBYIDTranrq;
import com.example.Pawsome.dto.ONEORDERBYIDTranrs;
import com.example.Pawsome.dto.ORDERDETAILTranrq;
import com.example.Pawsome.dto.ORDERDETAILTranrs;
import com.example.Pawsome.dto.UPDATEEMPTranrq;
import com.example.Pawsome.dto.UPDATEEMPTranrs;
import com.example.Pawsome.dto.UPDATEORDERDETAILTranrq;
import com.example.Pawsome.dto.UPDATEORDERDETAILTranrs;
import com.example.Pawsome.exception.DataDuplicateException;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.PasswordException;

public interface EmpSvc {

    /**
     * 員工資料查詢服務
     * @param request
     * @return
     * @throws DataNotFoundException
     * @throws IOException
     */
    EMPTranrs queryEmp(EMPTranrq request) throws DataNotFoundException, IOException;

    /**
     * 員工資料修改服務
     * @param request
     * @return
     * @throws DataNotFoundException
     */
    UPDATEEMPTranrs updateEmp(UPDATEEMPTranrq request) throws DataNotFoundException;

    /**
     * 員工資料新增服務
     * @param request
     * @return
     * @throws DataDuplicateException
     */
    INSERTEMPTranrs insertEmp(INSERTEMPTranrq request) throws DataDuplicateException;

    /**
     * 最高權限員工資料查詢服務
     * @param request
     * @return
     * @throws DataNotFoundException
     */
    ADMINTranrs queryAdmin(ADMINTranrq request) throws DataNotFoundException;

    /**
     * 單筆訂單查詢服務
     * @param request
     * @return
     * @throws DataNotFoundException
     * @throws IOException
     */
    ONEORDERBYIDTranrs queryOrderByID(ONEORDERBYIDTranrq request) throws DataNotFoundException, IOException;

    /**
     * 訂單細項資料查詢服務
     * @param request
     * @return
     * @throws DataNotFoundException
     * @throws IOException
     */
    ORDERDETAILTranrs queryOrderDetail(ORDERDETAILTranrq request) throws DataNotFoundException, IOException;

    /**
     * 訂單細項資料修改服務
     * @param request
     * @return
     * @throws DataNotFoundException
     * @throws IOException
     */
    UPDATEORDERDETAILTranrs updateOrderDetail(UPDATEORDERDETAILTranrq request) throws DataNotFoundException, IOException;

    LOGINEMPTranrs loginEmp(LOGINEMPTranrq request) throws DataNotFoundException, PasswordException;

    HASHEMPTranrs hashEmp(HASHEMPTranrq request) throws DataNotFoundException;

}
