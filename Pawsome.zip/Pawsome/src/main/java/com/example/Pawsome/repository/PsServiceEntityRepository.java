package com.example.Pawsome.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.Pawsome.entity.PsServiceEntity;

@Repository
public interface PsServiceEntityRepository extends JpaRepository<PsServiceEntity, Integer> {

    public List<PsServiceEntity> findByTypeAndIsAvaliable(String type, String isAvaliable);

    public List<PsServiceEntity> findByName(String name);

    public List<PsServiceEntity> findByNameContainingAndIsAvaliableAndType(String name, String isAvaliable, String type);

    @Query("SELECT MAX(s.serviceId) FROM PsServiceEntity s")
    public int findMaxServiceId();

    public Optional<PsServiceEntity> findByServiceId(int id);

}
