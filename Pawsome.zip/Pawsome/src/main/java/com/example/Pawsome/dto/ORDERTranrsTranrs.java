package com.example.Pawsome.dto;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ORDERTranrsTranrs {
    /** cusNumber 訂單數量 */
    private double orderNumber;

    /** totalPage 總頁數 */
    @NotNull(message = "總頁數不得為空")
    private int totalPage;

    /** pageNumber 當前頁數 */
    @NotNull(message = "當前頁數不得為空")
    private int pageNumber;

    /** pageSize 顯示筆數 */
    @NotNull(message = "顯示筆數不得為空")
    private int pageSize;

    /** items 訂單資料*/
    @JsonProperty("items")
    private List<ORDERTranrsTranrsItems> items;
}
