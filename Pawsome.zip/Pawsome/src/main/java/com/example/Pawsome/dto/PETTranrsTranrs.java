package com.example.Pawsome.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PETTranrsTranrs {
    /** petNumber 寵物數量 */
    private int petNumber;
    
    /** items 寵物資料*/
    @JsonProperty("items")
    private List<PETTranrsTranrsItems> items;
}
