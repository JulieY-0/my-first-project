package com.example.Pawsome.dto;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SERVICEALLFUZZYTranrsMwheaderTranrs {

//    /** totalPage 總頁數 */
//    @NotNull(message = "總頁數不得為空")
//    private int totalPage;
    
    /** totalCount 總筆數 */
    @NotNull(message = "總筆數不得為空")
    private int totalCount;
    
    @Valid
    @JsonProperty("datas")
    private List<SERVICEALLFUZZYTranrsMwheaderTranrsDatas> datas;
}
