package com.example.Pawsome.dto;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class ONECUSTranrsTranrs {

    /** cusNumber 客戶數量 */
    private double cusNumber;

    /** totalPage 總頁數 */
    @NotNull(message = "總頁數不得為空")
    private int totalPage;

    /** pageNumber 當前頁數 */
    @NotNull(message = "當前頁數不得為空")
    private int pageNumber;

    /** pageSize 顯示筆數 */
    @NotNull(message = "顯示筆數不得為空")
    private int pageSize;
    
    /** IMGDATA */
    private String imgData;

    /** items */
    @Valid
    private List<ONECUSTranrsTranrsItem> items;
}
