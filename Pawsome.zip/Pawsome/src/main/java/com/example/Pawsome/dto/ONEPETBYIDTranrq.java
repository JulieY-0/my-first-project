package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class ONEPETBYIDTranrq {
    @NotBlank(message = "寵物Id不可為空")
    private int petId;
}
