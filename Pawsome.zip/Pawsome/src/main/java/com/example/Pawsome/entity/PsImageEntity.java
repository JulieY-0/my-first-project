package com.example.Pawsome.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "PS_IMAGE")
public class PsImageEntity {

    @Id
    @Column(name = "IMAGEID")
    private String imageId;

    @Lob
    @Column(name = "IMAGEDATA")
    private byte[] imageData;
}
