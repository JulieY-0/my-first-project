package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;


@Data
public class UPDATEORDERDETAILTranrqTranrq {
    
    /** orderId 訂單編號 */
    @NotBlank
    @Size(message = "訂單編號長度不得超過20", max = 20)
    private String orderId;
    
    /** itemId 訂單細項編號 */
    @NotBlank
    @Size(message = "訂單細項編號長度不得超過20", max = 20)
    private String itemId;

    /** startDate 服務開始日期 */
    @NotBlank
    private String startDate;
    
    /** endDate 服務結束日期 */
    private String endDate;
    
    /** startTime 服務開始時間 */
    @NotBlank
    private String startTime;
    
    /** petId 寵物編號 */
    @NotBlank
    @Size(message = "寵物編號長度不得超過20", max = 20)
    private String petId;

    /** remarks 備註 */
    @NotBlank
    private String remarks;

    /** orderProcess 訂單細項狀態 */
    @NotBlank
    private String orderProcess;
    
    /** updateEmp 異動人員 */
    private String updateEmp;

}
