package com.example.Pawsome.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class DELETEFAVORITETranrq {
    @NotBlank(message = "顧客信箱不可為空")
    private String custEmail;
    
    @NotBlank(message = "ServiceId不可為空")
    private String serviceId;
}
