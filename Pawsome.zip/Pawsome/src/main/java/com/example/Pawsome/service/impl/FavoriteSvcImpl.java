package com.example.Pawsome.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.Pawsome.dto.DELETEFAVORITERq;
import com.example.Pawsome.dto.DELETEFAVORITERs;
import com.example.Pawsome.dto.DELETEFAVORITETranrq;
import com.example.Pawsome.dto.FAVORITEBYCUSTOMERRq;
import com.example.Pawsome.dto.FAVORITEBYCUSTOMERRs;
import com.example.Pawsome.dto.FAVORITEBYCUSTOMERTranrs;
import com.example.Pawsome.dto.FAVORITEBYCUSTOMERTranrsItems;
import com.example.Pawsome.dto.INSERTFAVORITERq;
import com.example.Pawsome.dto.INSERTFAVORITERs;
import com.example.Pawsome.dto.INSERTFAVORITETranrq;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.entity.PsFavoriteEntity;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataDuplicateException;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.repository.PsFavorityEntityRepository;
import com.example.Pawsome.service.FavoriteSvc;

@Service
public class FavoriteSvcImpl implements FavoriteSvc {
    @Autowired
    private PsFavorityEntityRepository favRepo;

    @Override
    public INSERTFAVORITERs insertFavorite(INSERTFAVORITERq tranrq) throws DataDuplicateException {
        String custEmail = tranrq.getTranrq().getCustEmail();
        String serviceId = tranrq.getTranrq().getServiceId();
        
        // 根據 custEmail跟ServiceId 查詢資料
        Optional<PsFavoriteEntity> petsWithEmail = favRepo.findByCustEmailAndServiceId(custEmail, serviceId);
        if (petsWithEmail.isPresent()) {
            throw new DataDuplicateException("PAWSOME-INSERTFAVORITE", ReturnCodeAndDescEnum.DATA_DUPLICATE.getCode());
        }
        INSERTFAVORITETranrq dataEntity = tranrq.getTranrq();
        PsFavoriteEntity entity = new PsFavoriteEntity();
        entity.setCustEmail(dataEntity.getCustEmail());
        entity.setServiceId(dataEntity.getServiceId());
        entity.setServiceName(dataEntity.getServiceName());

        favRepo.save(entity);
        // 返回成功的回應
        TranrsMwheader mwheader = new TranrsMwheader();
        INSERTFAVORITERs rs = new INSERTFAVORITERs();
        mwheader.setMsgid("PAWSOME-INSERTFAVORITE");
        ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(traSuccess.getCode());
        mwheader.setReturnDesc(traSuccess.getDesc());
        rs.setMwheader(mwheader);
        return rs;
    }

    @Override
    @Transactional
    public DELETEFAVORITERs deleteFavorite(DELETEFAVORITERq tranrq) throws DataNotFoundException {
        DELETEFAVORITETranrq dataEntity = tranrq.getTranrq();
        String serviceId = dataEntity.getServiceId();
        String custEmail = dataEntity.getCustEmail();

        // 根據 custEmail跟ServiceId 查詢資料
        Optional<PsFavoriteEntity> petsWithEmail = favRepo.findByCustEmailAndServiceId(custEmail, serviceId);
        if (!petsWithEmail.isPresent()) {
            throw new DataNotFoundException("PAWSOME-DELETEFAVORITE", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
        }
        favRepo.deleteByCustEmailAndServiceId(custEmail, serviceId);
        // 返回成功的回應
        TranrsMwheader mwheader = new TranrsMwheader();
        DELETEFAVORITERs rs = new DELETEFAVORITERs();
        mwheader.setMsgid("PAWSOME-DELETEFAVORITE");
        ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(traSuccess.getCode());
        mwheader.setReturnDesc(traSuccess.getDesc());
        rs.setMwheader(mwheader);
        return rs;
    }

    @Override
    public FAVORITEBYCUSTOMERRs favoriteByCustomer(FAVORITEBYCUSTOMERRq tranrq) throws DataNotFoundException {
        String custEmail = tranrq.getTranrq().getCustEmail();
        System.out.println(custEmail);
        // 根據 custEmail 查詢資料
        List<PsFavoriteEntity> favoriteWithEmail = favRepo.findByCustEmail(custEmail);
        if (favoriteWithEmail.isEmpty()) {
            throw new DataNotFoundException("PAWSOME-ORDERBYCUSTOMER", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
        }
        List<FAVORITEBYCUSTOMERTranrsItems> datas = new ArrayList<>();
        // 查出來的Data全部變成data並存進List裡
        for (PsFavoriteEntity favorite : favoriteWithEmail) {
            FAVORITEBYCUSTOMERTranrsItems data = new FAVORITEBYCUSTOMERTranrsItems();
            data.setCustEmail(favorite.getCustEmail());
            data.setServiceId(favorite.getServiceId());
            data.setServiceName(favorite.getServiceName());
            datas.add(data);

        }
        System.out.println(datas);
        // 返回成功的回應
        FAVORITEBYCUSTOMERTranrs tranrs = new FAVORITEBYCUSTOMERTranrs();
        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid("PAWSOME-FAVORITEBYCUSTOMER");
        ReturnCodeAndDescEnum traSuccess = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(traSuccess.getCode());
        mwheader.setReturnDesc(traSuccess.getDesc());

        FAVORITEBYCUSTOMERRs rs = new FAVORITEBYCUSTOMERRs();
        rs.setMwheader(mwheader);
        rs.setTranrs(tranrs);
        tranrs.setItems(datas);
        return rs;
    }

}
