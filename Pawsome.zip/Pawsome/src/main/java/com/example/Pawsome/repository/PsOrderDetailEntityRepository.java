package com.example.Pawsome.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Pawsome.entity.PsOrderDetailEntity;
import com.example.Pawsome.entity.PsOrderDetailPK;

@Repository
public interface PsOrderDetailEntityRepository extends JpaRepository<PsOrderDetailEntity, PsOrderDetailPK> {

    public Optional<PsOrderDetailEntity> findByOrderIdAndItemId(String orderId, String itemId);

}
