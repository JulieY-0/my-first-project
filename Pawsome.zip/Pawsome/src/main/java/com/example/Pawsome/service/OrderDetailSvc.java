package com.example.Pawsome.service;

import java.io.IOException;

import com.example.Pawsome.dto.CALENDARrq;
import com.example.Pawsome.dto.CALENDARrs;
import com.example.Pawsome.dto.ONEORDERDETAILTranrq;
import com.example.Pawsome.dto.ONEORDERDETAILTranrs;
import com.example.Pawsome.exception.DataNotFoundException;

public interface OrderDetailSvc {
    
    /** 查詢單筆訂單明細 */
    public ONEORDERDETAILTranrs queryOneOrderDetail(ONEORDERDETAILTranrq request) throws DataNotFoundException, IOException;
    
    /** 查詢所有"已確認"訂單明細 */
    public CALENDARrs calendar(CALENDARrq tranrq) throws IOException, DataNotFoundException;

}
