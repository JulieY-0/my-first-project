package com.example.Pawsome.common;

import org.springframework.stereotype.Component;

@Component
public class MsgIdObject {

    private String MsgIdObject;

    public String getMsgIdObject() {
        return MsgIdObject;
    }

    public void setMsgIdObject(String msgIdObject) {
        MsgIdObject = msgIdObject;
    }
    
    
}
