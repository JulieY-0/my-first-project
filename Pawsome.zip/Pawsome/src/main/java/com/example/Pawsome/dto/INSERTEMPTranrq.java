package com.example.Pawsome.dto;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


@Data
public class INSERTEMPTranrq {
    
    /** MWHEADER */
    @JsonProperty("MWHEADER")
    @Valid
    private TranrqMwheader mwheader;

    /** TRANRQ */
    @JsonProperty("TRANRQ")
    private INSERTEMPTranrqTranrq tranrq;
}


