package com.example.Pawsome.dto;

import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class ORDERTranrsTranrsItems {

    /** orderId 訂單編號 */
    @Size(message = "長度不得超過20", max = 20)
    private String orderId;

    /** custEmail 會員EMAIL */
    @Size(message = "長度不得超過50", max = 50)
    private String custEmail;

    /** total 訂單總金額 */
    @Size(message = "長度不得超過20", max = 20)
    private int total;

    /** orderProcess 訂單狀態 */
    @Size(message = "長度不得超過10", max = 10)
    private String orderProcess;
    
    /** name 客戶姓名 */
    @Size(message = "長度不得超過20", max = 20)
    private String custName;

    /** tel 客戶電話 */
    @Size(message = "長度不得超過15", max = 15)
    private String custTel;

    /** 訂單確認日期 */
    private String confirmDate;

}
