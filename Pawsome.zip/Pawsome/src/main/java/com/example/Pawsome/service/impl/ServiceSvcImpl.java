package com.example.Pawsome.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Pawsome.dto.DELETESERVICETranrq;
import com.example.Pawsome.dto.INSERTSERVICETranrq;
import com.example.Pawsome.dto.INSERTSERVICETranrqMwheaderTranrq;
import com.example.Pawsome.dto.INSERTSERVICETranrs;
import com.example.Pawsome.dto.INSERTSERVICETranrsMwheaderServiceId;
import com.example.Pawsome.dto.ONESERVICETranrq;
import com.example.Pawsome.dto.ONESERVICETranrs;
import com.example.Pawsome.dto.ONESERVICETranrsMwheaderTranrs;
import com.example.Pawsome.dto.ONESERVICETranrsMwheaderTranrsDatas;
import com.example.Pawsome.dto.SERVICEALLFUZZYTranrq;
import com.example.Pawsome.dto.SERVICEALLFUZZYTranrs;
import com.example.Pawsome.dto.SERVICEALLFUZZYTranrsMwheaderTranrs;
import com.example.Pawsome.dto.SERVICEALLFUZZYTranrsMwheaderTranrsDatas;
import com.example.Pawsome.dto.SERVICEALLTranrq;
import com.example.Pawsome.dto.SERVICEALLTranrs;
import com.example.Pawsome.dto.SERVICEALLTranrsMwheaderTranrs;
import com.example.Pawsome.dto.SERVICEALLTranrsMwheaderTranrsDatas;
import com.example.Pawsome.dto.SERVICEDETAILTranrq;
import com.example.Pawsome.dto.SERVICEDETAILTranrs;
import com.example.Pawsome.dto.SERVICEDETAILTranrsMwheaderTranrs;
import com.example.Pawsome.dto.SERVICEDETAILTranrsMwheaderTranrsDatas;
import com.example.Pawsome.dto.SERVICETranrq;
import com.example.Pawsome.dto.SERVICETranrs;
import com.example.Pawsome.dto.SERVICETranrsMwheaderTranrs;
import com.example.Pawsome.dto.SERVICETranrsMwheaderTranrsName;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.dto.UPDATESERVICETranrq;
import com.example.Pawsome.dto.UPDATESERVICETranrqMwheaderTranrq;
import com.example.Pawsome.entity.PsServiceEntity;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.repository.PsServiceEntityRepository;
import com.example.Pawsome.service.ServiceSvc;
import com.example.Pawsome.service.sql.SqlAction;
import com.example.Pawsome.service.sql.SqlUtils;

@Service
public class ServiceSvcImpl implements ServiceSvc {

    @Autowired
    private PsServiceEntityRepository serviceRepo;

    /** 注入sql執行檔 */
    @Autowired
    private SqlAction sqlAction;

    /** 注入sql建構語句檔 */
    @Autowired
    private SqlUtils sqlUtils;

    @Override
    public SERVICETranrs serviceByTypeAndIsAvaliable(SERVICETranrq request) throws DataNotFoundException, Exception {

        List<PsServiceEntity> serviceEntitys = serviceRepo.findByTypeAndIsAvaliable(request.getTranrq().getType(), "y");

        if (serviceEntitys.isEmpty()) {
            //            如果沒有資料
            throw new DataNotFoundException("PAWSOME-SERVICE", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
        }

        List<SERVICETranrsMwheaderTranrsName> names = new ArrayList<>();
        for (PsServiceEntity serviceEntity : serviceEntitys) {
            SERVICETranrsMwheaderTranrsName name = new SERVICETranrsMwheaderTranrsName();
            name.setName(serviceEntity.getName());
            name.setServiceId(serviceEntity.getServiceId());
            names.add(name);
        }

        SERVICETranrsMwheaderTranrs tranrs = new SERVICETranrsMwheaderTranrs();
        tranrs.setTranrs(names);

        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid("PAWSOME-SERVICE");
        ReturnCodeAndDescEnum successCode = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(successCode.getCode());
        mwheader.setReturnDesc(successCode.getDesc());

        SERVICETranrs serviceTranrs = new SERVICETranrs();
        serviceTranrs.setTranrs(tranrs);
        serviceTranrs.setMwheader(mwheader);

        return serviceTranrs;
    }

    @Override
    public SERVICEDETAILTranrs serviceByName(SERVICEDETAILTranrq request) throws DataNotFoundException, Exception {
        List<PsServiceEntity> serviceEntitys = serviceRepo.findByName(request.getTranrq().getName());

        if (serviceEntitys.isEmpty()) {
            throw new DataNotFoundException("PAWSOME-SERVICEDETAIL", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
        }

        List<SERVICEDETAILTranrsMwheaderTranrsDatas> datas = new ArrayList<>();
        for (PsServiceEntity serviceEntity : serviceEntitys) {
            SERVICEDETAILTranrsMwheaderTranrsDatas data = new SERVICEDETAILTranrsMwheaderTranrsDatas();
            data.setServiceId(serviceEntity.getServiceId());
            data.setType(serviceEntity.getType());
            data.setName(serviceEntity.getName());
            data.setBrief(serviceEntity.getBrief());
            data.setPetType(serviceEntity.getPetType());
            data.setPetSizeRange(serviceEntity.getPetSizeRange());
            data.setPrice(serviceEntity.getPrice());
            datas.add(data);
        }

        SERVICEDETAILTranrsMwheaderTranrs tranrs = new SERVICEDETAILTranrsMwheaderTranrs();
        tranrs.setDatas(datas);

        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid("PAWSOME-SERVICEDETAIL");
        ReturnCodeAndDescEnum successCode = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(successCode.getCode());
        mwheader.setReturnDesc(successCode.getDesc());

        SERVICEDETAILTranrs serviceDetailTranrs = new SERVICEDETAILTranrs();
        serviceDetailTranrs.setTranrs(tranrs);
        serviceDetailTranrs.setMwheader(mwheader);

        return serviceDetailTranrs;
    }

    @Override
    public ONESERVICETranrs serviceByNameFuzzyAndIsAvaliableAndType(ONESERVICETranrq request) throws DataNotFoundException, Exception {

        List<PsServiceEntity> serviceEntitys = serviceRepo.findByNameContainingAndIsAvaliableAndType(request.getTranrq().getName(), "y",request.getTranrq().getType());

        if (serviceEntitys.isEmpty()) {
            throw new DataNotFoundException("PAWSOME-ONESERVICE", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
        }

        List<ONESERVICETranrsMwheaderTranrsDatas> datas = new ArrayList<>();
        for (PsServiceEntity serviceEntity : serviceEntitys) {
            ONESERVICETranrsMwheaderTranrsDatas data = new ONESERVICETranrsMwheaderTranrsDatas();
            data.setServiceId(serviceEntity.getServiceId());
            data.setName(serviceEntity.getName());
            datas.add(data);
        }

        ONESERVICETranrsMwheaderTranrs tranrs = new ONESERVICETranrsMwheaderTranrs();
        tranrs.setDatas(datas);

        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid("PAWSOME-ONESERVICE");
        ReturnCodeAndDescEnum successCode = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(successCode.getCode());
        mwheader.setReturnDesc(successCode.getDesc());

        ONESERVICETranrs oneServiceTranrs = new ONESERVICETranrs();
        oneServiceTranrs.setTranrs(tranrs);
        oneServiceTranrs.setMwheader(mwheader);

        return oneServiceTranrs;
    }

    @Override
    public TranrsMwheader updateService(UPDATESERVICETranrq request) throws DataNotFoundException, Exception {

        UPDATESERVICETranrqMwheaderTranrq tranrq = request.getTranrq();
        int serviceId = tranrq.getServiceId();
        Optional<PsServiceEntity> optionalEntity = serviceRepo.findById(serviceId);

        if (!optionalEntity.isPresent()) {
            throw new DataNotFoundException("PAWSOME-UPDATESERVICE", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
        }

        PsServiceEntity entity = optionalEntity.get();
        entity.setServiceId(serviceId);
        entity.setType(tranrq.getType());
        entity.setName(tranrq.getName());
        entity.setBrief(tranrq.getBrief());
        entity.setPetType(tranrq.getPetType());
        entity.setPetSizeRange(tranrq.getPetSizeRange());
        entity.setPrice(tranrq.getPrice());
        entity.setIsAvaliable(tranrq.getIsavaliable());

        serviceRepo.save(entity);

        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid("PAWSOME-UPDATESERVICE");
        ReturnCodeAndDescEnum successCode = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(successCode.getCode());
        mwheader.setReturnDesc(successCode.getDesc());

        return mwheader;

    }

    @Override
    public TranrsMwheader deleteService(DELETESERVICETranrq request) throws DataNotFoundException, Exception {

        int serviceId = request.getTranrq().getServiceId();

        if (!serviceRepo.existsById(serviceId)) {
            throw new DataNotFoundException("PAWSOME-DELETESERVICE", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
        }

        serviceRepo.deleteById(serviceId);

        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid("PAWSOME-DELETESERVICE");
        ReturnCodeAndDescEnum successCode = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(successCode.getCode());
        mwheader.setReturnDesc(successCode.getDesc());

        return mwheader;
    }

    @Override
    public INSERTSERVICETranrs insertService(INSERTSERVICETranrq request) throws Exception {

        INSERTSERVICETranrqMwheaderTranrq tranrq = request.getTranrq();

        PsServiceEntity entity = new PsServiceEntity();
        entity.setType(tranrq.getType());
        entity.setName(tranrq.getName());
        entity.setBrief(tranrq.getBrief());
        entity.setPetType(tranrq.getPetType());
        entity.setPetSizeRange(tranrq.getPetSizeRange());
        entity.setPrice(tranrq.getPrice());
        entity.setIsAvaliable(tranrq.getIsavaliable());

        serviceRepo.save(entity);

        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid("PAWSOME-INSERTSERVICE");
        ReturnCodeAndDescEnum successCode = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(successCode.getCode());
        mwheader.setReturnDesc(successCode.getDesc());

        INSERTSERVICETranrsMwheaderServiceId tranrs = new INSERTSERVICETranrsMwheaderServiceId();

        tranrs.setServiceId(serviceRepo.findMaxServiceId());

        INSERTSERVICETranrs insertServiceTranrs = new INSERTSERVICETranrs();
        insertServiceTranrs.setMwheader(mwheader);
        insertServiceTranrs.setTranrs(tranrs);

        return insertServiceTranrs;
    }

//    未用到
    @Override
    public SERVICEALLTranrs serviceAll(SERVICEALLTranrq request) throws DataNotFoundException, Exception {

        Map<String, Object> map = new HashMap<>();
        Map<String, Object> countMap = new HashMap<>();

        String serviceName = request.getTranrq().getName();
        //名稱非空值放入map   
        if (!serviceName.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            String likeName = sb.append("%").append(serviceName).append("%").toString();
            map.put("LIKE_NAME", likeName);
            countMap.put("LIKE_NAME", likeName);
        }

        int pageSize = request.getTranrq().getPageSize();
        int pageSkipAmount = request.getTranrq().getPageNumber() * pageSize;
        //略過幾筆   
        map.put("SKIP_AMOUNT", pageSkipAmount);
        //每頁幾筆
        map.put("NEXT_AMOUNT", pageSize);

        String sqlCountQuery = sqlUtils.getDynamicQuerySQL("SERVICE_QUERY_TOTALCOUNT.sql", countMap);
        String sqlQuery = sqlUtils.getDynamicQuerySQL("SERVICE_QUERY_001.sql", map);

        List<Map<String, Object>> countResult = sqlAction.queryForList(sqlCountQuery, countMap);
        List<SERVICEALLTranrsMwheaderTranrsDatas> result = sqlAction.queryForListVO(sqlQuery, map,
            SERVICEALLTranrsMwheaderTranrsDatas.class, false);

        if (result.isEmpty()) {
            throw new DataNotFoundException("PAWSOME-SERVICEALL", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
        }

        SERVICEALLTranrsMwheaderTranrs tranrs = new SERVICEALLTranrsMwheaderTranrs();
        tranrs.setTotalCount(((BigDecimal) countResult.get(0).get("TOTALCOUNT")).intValue());
        tranrs.setDatas(result);

        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid("PAWSOME-SERVICEALL");
        ReturnCodeAndDescEnum successCode = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(successCode.getCode());
        mwheader.setReturnDesc(successCode.getDesc());

        SERVICEALLTranrs serviceAllTranrs = new SERVICEALLTranrs();
        serviceAllTranrs.setMwheader(mwheader);
        serviceAllTranrs.setTranrs(tranrs);

        return serviceAllTranrs;
    }

    @Override
    public SERVICEALLFUZZYTranrs serviceAllFUZZY(SERVICEALLFUZZYTranrq request) throws DataNotFoundException, Exception {
        Map<String, Object> map = new HashMap<>();
        Map<String, Object> countMap = new HashMap<>();

        String serviceName = request.getTranrq().getName();
        String serviceType = request.getTranrq().getType();
        String isAvaliable = request.getTranrq().getIsavaliable();

        //放入map   
        StringBuilder sb = new StringBuilder();
        String likeName = sb.append("%").append(serviceName).append("%").toString();
        map.put("LIKE_NAME", likeName);
        countMap.put("LIKE_NAME", likeName);

        if (!serviceType.isEmpty()) {
            map.put("TYPE", serviceType);
            countMap.put("TYPE", serviceType);
        }

        if (!isAvaliable.isEmpty()) {
            map.put("ISAVALIABLE", isAvaliable);
            countMap.put("ISAVALIABLE", isAvaliable);
        }

        int pageSize = request.getTranrq().getPageSize();
        int pageSkipAmount = request.getTranrq().getPageNumber() * pageSize;
        //略過幾筆   
        map.put("SKIP_AMOUNT", pageSkipAmount);
        //每頁幾筆
        map.put("NEXT_AMOUNT", pageSize);

        String sqlCountQuery = sqlUtils.getDynamicQuerySQL("SERVICE_QUERY_TOTALCOUNT_002.sql", countMap);
        String sqlQuery = sqlUtils.getDynamicQuerySQL("SERVICE_QUERY_002.sql", map);

        List<Map<String, Object>> countResult = sqlAction.queryForList(sqlCountQuery, countMap);
        List<SERVICEALLFUZZYTranrsMwheaderTranrsDatas> result = sqlAction.queryForListVO(sqlQuery, map,
            SERVICEALLFUZZYTranrsMwheaderTranrsDatas.class, false);

        if (result.isEmpty()) {
            throw new DataNotFoundException("PAWSOME-SERVICEALL", ReturnCodeAndDescEnum.DATA_NOT_FOUND.getCode());
        }

        SERVICEALLFUZZYTranrsMwheaderTranrs tranrs = new SERVICEALLFUZZYTranrsMwheaderTranrs();
        tranrs.setTotalCount(((BigDecimal) countResult.get(0).get("TOTALCOUNT")).intValue());
        tranrs.setDatas(result);

        TranrsMwheader mwheader = new TranrsMwheader();
        mwheader.setMsgid("PAWSOME-SERVICEALLFUZZY");
        ReturnCodeAndDescEnum successCode = ReturnCodeAndDescEnum.SUCCESS;
        mwheader.setReturnCode(successCode.getCode());
        mwheader.setReturnDesc(successCode.getDesc());

        SERVICEALLFUZZYTranrs serviceAllFuzzyTranrs = new SERVICEALLFUZZYTranrs();
        serviceAllFuzzyTranrs.setMwheader(mwheader);
        serviceAllFuzzyTranrs.setTranrs(tranrs);

        return serviceAllFuzzyTranrs;
    }

}
