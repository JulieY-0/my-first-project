package com.example.Pawsome.dto;

import lombok.Data;

@Data
public class INSERTFAVORITETranrq {
    private String custEmail;

    private String serviceId;

    private String serviceName;


}
