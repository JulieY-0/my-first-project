package com.example.Pawsome.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Pawsome.dto.DELETEPETRq;
import com.example.Pawsome.dto.DELETEPETRs;
import com.example.Pawsome.dto.INSERTPETRq;
import com.example.Pawsome.dto.INSERTPETRs;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERRq;
import com.example.Pawsome.dto.ONEPETBYCUSTOMERRs;
import com.example.Pawsome.dto.ONEPETBYIDRq;
import com.example.Pawsome.dto.ONEPETBYIDRs;
import com.example.Pawsome.dto.PETTranrq;
import com.example.Pawsome.dto.PETTranrs;
import com.example.Pawsome.dto.UPDATEPETRq;
import com.example.Pawsome.dto.UPDATEPETRs;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.ErrorInputException;
import com.example.Pawsome.service.PetSvc;

@RestController
@CrossOrigin("http://localhost:4200")
public class PetController {

    @Autowired
    private PetSvc petSvc;

    @PostMapping(value = "/insertPet")
    public INSERTPETRs insertPet(@Valid
    @RequestBody
    INSERTPETRq tranrq, Errors errors) throws DataNotFoundException, ErrorInputException {
        //檢查errors是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            ReturnCodeAndDescEnum traErrorInput = ReturnCodeAndDescEnum.ERROR_INPUT;
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append(";");
            }
            throw new ErrorInputException("PAWSOME-UPDATEPET", traErrorInput.getCode());
        }
        return petSvc.insertPet(tranrq);
    }

    @PostMapping(value = "/updatePet")
    public UPDATEPETRs updatePet(@Valid
    @RequestBody
    UPDATEPETRq tranrq, Errors errors) throws DataNotFoundException, ErrorInputException {
        //檢查errors是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            ReturnCodeAndDescEnum traErrorInput = ReturnCodeAndDescEnum.ERROR_INPUT;
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append(";");
            }
            throw new ErrorInputException("PAWSOME-UPDATEPET", traErrorInput.getCode());
        }
        return petSvc.updatePet(tranrq);
    }

    @PostMapping(value = "/deletePet")
    public DELETEPETRs deletePet(@Valid
    @RequestBody
    DELETEPETRq tranrq, Errors errors) throws DataNotFoundException, ErrorInputException {
        //檢查errors是否有錯
        if (errors.hasErrors()) {
            ReturnCodeAndDescEnum traErrorInput = ReturnCodeAndDescEnum.ERROR_INPUT;
            StringBuilder sb = new StringBuilder();
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append(";");
            }
            throw new ErrorInputException("PAWSOME-UPDATEPET", traErrorInput.getCode());
        }
        return petSvc.deletePet(tranrq);
    }

    @PostMapping(value = "/onePetByCustomer")
    public ONEPETBYCUSTOMERRs onePetByCustomer(@Valid
    @RequestBody
    ONEPETBYCUSTOMERRq tranrq, Errors errors) throws DataNotFoundException, ErrorInputException {
        //檢查errors是否有錯
        if (errors.hasErrors()) {
            StringBuilder sb = new StringBuilder();
            ReturnCodeAndDescEnum traErrorInput = ReturnCodeAndDescEnum.ERROR_INPUT;
            for (ObjectError error : errors.getAllErrors()) {
                sb.append(error.getDefaultMessage()).append(";");
            }
            throw new ErrorInputException("PAWSOME-UPDATEPET", traErrorInput.getCode());
        }
        return petSvc.onePetByCustomer(tranrq);
    }

    /** PET 寵物資料查詢服務 */
    private static final String PET = "PAWSOME-PET";

    /** 必填欄位不完整 */
    private static final String ERRORINPUT = "E001";

    @PostMapping(value = "/pet")
    public PETTranrs pet(@Valid
    @RequestBody
    PETTranrq request, Errors errors) throws DataNotFoundException, ErrorInputException {
        if (errors.hasErrors()) {
            throw new ErrorInputException(PET, ERRORINPUT);
        }
        return petSvc.pet(request);
    }
    
    @PostMapping(value = "/onePetById")
    public ONEPETBYIDRs onePetById(@Valid
    @RequestBody
    ONEPETBYIDRq request, Errors errors) throws DataNotFoundException, ErrorInputException {
        if (errors.hasErrors()) {
            throw new ErrorInputException(PET, ERRORINPUT);
        }
        return petSvc.onePetById(request);
    }
    
    
}
