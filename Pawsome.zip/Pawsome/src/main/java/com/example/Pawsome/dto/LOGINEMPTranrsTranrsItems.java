package com.example.Pawsome.dto;

import java.util.Date;

import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class LOGINEMPTranrsTranrsItems {
    /** email 員工信箱 */
    @Size(message = "長度不得超過50", max = 50)
    private String email;

    /** password 員工密碼 */
    @Size(message = "長度不得超過15", max = 15)
    private String password;

    /** name 員工姓名 */
    @Size(message = "長度不得超過20", max = 20)
    private String name;

    /** tel 員工電話 */
    @Size(message = "長度不得超過15", max = 15)
    private String tel;

    /** sex 員工性別 */
    @Size(message = "長度不得超過1", max = 1)
    private String sex;

    /** birthday 員工 */
    @Size(message = "長度不得超過15", max = 15)
    private String birthday;
    
    /** sex 員工權限 */
    @Size(message = "長度不得超過5", max = 5)
    private String permissions;
    
    /** sex 員工離職 */
    @Size(message = "長度不得超過1", max = 1)
    private String isQuit;
    
    /** 加密信箱 */
    @Size(message = "長度不得超過70", max = 70)
    private String hashEmail;
}
