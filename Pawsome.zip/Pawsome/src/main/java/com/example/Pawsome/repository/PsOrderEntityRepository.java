package com.example.Pawsome.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Pawsome.entity.PsOrderEntity;

@Repository
public interface PsOrderEntityRepository extends JpaRepository<PsOrderEntity, String> {
    public Page<PsOrderEntity> findByCustEmailOrderByOrderProcessAscConfirmDateDesc(String custEmail, Pageable pageable);

    public Page<PsOrderEntity> findByCustEmailAndOrderIdLikeOrderByOrderProcessAscConfirmDateDesc(String custEmail, String orderId,
            Pageable pageable);
}
