package com.example.Pawsome.service;

import com.example.Pawsome.dto.DELETEFAVORITERq;
import com.example.Pawsome.dto.DELETEFAVORITERs;
import com.example.Pawsome.dto.FAVORITEBYCUSTOMERRq;
import com.example.Pawsome.dto.FAVORITEBYCUSTOMERRs;
import com.example.Pawsome.dto.INSERTFAVORITERq;
import com.example.Pawsome.dto.INSERTFAVORITERs;
import com.example.Pawsome.exception.DataDuplicateException;
import com.example.Pawsome.exception.DataNotFoundException;

public interface FavoriteSvc {
    INSERTFAVORITERs insertFavorite(INSERTFAVORITERq request) throws DataDuplicateException;

    DELETEFAVORITERs deleteFavorite(DELETEFAVORITERq tranrq) throws DataNotFoundException;
    
    FAVORITEBYCUSTOMERRs favoriteByCustomer(FAVORITEBYCUSTOMERRq tranrq) throws DataNotFoundException;
}
