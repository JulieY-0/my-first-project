package com.example.Pawsome.dto;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CUSTranrsTranrs {

    /** cusNumber 客戶數量 */
    private double cusNumber;

    /** totalPage 總頁數 */
    @NotNull(message = "總頁數不得為空")
    private int totalPage;

    /** pageNumber 當前頁數 */
    @NotNull(message = "當前頁數不得為空")
    private int pageNumber;

    /** pageSize 顯示筆數 */
    @NotNull(message = "顯示筆數不得為空")
    private int pageSize;

    /** items 員工資料*/
    @JsonProperty("items")
    private List<CUSTranrsTranrsItems> items;
}
