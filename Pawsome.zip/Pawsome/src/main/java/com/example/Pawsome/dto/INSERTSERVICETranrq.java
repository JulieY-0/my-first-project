package com.example.Pawsome.dto;


import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class INSERTSERVICETranrq {

    /** 放API代號*/
    @Valid
    @JsonProperty("MWHEADER")
    private TranrqMwheader mwheader;
    
    /** 放服務類別*/
    @Valid
    @JsonProperty("TRANRQ")
    private INSERTSERVICETranrqMwheaderTranrq tranrq;
    
    
}
