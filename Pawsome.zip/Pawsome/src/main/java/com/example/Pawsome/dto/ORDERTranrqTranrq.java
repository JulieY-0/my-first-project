package com.example.Pawsome.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class ORDERTranrqTranrq {

    /** pageNumber 目前頁碼 */
    @NotNull(message = "目前頁碼不得為空")
    private int pageNumber;
    
    /** pageSize 每頁筆數 */
    @NotNull(message = "每頁筆數不得為空")
    private int pageSize;
    
    /** name 客戶姓名 */
    @Size(message = "長度不得超過20", max = 20)
    private String custName;

    /** tel 客戶電話 */
    @Size(message = "長度不得超過15", max = 15)
    private String custTel;
    
    /** orderId 訂單編號 */
    @Size(message = "長度不得超過20", max = 20)
    private String orderId;
    
    /** 查詢訂單確認日期(起) */
    private String qStartDate;
    
    /** 查詢訂單確認日期(訖) */
    private String qEndDate;

    /** orderProcess 訂單狀態 */
    @Size(message = "長度不得超過10", max = 10)
    private String orderProcess;
    
}
