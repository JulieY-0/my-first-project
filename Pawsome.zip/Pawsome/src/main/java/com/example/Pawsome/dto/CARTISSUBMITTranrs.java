package com.example.Pawsome.dto;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CARTISSUBMITTranrs {

    /** MWHEADER */
    @Valid
    @JsonProperty("MWHEADER")
    private TranrsMwheader rsMwheader;

    /** TRANRS */
    @Valid
    @JsonProperty("TRANRS")
    private CARTISSUBMITTranrsTranrs rsTranrs;

}
