package com.example.Pawsome.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Pawsome.entity.PsPetEntity;

@Repository
public interface PsPetEntityRepository extends JpaRepository<PsPetEntity, Integer> {

    public List<PsPetEntity> findByCustEmail(String custEmail);

    public Optional<PsPetEntity> findByPetId(int id);

}
