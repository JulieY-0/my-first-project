package com.example.Pawsome.dto;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import lombok.Data;


@Data
public class ONEORDERDETAILTranrsTranrs {
    
    /** totalPage 總頁數 */
    @NotNull(message = "總頁數不得為空")
    private int totalPage;
    
    /** totalCount 總筆數 */
    @NotNull(message = "總筆數不得為空")
    private int totalCount;
    
    /** pageNumber 當前頁數 */
    @NotNull(message = "當前頁數不得為空")
    private int pageNumber;

    /** pageSize 顯示筆數 */
    @NotNull(message = "顯示筆數不得為空")
    private int pageSize;
    
    /** items */
    @Valid
    private List<ONEORDERDETAILTranrsTranrsItems> items;

}
