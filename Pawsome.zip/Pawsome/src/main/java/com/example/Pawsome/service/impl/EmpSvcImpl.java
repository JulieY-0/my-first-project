package com.example.Pawsome.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Date;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.Pawsome.dto.ADMINTranrq;
import com.example.Pawsome.dto.ADMINTranrs;
import com.example.Pawsome.dto.ADMINTranrsTranrs;
import com.example.Pawsome.dto.EMPTranrq;
import com.example.Pawsome.dto.EMPTranrqTranrq;
import com.example.Pawsome.dto.EMPTranrs;
import com.example.Pawsome.dto.EMPTranrsTranrs;
import com.example.Pawsome.dto.EMPTranrsTranrsItems;
import com.example.Pawsome.dto.HASHEMPTranrq;
import com.example.Pawsome.dto.HASHEMPTranrs;
import com.example.Pawsome.dto.HASHEMPTranrsTranrs;
import com.example.Pawsome.dto.INSERTEMPTranrq;
import com.example.Pawsome.dto.INSERTEMPTranrqTranrq;
import com.example.Pawsome.dto.INSERTEMPTranrs;
import com.example.Pawsome.dto.LOGINEMPTranrq;
import com.example.Pawsome.dto.LOGINEMPTranrs;
import com.example.Pawsome.dto.LOGINEMPTranrsTranrs;
import com.example.Pawsome.dto.LOGINEMPTranrsTranrsItems;
import com.example.Pawsome.dto.ONEORDERBYIDTranrq;
import com.example.Pawsome.dto.ONEORDERBYIDTranrqTranrq;
import com.example.Pawsome.dto.ONEORDERBYIDTranrs;
import com.example.Pawsome.dto.ONEORDERBYIDTranrsTranrs;
import com.example.Pawsome.dto.ONEORDERBYIDTranrsTranrsItems;
import com.example.Pawsome.dto.ORDERDETAILTranrq;
import com.example.Pawsome.dto.ORDERDETAILTranrqTranrq;
import com.example.Pawsome.dto.ORDERDETAILTranrs;
import com.example.Pawsome.dto.ORDERDETAILTranrsTranrs;
import com.example.Pawsome.dto.ORDERDETAILTranrsTranrsItems;
import com.example.Pawsome.dto.TranrsMwheader;
import com.example.Pawsome.dto.UPDATEEMPTranrq;
import com.example.Pawsome.dto.UPDATEEMPTranrqTranrq;
import com.example.Pawsome.dto.UPDATEEMPTranrs;
import com.example.Pawsome.dto.UPDATEORDERDETAILTranrq;
import com.example.Pawsome.dto.UPDATEORDERDETAILTranrqTranrq;
import com.example.Pawsome.dto.UPDATEORDERDETAILTranrs;
import com.example.Pawsome.entity.PsEmpEntity;
import com.example.Pawsome.entity.PsOrderDetailEntity;
import com.example.Pawsome.entity.PsOrderEntity;
import com.example.Pawsome.entity.PsShoppingCartEntity;
import com.example.Pawsome.enums.ReturnCodeAndDescEnum;
import com.example.Pawsome.exception.DataDuplicateException;
import com.example.Pawsome.exception.DataNotFoundException;
import com.example.Pawsome.exception.PasswordException;
import com.example.Pawsome.repository.PsEmpEntityRepository;
import com.example.Pawsome.repository.PsOrderDetailEntityRepository;
import com.example.Pawsome.repository.PsOrderEntityRepository;
import com.example.Pawsome.repository.PsShoppingCartEntityRepository;
import com.example.Pawsome.service.EmpSvc;
import com.example.Pawsome.service.sql.SqlAction;
import com.example.Pawsome.service.sql.SqlUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class EmpSvcImpl implements EmpSvc {

    /** SqlAction */
    @Autowired
    private SqlAction sqlAction;

    /** SqlUtils */
    @Autowired
    private SqlUtils sqlUtils;

    @Autowired
    private PsEmpEntityRepository empRepo;

    @Autowired
    private PsOrderDetailEntityRepository orderDetailRepo;

    @Autowired
    private PsOrderEntityRepository orderRepo;

    @Autowired
    private PsShoppingCartEntityRepository cartRepo;

    /** ObjectMapper */
    @Autowired
    private ObjectMapper objectMapper;

    /** EMP 員工資料查詢服務 */
    private static final String EMP = "PAWSOME-EMP";

    /** UPDATEEMP 員工資料修改服務 */
    private static final String UPDATEEMP = "PAWSOME-UPDATEEMP";

    /** INSERTEMP 員工資料新增服務 */
    private static final String INSERTEMP = "PAWSOME-INSERTEMP";

    /** ADMIN 最高權限員工資料查詢服務 */
    private static final String ADMIN = "PAWSOME-ADMIN";

    /** ONEORDERBYID 單筆訂單查詢服務 */
    private static final String ONEORDERBYID = "PAWSOME-ONEORDERBYID";

    /** ORDERDETAIL 訂單細項資料查詢服務 */
    private static final String ORDERDETAIL = "PAWSOME-ORDERDETAIL";

    /** EMP 員工登入查詢服務 */
    private static final String LOGINEMP = "PAWSOME-loginEMP";

    /** EMP 員工加密信箱服務 */
    private static final String HASHEMP = "PAWSOME-EMP";

    /** UPDATEORDERDETAIL 訂單細項資料修改服務 */
    private static final String UPDATEORDERDETAIL = "PAWSOME-UPDATEORDERDETAIL";

    /** 交易成功代碼 */
    private static final String SUCCESSCODE = ReturnCodeAndDescEnum.SUCCESS.getCode();

    /** 交易成功訊息 */
    private static final String SUCCESSDESC = ReturnCodeAndDescEnum.SUCCESS.getDesc();

    /** 查無資料代碼 */
    private static final String DATANOTFOUND = "E702";

    /** 查無資料代碼 */
    private static final String DATADUPLICATE = "E703";

    /** 更新失敗代碼 */
    private static final String UPDATEFAIL = "E002";

    /** SQL_EMP */
    private static final String SQL_EMP_TOTALCOUNT = "EMP_QUERY_TOTALCOUNT.sql";

    /** SQL_EMP */
    private static final String SQL_EMP = "EMP_QUERY_001.sql";

    /** SQL_ONEORDERBYID */
    private static final String SQL_ONEORDERBYID = "ONEORDERBYID_QUERY_001.sql";

    /** SQL_ORDERDETAIL */
    private static final String SQL_ORDERDETAIL = "ORDERDETAIL_QUERY_001.sql";

    /** SQL_ORDERDETAIL_2 */
    private static final String SQL_ORDERDETAIL_2 = "ORDERDETAIL_QUERY_002.sql";

    /** 刪除失敗 */
    private static final String PASSWORDFAIL = "E005";

    /**
     * 判斷是否為空值
     * 
     * @param param
     * @return
     */
    private String isNull(Object param) {
        if (param != null) {
            return param.toString();
        }
        return null;
    }

    /**
     * 轉換日期格式
     * @param data
     * @return
     */
    private String dateFormatter(String data) {
        Instant instant = Instant.parse(data);
        ZonedDateTime zoneDateTime = instant.atZone(java.time.ZoneOffset.of("+08:00"));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return formatter.format(zoneDateTime);
    }

    /**
     * 將string轉為DB格式後傳入
     * @param date
     * @return
     */
    public Date formatDatetoDB(String date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate localDate = LocalDate.parse(date, formatter);
        return Date.valueOf(localDate);
    }

    /** queryEmp 員工資料查詢服務 */
    @Override
    public EMPTranrs queryEmp(EMPTranrq request) throws DataNotFoundException, IOException {
        EMPTranrqTranrq requestData = request.getTranrq();
        Map<String, Object> mapTotalCount = new HashMap<>();
        String email = requestData.getEmail();
        mapTotalCount.put("email", email);
        String name = requestData.getName();
        mapTotalCount.put("name", name);
        String tel = requestData.getTel();
        mapTotalCount.put("tel", tel);
        String isquit = requestData.getIsQuit();
        mapTotalCount.put("isquit", isquit);

        String queryTotalCountSql = sqlUtils.getDynamicQuerySQL(SQL_EMP_TOTALCOUNT, mapTotalCount);
        List<Map<String, Object>> queryTotalCountEntity = sqlAction.queryForList(queryTotalCountSql, mapTotalCount);

        // 當前頁數
        int pageNumber = requestData.getPageNumber();
        // 顯示筆數
        int pageSize = requestData.getPageSize();
        // 顯示筆數的 Index
        int pageSizeIndex = pageNumber * pageSize;
        // 總筆數
        double totalCount = ((BigDecimal) queryTotalCountEntity.get(0).get("TOTALCOUNT")).intValue();
        // 總頁數 (無條件進位)
        int totalPage = (int) Math.ceil(totalCount / pageSize);

        Map<String, Object> mapQueryEMP = new HashMap<>();
        mapQueryEMP.put("email", email);
        mapQueryEMP.put("name", name);
        mapQueryEMP.put("tel", tel);
        mapQueryEMP.put("isquit", isquit);
        mapQueryEMP.put("pageSizeIndex", pageSizeIndex);
        mapQueryEMP.put("pageSize", pageSize);
        String querySql = sqlUtils.getDynamicQuerySQL(SQL_EMP, mapQueryEMP);
        List<Map<String, Object>> queryEntitys = sqlAction.queryForList(querySql, mapQueryEMP);

        if (queryEntitys.isEmpty()) {
            throw new DataNotFoundException(EMP, DATANOTFOUND);
        }

        List<EMPTranrsTranrsItems> itemsList = new ArrayList<>();
        for (Map<String, Object> queryEntity : queryEntitys) {
            PsEmpEntity entity = objectMapper.convertValue(queryEntity, PsEmpEntity.class);
            EMPTranrsTranrsItems items = new EMPTranrsTranrsItems();
            items.setEmail(entity.getEmail());
            items.setPassword(entity.getPassword());
            items.setName(entity.getName());
            items.setTel(entity.getTel());
            items.setSex(isNull(entity.getSex()));
            items.setBirthday(isNull(entity.getBirthday()));
            items.setPermissions(entity.getPermissions());
            items.setIsQuit(entity.getIsQuit());
            items.setUpdateTime(entity.getUpdateTime().toString());
            items.setHashEmail(isNull(entity.getHashEmail()));
            itemsList.add(items);
        }

        EMPTranrsTranrs empTranrsTranrs = new EMPTranrsTranrs();
        empTranrsTranrs.setTotalPage(totalPage);
        empTranrsTranrs.setTotalCount((int) totalCount);
        empTranrsTranrs.setPageNumber(pageNumber);
        empTranrsTranrs.setPageSize(pageSize);
        empTranrsTranrs.setItems(itemsList);

        TranrsMwheader empTranrsMwheader = new TranrsMwheader();
        empTranrsMwheader.setMsgid(EMP);
        empTranrsMwheader.setReturnCode(SUCCESSCODE);
        empTranrsMwheader.setReturnDesc(SUCCESSDESC);

        EMPTranrs empTranrs = new EMPTranrs();
        empTranrs.setMwheader(empTranrsMwheader);
        empTranrs.setTranrs(empTranrsTranrs);

        return empTranrs;
    }

    /** updateEmp 員工資料修改服務 */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public UPDATEEMPTranrs updateEmp(UPDATEEMPTranrq request) throws DataNotFoundException {
        UPDATEEMPTranrqTranrq requestData = request.getTranrq();
        Optional<PsEmpEntity> entityOptional = empRepo.findById(requestData.getEmail());

        if (!entityOptional.isPresent()) {
            throw new DataNotFoundException(UPDATEEMP, DATANOTFOUND);
        }

        PsEmpEntity updateEntity = entityOptional.get();
        updateEntity.setEmail(requestData.getEmail());
        updateEntity.setPassword(requestData.getPassword());
        updateEntity.setName(requestData.getName());
        updateEntity.setTel(requestData.getTel());
        if (!requestData.getSex().isEmpty()) {
            updateEntity.setSex(requestData.getSex());
        }
        if (!requestData.getBirthday().isEmpty()) {
            Instant instant = Instant.parse(requestData.getBirthday());
            ZonedDateTime zoneDateTime = instant.atZone(java.time.ZoneOffset.of("+08:00"));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            updateEntity.setBirthday(Date.valueOf(formatter.format(zoneDateTime)));
        }
        updateEntity.setPermissions(requestData.getPermissions());
        updateEntity.setIsQuit(requestData.getIsQuit());
        updateEntity.setUpdateTime(Date.valueOf(LocalDate.now()));
        empRepo.save(updateEntity);

        TranrsMwheader updateEmpTranrsMwheader = new TranrsMwheader();
        updateEmpTranrsMwheader.setMsgid(UPDATEEMP);
        updateEmpTranrsMwheader.setReturnCode(SUCCESSCODE);
        updateEmpTranrsMwheader.setReturnDesc(SUCCESSDESC);

        UPDATEEMPTranrs updateEmpTranrs = new UPDATEEMPTranrs();
        updateEmpTranrs.setMwheader(updateEmpTranrsMwheader);

        return updateEmpTranrs;
    }

    /** insertEmp 員工資料新增服務 */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public INSERTEMPTranrs insertEmp(INSERTEMPTranrq request) throws DataDuplicateException {
        INSERTEMPTranrqTranrq requestData = request.getTranrq();
        if (empRepo.existsById(requestData.getEmail())) {
            throw new DataDuplicateException(INSERTEMP, DATADUPLICATE);
        }

        //email轉換hashed加鹽
        String email = requestData.getEmail();
        byte[] salt = generateSalt();
        String hashedEmail = hashPassword(email, salt);

        PsEmpEntity insertEntity = new PsEmpEntity();
        insertEntity.setEmail(requestData.getEmail());
        insertEntity.setHashEmail(hashedEmail);
        insertEntity.setPassword(requestData.getPassword());
        insertEntity.setName(requestData.getName());
        insertEntity.setTel(requestData.getTel());
        if (!requestData.getSex().isEmpty()) {
            insertEntity.setSex(requestData.getSex());
        }
        if (!requestData.getBirthday().isEmpty()) {
            Instant instant = Instant.parse(requestData.getBirthday());
            ZonedDateTime zoneDateTime = instant.atZone(java.time.ZoneOffset.of("+08:00"));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            insertEntity.setBirthday(Date.valueOf(formatter.format(zoneDateTime)));
        }
        insertEntity.setPermissions(requestData.getPermissions());
        insertEntity.setIsQuit(requestData.getIsQuit());
        insertEntity.setUpdateTime(Date.valueOf(LocalDate.now()));
        empRepo.save(insertEntity);

        TranrsMwheader insertEmpTranrsMwheader = new TranrsMwheader();
        insertEmpTranrsMwheader.setMsgid(INSERTEMP);
        insertEmpTranrsMwheader.setReturnCode(SUCCESSCODE);
        insertEmpTranrsMwheader.setReturnDesc(SUCCESSDESC);

        INSERTEMPTranrs insertEmpTranrs = new INSERTEMPTranrs();
        insertEmpTranrs.setMwheader(insertEmpTranrsMwheader);

        return insertEmpTranrs;
    }

    /** queryAdmin 最高權限員工資料查詢服務 */
    @Override
    public ADMINTranrs queryAdmin(ADMINTranrq request) throws DataNotFoundException {

        Optional<PsEmpEntity> optionalEntity = empRepo.findByPermissions(request.getTranrq().getPermissions());

        if (!optionalEntity.isPresent()) {
            throw new DataNotFoundException(ADMIN, DATANOTFOUND);
        }

        PsEmpEntity entity = optionalEntity.get();
        ADMINTranrsTranrs adminTranrsTranrs = new ADMINTranrsTranrs();
        adminTranrsTranrs.setEmail(entity.getEmail());
        adminTranrsTranrs.setName(entity.getName());

        TranrsMwheader adminTranrsMwheader = new TranrsMwheader();
        adminTranrsMwheader.setMsgid(ADMIN);
        adminTranrsMwheader.setReturnCode(SUCCESSCODE);
        adminTranrsMwheader.setReturnDesc(SUCCESSDESC);

        ADMINTranrs adminTranrs = new ADMINTranrs();
        adminTranrs.setMwheader(adminTranrsMwheader);
        adminTranrs.setTranrs(adminTranrsTranrs);

        return adminTranrs;
    }

    /** queryOrderByID 單筆訂單查詢服務 */
    @Override
    public ONEORDERBYIDTranrs queryOrderByID(ONEORDERBYIDTranrq request) throws DataNotFoundException, IOException {
        ONEORDERBYIDTranrqTranrq requestData = request.getTranrq();
        String rq = request.getTranrq().getOrderId();
        // 當前頁數
        int pageNumber = requestData.getPageNumber();
        // 顯示筆數
        int pageSize = requestData.getPageSize();
        // 顯示筆數的 Index
        int pageSizeIndex = pageNumber * pageSize;
        // 總筆數
        int totalCount = 1;
        int totalPage = (int) Math.ceil(totalCount / pageSize);

        Map<String, Object> mapQueryOrderByID = new HashMap<>();
        mapQueryOrderByID.put("rq", rq);
        mapQueryOrderByID.put("pageSizeIndex", pageSizeIndex);
        mapQueryOrderByID.put("pageSize", pageSize);
        String querySql = sqlUtils.getDynamicQuerySQL(SQL_ONEORDERBYID, mapQueryOrderByID);
        List<Map<String, Object>> queryEntitys = sqlAction.queryForList(querySql, mapQueryOrderByID);

        if (queryEntitys.isEmpty()) {
            throw new DataNotFoundException(ONEORDERBYID, DATANOTFOUND);
        }

        List<ONEORDERBYIDTranrsTranrsItems> itemsList = new ArrayList<>();
        for (Map<String, Object> queryEntity : queryEntitys) {
            ONEORDERBYIDTranrsTranrsItems items = new ONEORDERBYIDTranrsTranrsItems();
            items.setOrderId(queryEntity.get("ORDER_ID").toString());
            items.setCustEmail(queryEntity.get("CUST_EMAIL").toString());
            items.setCustName(queryEntity.get("NAME").toString());
            items.setCustTel(queryEntity.get("TEL").toString());
            items.setConfirmDate(queryEntity.get("CONFIRM_DATE").toString());
            items.setTotal(queryEntity.get("TOTAL").toString());
            items.setOrderProcess(queryEntity.get("MSG").toString());
            itemsList.add(items);
        }

        ONEORDERBYIDTranrsTranrs oneOrderByIdTranrsTranrs = new ONEORDERBYIDTranrsTranrs();
        oneOrderByIdTranrsTranrs.setTotalPage(totalPage);
        oneOrderByIdTranrsTranrs.setTotalCount(totalCount);
        oneOrderByIdTranrsTranrs.setPageNumber(pageNumber);
        oneOrderByIdTranrsTranrs.setPageSize(pageSize);
        oneOrderByIdTranrsTranrs.setItems(itemsList);

        TranrsMwheader oneOrderByIdTranrsMwheader = new TranrsMwheader();
        oneOrderByIdTranrsMwheader.setMsgid(ONEORDERBYID);
        oneOrderByIdTranrsMwheader.setReturnCode(SUCCESSCODE);
        oneOrderByIdTranrsMwheader.setReturnDesc(SUCCESSDESC);

        ONEORDERBYIDTranrs oneOrderByIdTranrs = new ONEORDERBYIDTranrs();
        oneOrderByIdTranrs.setMwheader(oneOrderByIdTranrsMwheader);
        oneOrderByIdTranrs.setTranrs(oneOrderByIdTranrsTranrs);

        return oneOrderByIdTranrs;
    }

    /** queryOrderDetail 訂單細項資料查詢服務 */
    @Override
    public ORDERDETAILTranrs queryOrderDetail(ORDERDETAILTranrq request) throws DataNotFoundException, IOException {
        ORDERDETAILTranrqTranrq requestData = request.getTranrq();
        String orderId = request.getTranrq().getOrderId();
        // 當前頁數
        int pageNumber = requestData.getPageNumber();
        // 顯示筆數
        int pageSize = requestData.getPageSize();
        // 顯示筆數的 Index
        int pageSizeIndex = pageNumber * pageSize;

        Map<String, Object> mapQueryOrderDetail = new HashMap<>();
        mapQueryOrderDetail.put("orderId", orderId);
        mapQueryOrderDetail.put("pageSizeIndex", pageSizeIndex);
        mapQueryOrderDetail.put("pageSize", pageSize);
        String querySql = sqlUtils.getDynamicQuerySQL(SQL_ORDERDETAIL, mapQueryOrderDetail);
        List<Map<String, Object>> queryEntitys = sqlAction.queryForList(querySql, mapQueryOrderDetail);

        // 總筆數
        int totalCount = queryEntitys.size();
        int totalPage = (int) Math.ceil(totalCount / pageSize);

        if (queryEntitys.isEmpty()) {
            throw new DataNotFoundException(ORDERDETAIL, DATANOTFOUND);
        }

        List<ORDERDETAILTranrsTranrsItems> itemsList = new ArrayList<>();
        for (Map<String, Object> queryEntity : queryEntitys) {
            ORDERDETAILTranrsTranrsItems items = new ORDERDETAILTranrsTranrsItems();
            items.setItemId(queryEntity.get("ITEM_ID").toString());
            items.setServiceName(queryEntity.get("SERVICE_NAME").toString());
            items.setStartDate(queryEntity.get("START_DATE").toString());
            items.setEndDate(isNull(queryEntity.get("END_DATE")));
            items.setStartTime(queryEntity.get("START_TIME").toString());
            items.setPetName(queryEntity.get("PET_NAME").toString());
            items.setPetType(queryEntity.get("PET_TYPE").toString());
            items.setRemarks(isNull(queryEntity.get("REMARKS")));

            TimeUnit time = TimeUnit.DAYS;
            long duration;
            if (queryEntity.get("END_DATE") == null) {
                items.setPrice(String.valueOf(queryEntity.get("PRICE")));
            } else if (queryEntity.get("END_DATE").equals(queryEntity.get("START_DATE"))) {
                duration = TimeUnit.HOURS.toMillis(24);
                items.setPrice(String
                        .valueOf(Long.parseLong(String.valueOf(queryEntity.get("PRICE"))) * time.convert(duration, TimeUnit.MILLISECONDS)));
            } else {
                duration = Date.valueOf(queryEntity.get("END_DATE").toString().split(" ")[0]).getTime()
                        - Date.valueOf(queryEntity.get("START_DATE").toString().split(" ")[0]).getTime();
                items.setPrice(String
                        .valueOf(Long.parseLong(String.valueOf(queryEntity.get("PRICE"))) * time.convert(duration, TimeUnit.MILLISECONDS)));
            }

            items.setOrderProcess(queryEntity.get("MSG").toString());
            items.setUpdateEmp(isNull(queryEntity.get("EMP_NAME")));
            items.setUpdateTime(isNull(queryEntity.get("UPDATE_TIME")));
            itemsList.add(items);
        }

        ORDERDETAILTranrsTranrs orderDetailTranrsTranrs = new ORDERDETAILTranrsTranrs();
        orderDetailTranrsTranrs.setTotalPage(totalPage);
        orderDetailTranrsTranrs.setTotalCount(totalCount);
        orderDetailTranrsTranrs.setPageNumber(pageNumber);
        orderDetailTranrsTranrs.setPageSize(pageSize);
        orderDetailTranrsTranrs.setItems(itemsList);

        TranrsMwheader orderDetailTranrsMwheader = new TranrsMwheader();
        orderDetailTranrsMwheader.setMsgid(ORDERDETAIL);
        orderDetailTranrsMwheader.setReturnCode(SUCCESSCODE);
        orderDetailTranrsMwheader.setReturnDesc(SUCCESSDESC);

        ORDERDETAILTranrs orderDetailTranrs = new ORDERDETAILTranrs();
        orderDetailTranrs.setMwheader(orderDetailTranrsMwheader);
        orderDetailTranrs.setTranrs(orderDetailTranrsTranrs);

        return orderDetailTranrs;
    }

    /** updateOrderDetail 訂單細項資料修改服務 */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public UPDATEORDERDETAILTranrs updateOrderDetail(UPDATEORDERDETAILTranrq request) throws DataNotFoundException, IOException {
        UPDATEORDERDETAILTranrqTranrq requestData = request.getTranrq();
        String orderId = requestData.getOrderId();
        String itemId = requestData.getItemId();

        // 查詢單筆訂單明細
        Optional<PsOrderDetailEntity> queryOrderDetailEntity = orderDetailRepo.findByOrderIdAndItemId(orderId, itemId);

        // 查詢是否有資料
        if (!queryOrderDetailEntity.isPresent()) {
            throw new DataNotFoundException(UPDATEORDERDETAIL, UPDATEFAIL);
        }

        // 更新特定訂單明細狀態
        PsOrderDetailEntity updateOrderDetailEntity = queryOrderDetailEntity.get();
        // 更新特定訂單明細狀態
        updateOrderDetailEntity.setOrderProcess(requestData.getOrderProcess());
        updateOrderDetailEntity.setUpdateTime(Date.valueOf(LocalDate.now()));

        // 查詢員工資料
        String empMail = requestData.getUpdateEmp();
        if (empMail != null) {
            updateOrderDetailEntity.setUpdateEmp(empMail);
        } else {
            updateOrderDetailEntity.setUpdateEmp(null);
        }
        orderDetailRepo.save(updateOrderDetailEntity);

        // 查詢購物車中特定訂單細項
        Optional<PsShoppingCartEntity> cartnEtityOptional = cartRepo.findById(itemId);

        if (!cartnEtityOptional.isPresent()) {
            throw new DataNotFoundException(UPDATEORDERDETAIL, UPDATEFAIL);
        }

        // 更新購物車中特定訂單細項
        PsShoppingCartEntity updateCartEntity = cartnEtityOptional.get();
        updateCartEntity.setStartDate(formatDatetoDB(requestData.getStartDate()));
        updateCartEntity.setEndDate(requestData.getEndDate() == "" ? null : formatDatetoDB(requestData.getEndDate()));

        updateCartEntity.setStartTime(requestData.getStartTime());
        updateCartEntity.setPetId(Integer.valueOf(requestData.getPetId()));
        updateCartEntity.setRemarks(requestData.getRemarks());
        cartRepo.save(updateCartEntity);

        // 若訂單中每筆細項都為 "已完成"，將訂單中訂單狀態改為 "已完成"
        // 若訂單中每筆細項都為 "已取消 || 未到場"，將訂單中訂單狀態改為 "已取消"
        Map<String, Object> mapQueryOrderDetail = new HashMap<>();
        mapQueryOrderDetail.put("orderId", orderId);
        String queryOrderDetailSql = sqlUtils.getDynamicQuerySQL(SQL_ORDERDETAIL_2, mapQueryOrderDetail);
        List<Map<String, Object>> queryOrderDetailEntitys = sqlAction.queryForList(queryOrderDetailSql, mapQueryOrderDetail);

        int checkDone = 0;
        int checkCancel = 0;
        int checkOther = 0;
        int totalPrice = 0;

        // 查詢購物車中特定訂單細項
        Optional<PsOrderEntity> orderEntityOptional = orderRepo.findById(orderId);
        PsOrderEntity updateOrderEntity = orderEntityOptional.get();

        if (!orderEntityOptional.isPresent()) {
            throw new DataNotFoundException(UPDATEORDERDETAIL, UPDATEFAIL);
        }

        for (Map<String, Object> queryEntity : queryOrderDetailEntitys) {
            TimeUnit time = TimeUnit.DAYS;
            long duration;
            if (queryEntity.get("MSG").equals("已完成")) {
                checkDone += 1;
            }
            if (queryEntity.get("MSG").equals("已取消") || queryEntity.get("MSG").equals("未到場")) {
                checkCancel += 1;
            }
            if (!queryEntity.get("MSG").equals("已確認")) {
                checkOther += 1;
            }
            
            // 改變訂單狀態重新計算訂單總金額;
            if (queryEntity.get("END_DATE") == null) {
                totalPrice += Long.parseLong(queryEntity.get("PRICE").toString());
            } else if (queryEntity.get("END_DATE").equals(queryEntity.get("START_DATE"))) {
                duration = TimeUnit.HOURS.toMillis(24);
                totalPrice += Long.parseLong(queryEntity.get("PRICE").toString()) * time.convert(duration, TimeUnit.MILLISECONDS);
            } else {
                duration = Date.valueOf(queryEntity.get("END_DATE").toString().split(" ")[0]).getTime()
                        - Date.valueOf(queryEntity.get("START_DATE").toString().split(" ")[0]).getTime();
                totalPrice += Long.parseLong(String.valueOf(queryEntity.get("PRICE"))) * time.convert(duration, TimeUnit.MILLISECONDS);
            }
            updateOrderEntity.setTotal(totalPrice);
        }

        int updateOrderDetailNUM = queryOrderDetailEntitys.size();
        if (checkDone == updateOrderDetailNUM || checkOther == updateOrderDetailNUM) {
            updateOrderEntity.setOrderProcess("2");
        }
        if (checkCancel == updateOrderDetailNUM) {
            updateOrderEntity.setOrderProcess("3");
        }
        orderRepo.save(updateOrderEntity);

        TranrsMwheader upateOrderDetailTranrsMwheader = new TranrsMwheader();
        upateOrderDetailTranrsMwheader.setMsgid(UPDATEEMP);
        upateOrderDetailTranrsMwheader.setReturnCode(SUCCESSCODE);
        upateOrderDetailTranrsMwheader.setReturnDesc(SUCCESSDESC);

        UPDATEORDERDETAILTranrs upateOrderDetailTranrs = new UPDATEORDERDETAILTranrs();
        upateOrderDetailTranrs.setMwheader(upateOrderDetailTranrsMwheader);

        return upateOrderDetailTranrs;
    }

    @Override
    public LOGINEMPTranrs loginEmp(LOGINEMPTranrq request) throws DataNotFoundException, PasswordException {
        Optional<PsEmpEntity> entityOptional = empRepo.findById(request.getTranrq().getEmail());
        if (!entityOptional.isPresent()) {
            throw new DataNotFoundException(LOGINEMP, DATANOTFOUND);
        }

        if (!entityOptional.get().getPassword().equals(request.getTranrq().getPassword())) {
            throw new PasswordException(LOGINEMP, PASSWORDFAIL);
        }

        PsEmpEntity entityData = entityOptional.get();
        LOGINEMPTranrsTranrsItems items = new LOGINEMPTranrsTranrsItems();
        items.setEmail(entityData.getEmail());
        items.setPassword(entityData.getPassword());
        items.setName(entityData.getName());
        items.setSex(isNull(entityData.getSex()));
        items.setTel(entityData.getTel());
        items.setBirthday(isNull(entityData.getBirthday()));
        items.setIsQuit(entityData.getIsQuit());
        items.setPermissions(entityData.getPermissions());
        items.setHashEmail(entityData.getHashEmail());

        List<LOGINEMPTranrsTranrsItems> itemsList = new ArrayList<>();
        itemsList.add(items);
        LOGINEMPTranrsTranrs loginEmpTranrsTranrs = new LOGINEMPTranrsTranrs();
        loginEmpTranrsTranrs.setItems(itemsList);

        TranrsMwheader loginEmpTranrsMwheader = new TranrsMwheader();
        loginEmpTranrsMwheader.setMsgid(LOGINEMP);
        loginEmpTranrsMwheader.setReturnCode(SUCCESSCODE);
        loginEmpTranrsMwheader.setReturnDesc(SUCCESSDESC);

        LOGINEMPTranrs loginEmpTranrs = new LOGINEMPTranrs();
        loginEmpTranrs.setMwheader(loginEmpTranrsMwheader);
        loginEmpTranrs.setTranrs(loginEmpTranrsTranrs);

        return loginEmpTranrs;
    }

    @Override
    public HASHEMPTranrs hashEmp(HASHEMPTranrq request) throws DataNotFoundException {
        Optional<PsEmpEntity> entityOptional = empRepo.findByHashEmail(request.getTranrq().getHashEmail());

        if (!entityOptional.isPresent()) {
            throw new DataNotFoundException(HASHEMP, DATANOTFOUND);
        }

        PsEmpEntity entityData = entityOptional.get();
        HASHEMPTranrsTranrs tranrsTranrs = new HASHEMPTranrsTranrs();
        tranrsTranrs.setEmail(entityData.getEmail());

        TranrsMwheader HASHEMPTranrsMwheader = new TranrsMwheader();
        HASHEMPTranrsMwheader.setMsgid(HASHEMP);
        HASHEMPTranrsMwheader.setReturnCode(SUCCESSCODE);
        HASHEMPTranrsMwheader.setReturnDesc(SUCCESSDESC);

        HASHEMPTranrs hashTranrs = new HASHEMPTranrs();
        hashTranrs.setMwheader(HASHEMPTranrsMwheader);
        hashTranrs.setTranrs(tranrsTranrs);

        return hashTranrs;
    }

    //生成隨機鹽
    private static byte[] generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return salt;
    }

    //生成加密email資料
    private static String hashPassword(String email, byte[] salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            byte[] hashedPassword = md.digest(email.getBytes());
            return bytesToHex(hashedPassword);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }

    }

    //將每個字節轉換成16進位
    private static String bytesToHex(byte[] bytes) {
        StringBuilder result = new StringBuilder();
        for (byte b : bytes) {
            result.append(String.format("%02X", b));
        }
        return result.toString();
    }

}
