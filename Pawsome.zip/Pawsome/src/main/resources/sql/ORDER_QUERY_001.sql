select *
 from STUDENT2.PS_ORDER ORD
 left join STUDENT2.PS_COMMCODE CODE 
  on ORD.ORDER_PROCESS = CODE.COMMCODE
 left join STUDENT2.PS_CUSTOMER CUS
  on ORD.CUST_EMAIL = CUS.EMAIL
  where CODE.TYPE = 'ORDERPROCESS' 
  and CUS.NAME like '%' || :name || '%'
  and CUS.Tel like '%' || :tel || '%'
  and ORD.ORDER_ID like '%' || :orderId || '%'
  and ORD.ORDER_PROCESS like '%' || :orderProcess || '%'
  [and (ORD.CONFIRM_DATE >= to_date(:qStartDate ,'YYYY-MM-DD'))]
  [and (ORD.CONFIRM_DATE <= to_date(:qEndDate , 'YYYY-MM-DD'))]
 order by CODE.COMMCODE, ORD.CONFIRM_DATE desc
 offset :pageSizeIndex row
 fetch next :pageSize rows only