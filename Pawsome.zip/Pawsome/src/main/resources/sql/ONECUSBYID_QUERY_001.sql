 select *
 from STUDENT2.PS_CUSTOMER CUS 
 left join STUDENT2.PS_IMAGE IMG 
  on CUS.EMAIL = IMG.IMAGEID 
 where CUS.EMAIL = :cusmail or CUS.NAME = :cusmail or CUS.TEL = :cusmail
 offset :pageSizeIndex row
 fetch next :pageSize rows only