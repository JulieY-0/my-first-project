select count(svc.SERVICE_ID) as TOTALCOUNT
 from STUDENT2.PS_SERVICE svc
 where svc.NAME like :LIKE_NAME
 [and svc.TYPE = :TYPE]
 [and svc.ISAVALIABLE = :ISAVALIABLE]