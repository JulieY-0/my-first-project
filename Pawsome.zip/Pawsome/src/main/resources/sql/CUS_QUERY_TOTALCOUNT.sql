select count(CUS.EMAIL) as TOTALCOUNT
 from STUDENT2.PS_CUSTOMER CUS
 where CUS.EMAIL like '%' || :email || '%'
  and CUS.NAME like '%' || :name || '%'
  and CUS.Tel like '%' || :tel || '%'
