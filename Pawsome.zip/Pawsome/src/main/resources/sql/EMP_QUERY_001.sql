select *
 from STUDENT2.PS_EMP EMP
 left join STUDENT2.PS_COMMCODE CODE 
  on EMP.PERMISSIONS = CODE.COMMCODE
  and CODE.TYPE = 'PERMISSIONS' 
 where EMP.EMAIL like '%' || :email || '%'
  and EMP.NAME like '%' || :name || '%'
  and EMP.Tel like '%' || :tel || '%'
  and EMP.ISQUIT like '%' || :isquit || '%'
 order by EMP.PERMISSIONS, EMP.ISQUIT, EMP.UPDATE_TIME desc
 offset :pageSizeIndex row
 fetch next :pageSize rows only