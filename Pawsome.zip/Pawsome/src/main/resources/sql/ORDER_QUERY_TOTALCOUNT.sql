select count(ORD.ORDER_ID) as TOTALCOUNT
 from STUDENT2.PS_ORDER ORD
 left join STUDENT2.PS_CUSTOMER CUS
  on ORD.CUST_EMAIL = CUS.EMAIL
 where CUS.NAME like '%' || :name || '%'
  and CUS.Tel like '%' || :tel || '%'
  and ORD.ORDER_ID like '%' || :orderId || '%'
  and ORD.ORDER_PROCESS like '%' || :orderProcess || '%'
  [and (ORD.CONFIRM_DATE >= to_date(:qStartDate ,'YYYY-MM-DD'))]
  [and (ORD.CONFIRM_DATE <= to_date(:qEndDate , 'YYYY-MM-DD'))]
  