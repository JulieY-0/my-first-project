 select *
 from STUDENT2.PS_CUSTOMER CUS
 where CUS.EMAIL like '%' || :email || '%'
  and CUS.NAME like '%' || :name || '%'
  and CUS.Tel like '%' || :tel || '%'
 order by CUS.EMAIL
 offset :pageSizeIndex row
 fetch next :pageSize rows only