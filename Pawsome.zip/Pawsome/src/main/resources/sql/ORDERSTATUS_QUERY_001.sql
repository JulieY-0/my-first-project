select *
 from STUDENT2.PS_ORDER ORD
 left join STUDENT2.PS_COMMCODE CODE 
  on ORD.ORDER_PROCESS = CODE.COMMCODE
 left join STUDENT2.PS_CUSTOMER CUS
  on ORD.CUST_EMAIL = CUS.EMAIL
 where CODE.TYPE = 'ORDERPROCESS' 
  [and ORD.CONFIRM_DATE = :confirmDate]
  [and CODE.COMMCODE = :orderProcess]
 order by CODE.COMMCODE, ORD.CONFIRM_DATE
 offset :pageSizeIndex row
 fetch next :pageSize rows only